package com.chirstianbusiness.classes;

public class SearchBusinessManager {

	private String id;
	private String fk_directory_category;
	private String fk_directory_names;
	private String fk_membership_level;
	private String fk_user_id;
	private String parent_dir_id;
	private String business_name;
	private String description;
	private String business_phone;
	private String website_name;
	private String email;
	private String contact_person;
	private String fk_country;
	private String fk_country_name;
	private String fk_state;
	private String fk_state_name;
	private String fk_city;
	private String fk_city_name;
	private String street_name_number;
	private String postcode;
	private String latitude;
	private String longitude;
	private String region;
	private String longitudelongitudelongitude;
	private String business_logo;
	private String payment_status;
	private String plan_startdate;
	private String plan_enddate;
	private String is_featured;
	private String created_at;
	private String updated_at;
	private String status;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getFk_directory_category() {
		return fk_directory_category;
	}

	public void setFk_directory_category(String fk_directory_category) {
		this.fk_directory_category = fk_directory_category;
	}

	public String getFk_membership_level() {
		return fk_membership_level;
	}

	public void setFk_membership_level(String fk_membership_level) {
		this.fk_membership_level = fk_membership_level;
	}

	public String getFk_user_id() {
		return fk_user_id;
	}

	public void setFk_user_id(String fk_user_id) {
		this.fk_user_id = fk_user_id;
	}

	public String getParent_dir_id() {
		return parent_dir_id;
	}

	public void setParent_dir_id(String parent_dir_id) {
		this.parent_dir_id = parent_dir_id;
	}

	public String getBusiness_name() {
		return business_name;
	}

	public void setBusiness_name(String business_name) {
		this.business_name = business_name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getBusiness_phone() {
		return business_phone;
	}

	public void setBusiness_phone(String business_phone) {
		this.business_phone = business_phone;
	}

	public String getWebsite_name() {
		return website_name;
	}

	public void setWebsite_name(String website_name) {
		this.website_name = website_name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getContact_person() {
		return contact_person;
	}

	public void setContact_person(String contact_person) {
		this.contact_person = contact_person;
	}

	public String getFk_country() {
		return fk_country;
	}

	public void setFk_country(String fk_country) {
		this.fk_country = fk_country;
	}

	public String getFk_state() {
		return fk_state;
	}

	public void setFk_state(String fk_state) {
		this.fk_state = fk_state;
	}

	public String getFk_city() {
		return fk_city;
	}

	public void setFk_city(String fk_city) {
		this.fk_city = fk_city;
	}

	public String getStreet_name_number() {
		return street_name_number;
	}

	public void setStreet_name_number(String street_name_number) {
		this.street_name_number = street_name_number;
	}

	public String getPostcode() {
		return postcode;
	}

	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public String getLongitudelongitudelongitude() {
		return longitudelongitudelongitude;
	}

	public void setLongitudelongitudelongitude(
			String longitudelongitudelongitude) {
		this.longitudelongitudelongitude = longitudelongitudelongitude;
	}

	public String getBusiness_logo() {
		return business_logo;
	}

	public void setBusiness_logo(String business_logo) {
		this.business_logo = business_logo;
	}

	public String getPayment_status() {
		return payment_status;
	}

	public void setPayment_status(String payment_status) {
		this.payment_status = payment_status;
	}

	public String getPlan_startdate() {
		return plan_startdate;
	}

	public void setPlan_startdate(String plan_startdate) {
		this.plan_startdate = plan_startdate;
	}

	public String getPlan_enddate() {
		return plan_enddate;
	}

	public void setPlan_enddate(String plan_enddate) {
		this.plan_enddate = plan_enddate;
	}

	public String getIs_featured() {
		return is_featured;
	}

	public void setIs_featured(String is_featured) {
		this.is_featured = is_featured;
	}

	public String getCreated_at() {
		return created_at;
	}

	public void setCreated_at(String created_at) {
		this.created_at = created_at;
	}

	public String getUpdated_at() {
		return updated_at;
	}

	public void setUpdated_at(String updated_at) {
		this.updated_at = updated_at;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getFk_country_name() {
		return fk_country_name;
	}

	public void setFk_country_name(String fk_country_name) {
		this.fk_country_name = fk_country_name;
	}

	public String getFk_state_name() {
		return fk_state_name;
	}

	public void setFk_state_name(String fk_state_name) {
		this.fk_state_name = fk_state_name;
	}

	public String getFk_city_name() {
		return fk_city_name;
	}

	public void setFk_city_name(String fk_city_name) {
		this.fk_city_name = fk_city_name;
	}

	public String getFk_directory_names() {
		return fk_directory_names;
	}

	public void setFk_directory_names(String fk_directory_names) {
		this.fk_directory_names = fk_directory_names;
	}

}
