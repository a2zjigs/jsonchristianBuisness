package com.chirstianbusiness.classes;

public class MemberShipLevel {

	private String id;
	private String plan_name;
	private String plan_price;
	private String desc_limit;
	private String category_limit;

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the plan_name
	 */
	public String getPlan_name() {
		return plan_name;
	}

	/**
	 * @param plan_name
	 *            the plan_name to set
	 */
	public void setPlan_name(String plan_name) {
		this.plan_name = plan_name;
	}

	/**
	 * @return the plan_price
	 */
	public String getPlan_price() {
		return plan_price;
	}

	/**
	 * @param plan_price
	 *            the plan_price to set
	 */
	public void setPlan_price(String plan_price) {
		this.plan_price = plan_price;
	}

	/**
	 * @return the desc_limit
	 */
	public String getDesc_limit() {
		return desc_limit;
	}

	/**
	 * @param desc_limit
	 *            the desc_limit to set
	 */
	public void setDesc_limit(String desc_limit) {
		this.desc_limit = desc_limit;
	}

	/**
	 * @return the category_limit
	 */
	public String getCategory_limit() {
		return category_limit;
	}

	/**
	 * @param category_limit
	 *            the category_limit to set
	 */
	public void setCategory_limit(String category_limit) {
		this.category_limit = category_limit;
	}

}
