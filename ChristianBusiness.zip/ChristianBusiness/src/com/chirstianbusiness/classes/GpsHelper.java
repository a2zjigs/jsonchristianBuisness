package com.chirstianbusiness.classes;

public class GpsHelper {

	private String id;
	private String latitude;
	private String longitude;
	private String business_name;

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the latitude
	 */
	public String getLatitude() {
		return latitude;
	}

	/**
	 * @param latitude
	 *            the latitude to set
	 */
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	/**
	 * @return the longitude
	 */
	public String getLongitude() {
		return longitude;
	}

	/**
	 * @param longitude
	 *            the longitude to set
	 */
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	/**
	 * @return the business_name
	 */
	public String getBusiness_name() {
		return business_name;
	}

	/**
	 * @param business_name
	 *            the business_name to set
	 */
	public void setBusiness_name(String business_name) {
		this.business_name = business_name;
	}

}
