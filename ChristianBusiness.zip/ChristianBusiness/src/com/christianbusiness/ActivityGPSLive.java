package com.christianbusiness;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;
import com.animation.AnimationLayout;
import com.chirstianbusiness.classes.GPSTracker;
import com.chirstianbusiness.classes.GpsHelper;
import com.christianbusiness.preference.PreferenceConnector;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

public class ActivityGPSLive extends android.support.v4.app.FragmentActivity {

	GoogleMap find_us_map;
	ImageButton btn_home;
	GPSTracker gps;
	String Latitude, longitude, destlat, destlong;
	LatLng DUBLIN;
	ProgressDialog pDialog;
	List<LatLng> polyz;
	Button btn_list;

	protected AnimationLayout mChangePassLayout;

	protected String[] mStrings = { "Featured Business", "Search Business",
			"Near By Business", "Business Categories", "Favorite Business",
			"Resource", "Edit Profile", "Change Password", "Business Register",
			"GPS Live Map", "Logout" };

	SettingsAdapter madapter;
	ListView mList;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_findus);

		initwidget();

		SupportMapFragment fragment = (SupportMapFragment) getSupportFragmentManager()
				.findFragmentById(R.id.activity_findus_map);

		find_us_map = fragment.getMap();
		find_us_map.setMyLocationEnabled(true);

		if (isInternetAvailable()) {

		} else {
			Toast.makeText(getApplicationContext(),
					"No Internet Service Available", Toast.LENGTH_LONG).show();
		}

		MarkerOptions markerOptions = new MarkerOptions();

		markerOptions.title("Town Tour");
		markerOptions.snippet("We are here");
		gps = new GPSTracker(ActivityGPSLive.this);

		// check if GPS enabled
		if (gps.canGetLocation()) {

			Latitude = String.valueOf(gps.getLatitude());
			longitude = String.valueOf(gps.getLongitude());
			DUBLIN = new LatLng(gps.getLatitude(), gps.getLongitude());
		}

		// find_us_map.addMarker(new MarkerOptions()
		// .position(DUBLIN)
		// .title("You")
		// .snippet("You Are Here .")
		// .icon(BitmapDescriptorFactory
		// .defaultMarker(BitmapDescriptorFactory.HUE_VIOLET)));
		// LatLng latlng = new LatLng(52.245178, 0.715605);
		// destlat = "52.245178";
		// destlong = "0.715605";
		// find_us_map.moveCamera(CameraUpdateFactory.newLatLng(latlng));
		// find_us_map.animateCamera(CameraUpdateFactory.zoomTo(10));
		//
		// markerOptions.position(latlng);
		// find_us_map.addMarker(markerOptions);

		// new GetDirection().execute();

		btn_list.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
				mChangePassLayout.toggleSidebar();
				
			}
		});
		GetGpsLocation();
	}

	private void initwidget() {
		madapter = new SettingsAdapter(getApplicationContext());

		btn_list = (Button) findViewById(R.id.activity_findus_back_btn);

		mChangePassLayout = (AnimationLayout) findViewById(R.id.activity_change_password_mainlayout);
		mList = (ListView) findViewById(R.id.sidebar_list);

		mList.setAdapter(madapter);
		mList.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				// TODO Auto-generated method stub
				switch (arg2) {
				case 0:

					mChangePassLayout.toggleSidebar();
					Intent IntentNearby = new Intent(ActivityGPSLive.this,
							ActivityFeatured.class);
					startActivity(IntentNearby);
					finish();
					break;

				case 1:

					mChangePassLayout.toggleSidebar();
					Intent IntentActivitySearch = new Intent(
							ActivityGPSLive.this, ActivitySearchOption.class);
					startActivity(IntentActivitySearch);
					finish();

					break;

				case 2:
					mChangePassLayout.toggleSidebar();
					Intent intentchangepasswor2 = new Intent(
							ActivityGPSLive.this, ActivityNearByBusiness.class);
					startActivity(intentchangepasswor2);
					finish();

					break;

				case 3:
					mChangePassLayout.toggleSidebar();
					Intent intentchangepasswor = new Intent(
							ActivityGPSLive.this, ActivityEvents.class);
					startActivity(intentchangepasswor);
					finish();
					break;
				case 4:
					mChangePassLayout.toggleSidebar();
					Intent intentfavbusi = new Intent(ActivityGPSLive.this,
							ActivityFavouriteBusiness.class);
					startActivity(intentfavbusi);
					finish();

					break;

				case 5:
					mChangePassLayout.toggleSidebar();
					Intent IntentResource = new Intent(ActivityGPSLive.this,
							ActivityResource.class);
					startActivity(IntentResource);
					finish();
					break;
				case 6:
					// Toast.makeText(getApplicationContext(),
					// "Item Selected::" + arg2, Toast.LENGTH_LONG).show();
					mChangePassLayout.toggleSidebar();
					Intent intentchangepasswor3 = new Intent(
							ActivityGPSLive.this,
							ActivityRegistrationUpdate.class);
					startActivity(intentchangepasswor3);
					finish();
					break;

				case 7:
					// Toast.makeText(getApplicationContext(),
					// "Item Selected::" + arg2, Toast.LENGTH_LONG).show();
					mChangePassLayout.toggleSidebar();
					Intent Intengps = new Intent(ActivityGPSLive.this,
							ActivityChangePassword.class);
					startActivity(Intengps);
					finish();
					break;

				case 8:
					mChangePassLayout.toggleSidebar();
					Intent regActivity = new Intent(ActivityGPSLive.this,
							ActivityRegisterBusiness.class);
					startActivity(regActivity);
					finish();

					break;
				case 9:
					mChangePassLayout.toggleSidebar();
//					finish();
//					Intent Activity = new Intent(ActivityGPSLive.this,
//							ActivityGPSLive.class);
//					startActivity(Activity);


					break;

				case 10:
					PreferenceConnector.writeBoolean(getApplicationContext(),
							PreferenceConnector.IS_USER_LOGIN, false);

					AlertDialog.Builder alert = new AlertDialog.Builder(
							ActivityGPSLive.this);

					alert.setTitle("ChristianBusinessDirectory");
					alert.setMessage("Are You sure You Want to logout?");

					alert.setPositiveButton("Ok",
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int whichButton) {
									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.EMAIL, "");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.FIRSTNAME, "");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.LASTNAME, "");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.COUNTRYID, "");

									PreferenceConnector
											.writeString(
													getApplicationContext(),
													PreferenceConnector.COUNTRYNAME,
													"");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.STATEID, "");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.STATENAME, "");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.CITYNAME, "");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.CITYID, "");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.BUSINESS_NAME,
											"");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.USER_ID, "");
									Intent intent = new Intent(
											ActivityGPSLive.this,
											ActivityLogin.class);
									startActivity(intent);
									ActivityGPSLive.this.finish();
								}

							});
					alert.setNegativeButton("Cancel",
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int which) {
									// TODO Auto-generated method stub

								}

							});

					alert.show();

					break;
				default:
					break;
				}

			}
		});

	}

	protected void GetGpsLocation() {

		final ProgressDialog dialog;
		dialog = new ProgressDialog(this);
		dialog.setTitle("");
		dialog.setMessage("Please Wait...");
		dialog.setCancelable(false);

		AsyncTask<Void, Void, Boolean> waitForCompletion = new AsyncTask<Void, Void, Boolean>() {

			@Override
			protected void onPreExecute() {
				// TODO Auto-generated method stub
				super.onPreExecute();
				dialog.show();
			}

			@Override
			protected Boolean doInBackground(Void... arg0) {
				// TODO Auto-generated method stub
				Cons.ListofGpsList.clear();
				try {

					HttpClient httpClient = new DefaultHttpClient();
					String url = com.christianbusiness.utils.Constant.GetAllBusinesforGps;
					HttpGet httpGet = new HttpGet(url);
					Log.i("URL", url);

					HttpResponse response = httpClient.execute(httpGet);
					String json = EntityUtils.toString(response.getEntity());
					JSONTokener tokener = new JSONTokener(json);
					JSONObject finalResult = new JSONObject(tokener);
					Log.i("Response Json", "" + finalResult.toString());
					JSONArray obj = finalResult.getJSONArray("data");
					Log.i("Object of Data", obj.toString());
					for (int i = 0; i < obj.length(); i++) {
						GpsHelper cm = new GpsHelper();
						JSONObject objdata = obj.getJSONObject(i);
						cm.setId(objdata.getString("id"));

						if (objdata.has("business_name")) {
							cm.setBusiness_name(objdata
									.getString("business_name"));
						} else {
							cm.setBusiness_name("N.A");
						}

						if (objdata.has("latitude")) {
							cm.setLatitude(objdata.getString("latitude"));

							if (objdata.isNull("latitude")
									|| objdata.getString("latitude").equals("")) {
								if (gps.canGetLocation())
									cm.setLatitude(String.valueOf(gps
											.getLatitude()));
							}
						} else {
							if (gps.canGetLocation())
								cm.setLatitude(String.valueOf(gps.getLatitude()));
						}

						if (objdata.has("longitude")) {
							cm.setLongitude(objdata.getString("longitude"));

							if (objdata.isNull("longitude")
									|| objdata.getString("longitude")
											.equals("")) {
								if (gps.canGetLocation())
									cm.setLongitude(String.valueOf(gps
											.getLongitude()));
							}
						} else {
							if (gps.canGetLocation())
								cm.setLongitude(String.valueOf(gps
										.getLongitude()));
						}

						Cons.ListofGpsList.add(cm);

					}

				} catch (ClientProtocolException e) {
					// TODO Auto-generated catch block
					Log.i("Exception",
							"ClientProtocolException : " + e.getMessage());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Log.i("Exception", "IOException : " + e.getMessage());
				} catch (Exception e) {
					// TODO: handle exception
					Log.i("Exception", "Http Response : " + e.getMessage());
				}
				return null;
			}

			@Override
			protected void onPostExecute(Boolean result) {
				// TODO Auto-generated method stub
				dialog.dismiss();

				for (int i = 0; i < Cons.ListofGpsList.size(); i++) {
					// Cons.ListofGpsList.size();
					MarkerOptions markerOptions = new MarkerOptions();

					// Getting latitude of the place
					double lat = 0, lng = 0;

					if (Cons.ListofGpsList.get(i).getLatitude() != null
							|| !Cons.ListofGpsList.get(i).getLatitude().trim()
									.equals("")) {
						lat = Double.parseDouble(Cons.ListofGpsList.get(i)
								.getLatitude());
					} else {
						if (gps.canGetLocation())
							lat = gps.getLatitude();
					}

					// Getting longitude of the place
					if (Cons.ListofGpsList.get(i).getLongitude() != null
							|| !Cons.ListofGpsList.get(i).getLongitude().trim()
									.equals("")) {
						lng = Double.parseDouble(Cons.ListofGpsList.get(i)
								.getLongitude());
					} else {
						if (gps.canGetLocation())
							lng = gps.getLongitude();
					}

					// Getting name
					String name = Cons.ListofGpsList.get(i).getBusiness_name()
							.toString();

					// Getting vicinity
					String vicinity = Cons.ListofGpsList.get(i)
							.getBusiness_name().toString();

					LatLng latLng = new LatLng(lat, lng);

					// Setting the position for the marker
					markerOptions.position(latLng);

					markerOptions.title(vicinity);
					markerOptions.snippet(name);

					find_us_map
							.addMarker(new MarkerOptions()
									.position(latLng)
									.title(vicinity)
									.snippet("")
									.icon(BitmapDescriptorFactory
											.defaultMarker(BitmapDescriptorFactory.HUE_VIOLET)));

					find_us_map.moveCamera(CameraUpdateFactory
							.newLatLng(latLng));
					find_us_map.animateCamera(CameraUpdateFactory.zoomTo(0));
				}

			}

		};

		if (isInternetAvailable())
			waitForCompletion.execute();
		else
			Toast.makeText(getApplicationContext(),
					"Internet service not available", Toast.LENGTH_SHORT)
					.show();

	}

	public boolean isInternetAvailable() {
		ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		if (cm.getActiveNetworkInfo() != null)
			return (cm.getActiveNetworkInfo().isConnected() && cm
					.getActiveNetworkInfo().isAvailable());
		else
			return false;
	}

	public class SettingsAdapter extends BaseAdapter {

		Context mContext;

		public SettingsAdapter(Context c) {
			mContext = c;
		}

		public int getCount() {
			return mStrings.length;
		}

		public Object getItem(int pos) {
			return pos;
		}

		public long getItemId(int pos) {
			return pos;
		}

		public View getView(final int pos, View convertView, ViewGroup parent) {
			if (convertView == null)
				convertView = View.inflate(mContext, R.layout.row_layout_file,
						null);

			final ViewHolder holder = new ViewHolder();

			holder.imgText = (TextView) convertView
					.findViewById(R.id.row_layout_file_text_title);
			holder.imgText.setText(mStrings[pos]);
			return convertView;
		}

		class ViewHolder {
			public ImageView imgIcon, imgright;
			TextView imgText;
		}
	}

	class GetDirection extends AsyncTask<String, String, String> {

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			pDialog = new ProgressDialog(ActivityGPSLive.this);
			pDialog.setMessage("Loading route please wait..");
			pDialog.setIndeterminate(false);
			pDialog.setCancelable(false);
			pDialog.show();
		}

		protected String doInBackground(String... args) {

			String stringUrl = "http://maps.googleapis.com/maps/api/directions/json?origin="
					+ Latitude
					+ ","
					+ longitude
					+ "&destination="
					+ destlat
					+ "," + destlong + "&sensor=false";

			Log.i("String URL :", stringUrl);

			StringBuilder response = new StringBuilder();
			try {
				URL url = new URL(stringUrl);
				HttpURLConnection httpconn = (HttpURLConnection) url
						.openConnection();
				if (httpconn.getResponseCode() == HttpURLConnection.HTTP_OK) {
					BufferedReader input = new BufferedReader(
							new InputStreamReader(httpconn.getInputStream()),
							8192);
					String strLine = null;

					while ((strLine = input.readLine()) != null) {
						response.append(strLine);
					}
					input.close();
				}

				String jsonOutput = response.toString();

				JSONObject jsonObject = new JSONObject(jsonOutput);

				// routesArray contains ALL routes
				JSONArray routesArray = jsonObject.getJSONArray("routes");
				// Grab the first route
				JSONObject route = routesArray.getJSONObject(0);

				JSONObject poly = route.getJSONObject("overview_polyline");
				String polyline = poly.getString("points");
				polyz = decodePoly(polyline);

			} catch (Exception e) {

			}

			return null;

		}

		protected void onPostExecute(String file_url) {

			for (int i = 0; i < polyz.size() - 1; i++) {
				LatLng src = polyz.get(i);
				LatLng dest = polyz.get(i + 1);
				Polyline line = find_us_map.addPolyline(new PolylineOptions()
						.add(new LatLng(src.latitude, src.longitude),
								new LatLng(dest.latitude, dest.longitude))
						.width(5).color(Color.RED).geodesic(true));

			}

			pDialog.dismiss();

		}
	}

	private List<LatLng> decodePoly(String encoded) {

		List<LatLng> poly = new ArrayList<LatLng>();
		int index = 0, len = encoded.length();
		int lat = 0, lng = 0;

		while (index < len) {
			int b, shift = 0, result = 0;
			do {
				b = encoded.charAt(index++) - 63;
				result |= (b & 0x1f) << shift;
				shift += 5;
			} while (b >= 0x20);
			int dlat = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
			lat += dlat;

			shift = 0;
			result = 0;
			do {
				b = encoded.charAt(index++) - 63;
				result |= (b & 0x1f) << shift;
				shift += 5;
			} while (b >= 0x20);
			int dlng = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
			lng += dlng;

			LatLng p = new LatLng((((double) lat / 1E5)),
					(((double) lng / 1E5)));
			poly.add(p);
		}

		return poly;
	}

}
