package com.christianbusiness;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

import com.christianbusiness.preference.PreferenceConnector;
import com.christianbusiness.utils.Constant;
import com.paypal.android.sdk.payments.PayPalPayment;
import com.paypal.android.sdk.payments.PayPalService;
import com.paypal.android.sdk.payments.PaymentActivity;
import com.paypal.android.sdk.payments.PaymentConfirmation;

public class ActivityTermsAndConditions extends Activity {

	Button btn_back, btn_next, btn_payment, btn_submit;

	static TextView web_view;
	static String Succcess, id;
	static String Terms;
	static CheckBox check_terms;
	String Category;

	private static final String CONFIG_ENVIRONMENT = PaymentActivity.ENVIRONMENT_SANDBOX;
	private static final String CONFIG_CLIENT_ID = "AfxEPBCbluH93FqY_XcDqO93935NmdFDLFj8Qweoza6ZXz4kK_1Lm1QWVhMA";
	private static final String CONFIG_RECEIVER_EMAIL = "vaibhav-facilitator@siliconithub.com";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_terms_and_conditions);

		initwidget();

		GetTermsCondition();

		Intent intent = new Intent(this, PayPalService.class);

		intent.putExtra(PaymentActivity.EXTRA_PAYPAL_ENVIRONMENT,
				CONFIG_ENVIRONMENT);
		intent.putExtra(PaymentActivity.EXTRA_CLIENT_ID, CONFIG_CLIENT_ID);
		intent.putExtra(PaymentActivity.EXTRA_RECEIVER_EMAIL,
				CONFIG_RECEIVER_EMAIL);

		startService(intent);

		Category = ActivityCategoryList.CheckStatus.toString().substring(1,
				ActivityCategoryList.CheckStatus.toString().length() - 1);

		btn_back.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				finish();
				overridePendingTransition(R.anim.trans_right_in,
						R.anim.trans_right_out);
			}
		});

		btn_next.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent IntentSubmitActivity = new Intent(
						ActivityTermsAndConditions.this, ActivitySubmit.class);
				startActivity(IntentSubmitActivity);
				overridePendingTransition(R.anim.trans_left_in,
						R.anim.trans_left_out);
			}

		});

		btn_submit.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if (check_terms.isChecked()) {
					SendBusinessRegistrationApplication();
				} else {
					ShowAlert("ChristianBusinessDirectory",
							"Please accept the terms & condition.");
				}

			}
		});

		btn_payment.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

				if (check_terms.isChecked()) {

					PayPalPayment Sponsor = null, Premium = null, Deluxe = null;

					Sponsor = new PayPalPayment(new BigDecimal("97"), "USD",
							"Sponsor");
					Premium = new PayPalPayment(new BigDecimal("177"), "USD",
							"Premium");
					Deluxe = new PayPalPayment(new BigDecimal("397"), "USD",
							"Deluxe");

					Intent intent = new Intent(ActivityTermsAndConditions.this,
							PaymentActivity.class);
					intent.putExtra(PaymentActivity.EXTRA_PAYPAL_ENVIRONMENT,
							CONFIG_ENVIRONMENT);
					intent.putExtra(PaymentActivity.EXTRA_CLIENT_ID,
							CONFIG_CLIENT_ID);
					intent.putExtra(PaymentActivity.EXTRA_RECEIVER_EMAIL,
							CONFIG_RECEIVER_EMAIL);

					if (ActivityCategoryList.sizeofselection == 2) {
						intent.putExtra(PaymentActivity.EXTRA_PAYMENT, Sponsor);
					} else if (ActivityCategoryList.sizeofselection == 3) {
						intent.putExtra(PaymentActivity.EXTRA_PAYMENT, Premium);
					} else if (ActivityCategoryList.sizeofselection == 5) {
						intent.putExtra(PaymentActivity.EXTRA_PAYMENT, Deluxe);
					}

					startActivityForResult(intent, 0);

					overridePendingTransition(R.anim.trans_left_in,
							R.anim.trans_left_out);

				} else {

					ShowAlert("ChristianBusinessDirectory",
							"Please accept the terms & condition.");
				}

			}
		});
	}

	private void initwidget() {

		btn_back = (Button) findViewById(R.id.activity_terms_and_conditions_back_btn);
		btn_next = (Button) findViewById(R.id.activity_terms_and_conditions_next_btn);
		btn_submit = (Button) findViewById(R.id.activity_terms_and_conditions_submit_btn);
		btn_payment = (Button) findViewById(R.id.activity_terms_and_conditions_payment_btn);
		check_terms = (CheckBox) findViewById(R.id.activity_terms_and_conditions_checkbox);

		web_view = (TextView) findViewById(R.id.activity_terms_and_conditions_webview);
		web_view.setMovementMethod(ScrollingMovementMethod.getInstance());

		if (ActivityCategoryList.sizeofselection == 1) {
			btn_submit.setVisibility(View.VISIBLE);
		} else {
			btn_submit.setVisibility(View.GONE);
			btn_payment.setVisibility(View.VISIBLE);

		}
		// /web_view.loadUrl("http://www.google.co.in");
	}

	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		finish();
		overridePendingTransition(R.anim.trans_right_in, R.anim.trans_right_out);
		super.onBackPressed();
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		if (resultCode == Activity.RESULT_OK) {
			PaymentConfirmation confirm = data
					.getParcelableExtra(PaymentActivity.EXTRA_RESULT_CONFIRMATION);
			if (confirm != null) {
				// try {
				// Log.i("paymentExample",
				// confirm.toJSONObject().toString(4));
				// Intent i = new Intent(ActivityTermsAndConditions.this,
				// ActivityFeatured.class);
				// startActivity(i);
				// finish();
				SendBusinessRegistrationApplication();
				// } catch (JSONException e) {
				// Log.e("paymentExample",
				// "an extremely unlikely failure occurred: ", e);
				// }
			}
		} else if (resultCode == Activity.RESULT_CANCELED) {
			Log.i("paymentExample", "The user canceled.");
			ShowAlert("ChristianBusinessDirectory",
					"Transaction is canceled by user.");
		} else if (resultCode == PaymentActivity.RESULT_PAYMENT_INVALID) {
			Log.i("paymentExample",
					"An invalid payment was submitted. Please see the docs.");
			ShowAlert("ChristianBusinessDirectory", "Unauthorize Error..");
		}
	}

	private void ShowAlertMessage(String Title, String Message) {
		AlertDialog.Builder alertDialog = new AlertDialog.Builder(
				ActivityTermsAndConditions.this);

		// Setting Dialog Title
		alertDialog.setTitle(Title);

		// Setting Dialog Message
		alertDialog.setMessage(Message);

		// Setting Icon to Dialog
		// alertDialog.setIcon(R.drawable.delete);

		// Setting Positive "Yes" Button
		alertDialog.setPositiveButton("Cancel",
				new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int which) {

						// Write your code here to invoke YES event
						dialog.cancel();
					}
				});

		// Setting Negative "NO" Button
		alertDialog.setNegativeButton("Submit",
				new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int which) {
						// Write your code here to invoke NO event

						dialog.cancel();
						SendBusinessRegistrationApplication();

					}
				});

		// Showing Alert Message
		alertDialog.show();
	}

	private void SendBusinessRegistrationApplication() {
		// TODO Auto-generated method stub
		final ProgressDialog dialog;
		dialog = new ProgressDialog(this);
		dialog.setTitle("");
		dialog.setMessage("Please Wait...");
		dialog.setCancelable(false);

		AsyncTask<Void, Void, Boolean> waitForCompletion = new AsyncTask<Void, Void, Boolean>() {

			@Override
			protected void onPreExecute() {
				// TODO Auto-generated method stub
				super.onPreExecute();
				dialog.show();
			}

			@Override
			protected Boolean doInBackground(Void... params) {

				JSONObject jbjdata = new JSONObject();
				JSONObject jbj = new JSONObject();

				try {
					// jbj.put("fk_directory_category",
					// ActivityCategoryList.CheckStatus.toString());
					jbj.put("fk_directory_category", Category);

					Log.i("Category ::", Category);

					jbj.put("fk_membership_level", PreferenceConnector
							.readString(getApplicationContext(),
									PreferenceConnector.MEMBERSHIP_ID, ""));

					Log.i("membershiplevel ::", PreferenceConnector.readString(
							getApplicationContext(),
							PreferenceConnector.MEMBERSHIP_ID, ""));

					jbj.put("fk_user_id", PreferenceConnector.readString(
							getApplicationContext(),
							PreferenceConnector.USER_ID, ""));

					Log.i("User id ::", PreferenceConnector.readString(
							getApplicationContext(),
							PreferenceConnector.USER_ID, ""));

					jbj.put("business_name", PreferenceConnector.readString(
							getApplicationContext(),
							PreferenceConnector.BUSINESS_NAME_REGISTER, ""));

					Log.i("business_name::", PreferenceConnector.readString(
							getApplicationContext(),
							PreferenceConnector.BUSINESS_NAME_REGISTER, ""));

					jbj.put("business_phone", PreferenceConnector.readString(
							getApplicationContext(),
							PreferenceConnector.BUSINESS_PHNO, ""));

					Log.i("business_phone::", PreferenceConnector.readString(
							getApplicationContext(),
							PreferenceConnector.BUSINESS_PHNO, ""));

					jbj.put("website_name", PreferenceConnector.readString(
							getApplicationContext(),
							PreferenceConnector.BUSINESS_WEBSITE, ""));

					Log.i("website_name::", PreferenceConnector.readString(
							getApplicationContext(),
							PreferenceConnector.BUSINESS_WEBSITE, ""));

					jbj.put("email", PreferenceConnector.readString(
							getApplicationContext(), PreferenceConnector.EMAIL,
							""));

					Log.i("email::", PreferenceConnector.readString(
							getApplicationContext(), PreferenceConnector.EMAIL,
							""));

					jbj.put("contact_person", PreferenceConnector.readString(
							getApplicationContext(),
							PreferenceConnector.CONTACT_PERSON, ""));

					Log.i("contact_person::", PreferenceConnector.readString(
							getApplicationContext(),
							PreferenceConnector.CONTACT_PERSON, ""));

					jbj.put("fk_country", PreferenceConnector.readString(
							getApplicationContext(),
							PreferenceConnector.BUSINES_COUNTRYID, ""));

					Log.i("fk_country::", PreferenceConnector.readString(
							getApplicationContext(),
							PreferenceConnector.BUSINES_COUNTRYID, ""));

					jbj.put("fk_state", PreferenceConnector.readString(
							getApplicationContext(),
							PreferenceConnector.BUSINES_STATEID, ""));

					Log.i("fk_state::", PreferenceConnector.readString(
							getApplicationContext(),
							PreferenceConnector.BUSINES_STATEID, ""));

					jbj.put("fk_city", PreferenceConnector.readString(
							getApplicationContext(),
							PreferenceConnector.BUSINES_CITYID, ""));

					Log.i("fk_city::", PreferenceConnector.readString(
							getApplicationContext(),
							PreferenceConnector.BUSINES_CITYID, ""));

					jbj.put("street_name_number", PreferenceConnector
							.readString(getApplicationContext(),
									PreferenceConnector.STREEET_ADDRESS, ""));

					Log.i("street_name_number::", PreferenceConnector
							.readString(getApplicationContext(),
									PreferenceConnector.STREEET_ADDRESS, ""));

					jbj.put("postcode", PreferenceConnector.readString(
							getApplicationContext(),
							PreferenceConnector.BUSINESS_POSTCODE, ""));

					Log.i("postcode::", PreferenceConnector.readString(
							getApplicationContext(),
							PreferenceConnector.BUSINESS_POSTCODE, ""));

					// jbj.put("region", PreferenceConnector.readString(
					// getApplicationContext(),
					// PreferenceConnector.REGION, ""));
					//
					// Log.i("region::", PreferenceConnector.readString(
					// getApplicationContext(),
					// PreferenceConnector.REGION, ""));

					// jbj.put("payment_status", PreferenceConnector.readString(
					// getApplicationContext(),
					// PreferenceConnector.PAYMENT_STATUS, "N"));

					jbj.put("payment_status", "Y");

					Log.i("payment_status::", PreferenceConnector.readString(
							getApplicationContext(),
							PreferenceConnector.PAYMENT_STATUS, ""));

					jbj.put("status", "Y");

					jbj.put("description", PreferenceConnector.readString(
							getApplicationContext(),
							PreferenceConnector.DESCRIPTION, ""));

					Log.i("Description ::", PreferenceConnector.readString(
							getApplicationContext(),
							PreferenceConnector.DESCRIPTION, ""));

					if (ActivityAddLogo.Base64ofImage == null
							|| ActivityAddLogo.Base64ofImage.isEmpty()) {
						jbj.put("imageData", "");
						Log.i("Base 64 imageData ::", "");
					} else {
						jbj.put("imageData", ActivityAddLogo.Base64ofImage);
						Log.i("Base 64 imageData ::",
								ActivityAddLogo.Base64ofImage);
					}

					// Log.i("Base 64 imageData ::",
					// ActivityAddLogo.Base64ofImage);

					jbjdata.put("data", jbj);

				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				String finalString = jbjdata.toString();
				Log.i("String final", "" + finalString);

				try {
					HttpClient httpClient = new DefaultHttpClient();

					String url = Constant.BusinessRegistraton;
					HttpPost httpPost = new HttpPost(url);

					List<NameValuePair> parameters = new ArrayList<NameValuePair>();
					parameters.add(new BasicNameValuePair("data", finalString));
					httpPost.setEntity(new UrlEncodedFormEntity(parameters,
							"UTF-8"));

					HttpResponse response = httpClient.execute(httpPost);
					BufferedReader reader = new BufferedReader(
							new InputStreamReader(response.getEntity()
									.getContent(), "UTF-8"));

					String json = reader.readLine();
					Log.i("String response", "" + json);

					JSONTokener tokener = new JSONTokener(json);
					JSONObject finalResult = new JSONObject(tokener);

					Succcess = finalResult.getString("success");
					id = finalResult.getString("id");
					Succcess = "1";
				} catch (ClientProtocolException e) {
					// TODO Auto-generated catch block
					Log.i("Exception",
							"ClientProtocolException : " + e.getMessage());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Log.i("Exception", "IOException : " + e.getMessage());
				} catch (Exception e) {
					// TODO: handle exception
					Log.i("Exception", "Http Response : " + e.getMessage());
				}
				return null;
			}

			@Override
			protected void onPostExecute(Boolean result) {
				// TODO Auto-generated method stub
				super.onPostExecute(result);
				dialog.dismiss();

				if (Succcess.equals("1")
						&& ActivityMembershiplevel.membershiplevel != 1) {
					SendPaymentMethodNotification();
				} else {
					AlertDialog.Builder alertDialog = new AlertDialog.Builder(
							ActivityTermsAndConditions.this);

					// Setting Dialog Title
					alertDialog.setTitle("ChristianBusinessDirectory");

					// Setting Dialog Message
					alertDialog.setMessage("Business Registered Successfully");

					alertDialog.setPositiveButton("Ok",
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int which) {

									// Write your code here to invoke YES event
									dialog.cancel();
									Intent intent = new Intent(
											ActivityTermsAndConditions.this,
											ActivityFeatured.class);
									intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
									intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
									if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB)
										intent.addFlags(0x8000);
									startActivity(intent);
								}
							});
					alertDialog.show();
				}

			}
		};
		if (isInternetAvailable())
			waitForCompletion.execute();
		else
			Toast.makeText(getApplicationContext(),
					"Internet service not available", Toast.LENGTH_SHORT)
					.show();
	}

	private boolean isInternetAvailable() {
		// TODO Auto-generated method stub
		ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		if (cm.getActiveNetworkInfo() != null)
			return (cm.getActiveNetworkInfo().isConnected() && cm
					.getActiveNetworkInfo().isAvailable());
		else
			return false;
	}

	private void GetTermsCondition() {

		final ProgressDialog dialog;
		dialog = new ProgressDialog(this);
		dialog.setTitle("");

		dialog.setMessage("Please Wait...");
		dialog.setCancelable(false);

		AsyncTask<Void, Void, Boolean> waitForCompletion = new AsyncTask<Void, Void, Boolean>() {

			@Override
			protected void onPreExecute() {
				// TODO Auto-generated method stub
				super.onPreExecute();
				dialog.show();
			}

			@Override
			protected Boolean doInBackground(Void... params) {
				try {

					HttpClient httpClient = new DefaultHttpClient();
					String url = com.christianbusiness.utils.Constant.GetTermCondition;

					HttpGet httpGet = new HttpGet(url);
					Log.i("URL", url);

					HttpResponse response = httpClient.execute(httpGet);
					String json = EntityUtils.toString(response.getEntity());
					JSONTokener tokener = new JSONTokener(json);
					JSONObject finalResult = new JSONObject(tokener);
					Log.i("Response Json", "" + finalResult.toString());
					Terms = finalResult.getString("data");
				} catch (ClientProtocolException e) {
					// TODO Auto-generated catch block
					Log.i("Exception",
							"ClientProtocolException : " + e.getMessage());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Log.i("Exception", "IOException : " + e.getMessage());
				} catch (Exception e) {
					// TODO: handle exception
					Log.i("Exception", "Http Response : " + e.getMessage());
				}
				return null;
			};

			@Override
			protected void onPostExecute(Boolean result) {

				dialog.dismiss();
				web_view.setText(Terms);
			}
		};
		if (isInternetAvailable())
			waitForCompletion.execute();
		else
			Toast.makeText(getApplicationContext(),
					"Internet service not available", Toast.LENGTH_SHORT)
					.show();
	}

	private void SendPaymentMethodNotification() {

		final ProgressDialog dialog;
		dialog = new ProgressDialog(this);
		dialog.setTitle("");

		dialog.setMessage("Please Wait...");
		dialog.setCancelable(false);

		AsyncTask<Void, Void, Boolean> waitForCompletion = new AsyncTask<Void, Void, Boolean>() {

			@Override
			protected void onPreExecute() {
				// TODO Auto-generated method stub
				super.onPreExecute();
				dialog.show();
			}

			@Override
			protected Boolean doInBackground(Void... params) {
				try {

					HttpClient httpClient = new DefaultHttpClient();
					String url = com.christianbusiness.utils.Constant.GetPaymentMethod
							+ id;

					HttpGet httpGet = new HttpGet(url);
					Log.i("URL", url);

					HttpResponse response = httpClient.execute(httpGet);
					String json = EntityUtils.toString(response.getEntity());
					JSONTokener tokener = new JSONTokener(json);
					JSONObject finalResult = new JSONObject(tokener);
					Log.i("Response Json", "" + finalResult.toString());
					Terms = finalResult.getString("data");
				} catch (ClientProtocolException e) {
					// TODO Auto-generated catch block
					Log.i("Exception",
							"ClientProtocolException : " + e.getMessage());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Log.i("Exception", "IOException : " + e.getMessage());
				} catch (Exception e) {
					// TODO: handle exception
					Log.i("Exception", "Http Response : " + e.getMessage());
				}
				return null;
			};

			@Override
			protected void onPostExecute(Boolean result) {

				dialog.dismiss();
				AlertDialog.Builder alertDialog = new AlertDialog.Builder(
						ActivityTermsAndConditions.this);

				// Setting Dialog Title
				alertDialog.setTitle("ChristianBusinessDirectory");

				// Setting Dialog Message
				alertDialog.setMessage("Business Registered Successfully");

				alertDialog.setPositiveButton("Ok",
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog,
									int which) {

								// Write your code here to invoke YES event
								dialog.cancel();
								Intent intent = new Intent(
										ActivityTermsAndConditions.this,
										ActivityFeatured.class);
								intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
								intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
								if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB)
									intent.addFlags(0x8000);
								startActivity(intent);
							}
						});
				alertDialog.show();
			}
		};
		if (isInternetAvailable())
			waitForCompletion.execute();
		else
			Toast.makeText(getApplicationContext(),
					"Internet service not available", Toast.LENGTH_SHORT)
					.show();
	}

	private void ShowAlert(String Title, String Message) {
		AlertDialog.Builder alertDialog = new AlertDialog.Builder(
				ActivityTermsAndConditions.this);

		// Setting Dialog Title
		alertDialog.setTitle(Title);

		// Setting Dialog Message
		alertDialog.setMessage(Message);

		alertDialog.setPositiveButton("Ok",
				new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int which) {

						// Write your code here to invoke YES event
						dialog.cancel();
					}
				});
		alertDialog.show();
	}
}
