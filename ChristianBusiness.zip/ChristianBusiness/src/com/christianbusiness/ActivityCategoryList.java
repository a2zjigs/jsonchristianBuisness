package com.christianbusiness;

import java.io.IOException;
import java.util.ArrayList;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class ActivityCategoryList extends Activity {

	ListView list_of_category;
	TextView txt_membershipname;

	SettingsAdapter mAdapter;
	Button btn_back, btn_next;

	public static String Stringmembership;
	static int sizeofselection;

	public static ArrayList<String> CheckStatus = new ArrayList<String>();
	public static ArrayList<CategoryManager> ListOfCategory = new ArrayList<CategoryManager>();

	protected void onCreate(android.os.Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_categorylist);
		initwidget();

		mAdapter = new SettingsAdapter(getApplicationContext());
		list_of_category.setAdapter(mAdapter);
		// ListOfCategory = (ArrayList<CategoryManager>) Cons.ListOfCategory
		// .clone();

		if (Cons.ListOfCategory.size() == 0) {
			CheckStatus.clear();
			GetCategoryList();
		}

		btn_back.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				finish();
				overridePendingTransition(R.anim.trans_right_in,
						R.anim.trans_right_out);
			}
		});

		btn_next.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if (CheckStatus.size() <= sizeofselection) {
					Intent intentActivityLogo = new Intent(
							ActivityCategoryList.this, ActivityAddLogo.class);
					startActivity(intentActivityLogo);
					overridePendingTransition(R.anim.trans_left_in,
							R.anim.trans_left_out);
				} else {
					ShowAlertMessage("ChristianBusinessDirectory",
							"you can select " + sizeofselection + " category");
				}

			}
		});
	};

	private void initwidget() {
		list_of_category = (ListView) findViewById(R.id.activity_category_list);
		txt_membershipname = (TextView) findViewById(R.id.activity_categorylist_textview_membership);

		btn_back = (Button) findViewById(R.id.activity_categorylist_btn_back);
		btn_next = (Button) findViewById(R.id.activity_categorylist_btn_next);

		txt_membershipname.setText("You can select maximum " + sizeofselection
				+ " category for membership level " + Stringmembership);
	}

	public class SettingsAdapter extends BaseAdapter {

		Context mContext;

		public SettingsAdapter(Context c) {
			mContext = c;
		}

		public int getCount() {
			return Cons.ListOfCategory.size();
		}

		public Object getItem(int pos) {
			return pos;
		}

		public long getItemId(int pos) {
			return pos;
		}

		public View getView(final int pos, View convertView, ViewGroup parent) {
			if (convertView == null)
				convertView = View.inflate(mContext,
						R.layout.row_layout_category_list, null);

			final ViewHolder holder = new ViewHolder();
			holder.imgIcon = (ImageView) convertView
					.findViewById(R.id.row_layout_category_checkbox_selected);
			holder.imgText = (TextView) convertView
					.findViewById(R.id.row_layout_category_textview_title);

			holder.imgText.setText(Cons.ListOfCategory.get(pos)
					.getCategory_name());

			if (Cons.ListOfCategory.get(pos).getChecked()) {
				holder.imgIcon.setImageResource(R.drawable.checkbox_tick);
				Log.i("Category", pos + ":" + "true");
			} else {
				holder.imgIcon.setImageResource(R.drawable.checkbox);
				Log.i("Category", pos + ":" + "false");
			}

			holder.imgIcon.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub

					if (Cons.ListOfCategory.get(pos).getChecked()) {
						holder.imgIcon.setImageResource(R.drawable.checkbox);
						CheckStatus.remove(CheckStatus.size() - 1);
						CategoryManager cm = new CategoryManager();

						cm.setId(Cons.ListOfCategory.get(pos).getId());
						cm.setCategory_name(Cons.ListOfCategory.get(pos)
								.getCategory_name());
						cm.setCategory_image(Cons.ListOfCategory.get(pos)
								.getCategory_image());
						cm.setCategory_desc(Cons.ListOfCategory.get(pos)
								.getCategory_desc());
						cm.setCreated_at(Cons.ListOfCategory.get(pos)
								.getCreated_at());
						cm.setUpdated_at(Cons.ListOfCategory.get(pos)
								.getUpdated_at());
						cm.setStatus(Cons.ListOfCategory.get(pos).getStatus());
						cm.setChecked(false);

						Cons.ListOfCategory.remove(pos);
						Cons.ListOfCategory.add(pos, cm);
						Log.i("Status NOT::", ""
								+ Cons.ListOfCategory.get(pos).getChecked());
					} else {

						if (CheckStatus.size() < sizeofselection) {

							holder.imgIcon
									.setImageResource(R.drawable.checkbox_tick);
							CheckStatus.add(Cons.ListOfCategory.get(pos)
									.getId());

							CategoryManager cm = new CategoryManager();

							cm.setId(Cons.ListOfCategory.get(pos).getId());
							cm.setCategory_name(Cons.ListOfCategory.get(pos)
									.getCategory_name());
							cm.setCategory_image(Cons.ListOfCategory.get(pos)
									.getCategory_image());
							cm.setCategory_desc(Cons.ListOfCategory.get(pos)
									.getCategory_desc());
							cm.setCreated_at(Cons.ListOfCategory.get(pos)
									.getCreated_at());
							cm.setUpdated_at(Cons.ListOfCategory.get(pos)
									.getUpdated_at());
							cm.setStatus(Cons.ListOfCategory.get(pos)
									.getStatus());
							cm.setChecked(true);

							Cons.ListOfCategory.remove(pos);
							Cons.ListOfCategory.add(pos, cm);
							Log.i("Status YES::",
									""
											+ Cons.ListOfCategory.get(pos)
													.getChecked());
						} else {
							ShowAlertMessage("ChristianBusinessDirectory",
									"you can select " + sizeofselection
											+ " category");
						}
					}

				}
			});
			// .setOnCheckedChangeListener(new OnCheckedChangeListener() {
			//
			// @Override
			// public void onCheckedChanged(CompoundButton buttonView,
			// boolean isChecked) {
			// // TODO Auto-generated method stub
			// if (!isChecked) {
			// holder.imgIcon.setChecked(false);
			// CheckStatus.remove(CheckStatus.size() - 1);
			// CategoryManager cm = new CategoryManager();
			//
			// cm.setId(Cons.ListOfCategory.get(pos).getId());
			// cm.setCategory_name(Cons.ListOfCategory
			// .get(pos).getCategory_name());
			// cm.setCategory_image(Cons.ListOfCategory.get(
			// pos).getCategory_image());
			// cm.setCategory_desc(Cons.ListOfCategory
			// .get(pos).getCategory_desc());
			// cm.setCreated_at(Cons.ListOfCategory.get(pos)
			// .getCreated_at());
			// cm.setUpdated_at(Cons.ListOfCategory.get(pos)
			// .getUpdated_at());
			// cm.setStatus(Cons.ListOfCategory.get(pos)
			// .getStatus());
			// cm.setChecked(false);
			//
			// Cons.ListOfCategory.remove(pos);
			// Cons.ListOfCategory.add(pos, cm);
			// Log.i("Status NOT::", ""
			// + Cons.ListOfCategory.get(pos)
			// .getChecked());
			//
			// } else {
			// holder.imgIcon.setChecked(true);
			// CheckStatus.add(Cons.ListOfCategory.get(pos)
			// .getId());
			//
			// CategoryManager cm = new CategoryManager();
			//
			// cm.setId(Cons.ListOfCategory.get(pos).getId());
			// cm.setCategory_name(Cons.ListOfCategory
			// .get(pos).getCategory_name());
			// cm.setCategory_image(Cons.ListOfCategory.get(
			// pos).getCategory_image());
			// cm.setCategory_desc(Cons.ListOfCategory
			// .get(pos).getCategory_desc());
			// cm.setCreated_at(Cons.ListOfCategory.get(pos)
			// .getCreated_at());
			// cm.setUpdated_at(Cons.ListOfCategory.get(pos)
			// .getUpdated_at());
			// cm.setStatus(Cons.ListOfCategory.get(pos)
			// .getStatus());
			// cm.setChecked(true);
			//
			// Cons.ListOfCategory.remove(pos);
			// Cons.ListOfCategory.add(pos, cm);
			// Log.i("Status YES::", ""
			// + Cons.ListOfCategory.get(pos)
			// .getChecked());
			//
			// }
			// }
			// });
			// convertView.setOnClickListener(new OnClickListener() {
			//
			// @Override
			// public void onClick(View v) {
			// // TODO Auto-generated method stub
			//
			// if (holder.imgIcon.isChecked()) {
			// holder.imgIcon.setChecked(false);
			// CheckStatus.remove(CheckStatus.size() - 1);
			//
			// CategoryManager cm = new CategoryManager();
			//
			// cm.setId(ListOfCategory.get(pos).getId());
			// cm.setCategory_name(ListOfCategory.get(pos)
			// .getCategory_name());
			// cm.setCategory_image(ListOfCategory.get(pos)
			// .getCategory_image());
			// cm.setCategory_desc(ListOfCategory.get(pos)
			// .getCategory_desc());
			// cm.setCreated_at(ListOfCategory.get(pos)
			// .getCreated_at());
			// cm.setUpdated_at(ListOfCategory.get(pos)
			// .getUpdated_at());
			// cm.setStatus(ListOfCategory.get(pos).getStatus());
			// cm.setChecked(false);
			//
			// ListOfCategory.remove(pos);
			// ListOfCategory.add(pos, cm);
			// Log.i("Status ::", ""
			// + ListOfCategory.get(pos).getChecked());
			//
			// } else {
			// holder.imgIcon.setChecked(true);
			// CheckStatus.add(ListOfCategory.get(pos).getId());
			//
			// CategoryManager cm = new CategoryManager();
			//
			// cm.setId(ListOfCategory.get(pos).getId());
			// cm.setCategory_name(ListOfCategory.get(pos)
			// .getCategory_name());
			// cm.setCategory_image(ListOfCategory.get(pos)
			// .getCategory_image());
			// cm.setCategory_desc(ListOfCategory.get(pos)
			// .getCategory_desc());
			// cm.setCreated_at(ListOfCategory.get(pos)
			// .getCreated_at());
			// cm.setUpdated_at(ListOfCategory.get(pos)
			// .getUpdated_at());
			// cm.setStatus(ListOfCategory.get(pos).getStatus());
			// cm.setChecked(true);
			//
			// ListOfCategory.remove(pos);
			// ListOfCategory.add(pos, cm);
			// Log.i("Status ::", ""
			// + ListOfCategory.get(pos).getChecked());
			//
			// }
			// }
			// });

			return convertView;
		}

		class ViewHolder {
			public ImageView imgIcon;
			TextView imgText;
		}
	}

	protected void GetCategoryList() {

		final ProgressDialog dialog;
		dialog = new ProgressDialog(this);
		dialog.setTitle("");
		dialog.setMessage("Please Wait...");
		dialog.setCancelable(false);

		AsyncTask<Void, Void, Boolean> waitForCompletion = new AsyncTask<Void, Void, Boolean>() {

			@Override
			protected void onPreExecute() {
				// TODO Auto-generated method stub
				super.onPreExecute();
				dialog.show();
			}

			@Override
			protected Boolean doInBackground(Void... arg0) {
				// TODO Auto-generated method stub
				Cons.ListOfCategory.clear();
				try {

					HttpClient httpClient = new DefaultHttpClient();
					String url = com.christianbusiness.utils.Constant.CategoryList
							+ "?" + "page=2" + "&isregister=0";
					HttpGet httpGet = new HttpGet(url);
					Log.i("URL", url);

					HttpResponse response = httpClient.execute(httpGet);
					String json = EntityUtils.toString(response.getEntity());
					JSONTokener tokener = new JSONTokener(json);
					JSONObject finalResult = new JSONObject(tokener);
					Log.i("Response Json", "" + finalResult.toString());
					JSONArray obj = finalResult.getJSONArray("data");
					Log.i("Object of Data", obj.toString());
					for (int i = 0; i < obj.length(); i++) {
						CategoryManager cm = new CategoryManager();
						JSONObject objdata = obj.getJSONObject(i);
						cm.setId(objdata.getString("id"));
						cm.setCategory_name(objdata.getString("category_name"));
						cm.setCategory_image("category_image");
						cm.setCategory_desc(objdata.getString("category_desc"));
						cm.setCreated_at(objdata.getString("created_at"));
						cm.setUpdated_at(objdata.getString("updated_at"));
						cm.setStatus(objdata.getString("status"));
						cm.setChecked(false);

						Cons.ListOfCategory.add(cm);

					}

				} catch (ClientProtocolException e) {
					// TODO Auto-generated catch block
					Log.i("Exception",
							"ClientProtocolException : " + e.getMessage());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Log.i("Exception", "IOException : " + e.getMessage());
				} catch (Exception e) {
					// TODO: handle exception
					Log.i("Exception", "Http Response : " + e.getMessage());
				}
				return null;
			}

			@Override
			protected void onPostExecute(Boolean result) {
				// TODO Auto-generated method stub
				list_of_category.setAdapter(mAdapter);
				dialog.dismiss();
			}

		};

		if (isInternetAvailable())
			waitForCompletion.execute();
		else
			Toast.makeText(getApplicationContext(),
					"Internet service not available", Toast.LENGTH_SHORT)
					.show();

	}

	private boolean isInternetAvailable() {
		// TODO Auto-generated method stub
		ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		if (cm.getActiveNetworkInfo() != null)
			return (cm.getActiveNetworkInfo().isConnected() && cm
					.getActiveNetworkInfo().isAvailable());
		else
			return false;
	}

	private void ShowAlertMessage(String Title, String Message) {
		AlertDialog alertDialog = new AlertDialog.Builder(
				ActivityCategoryList.this).create();

		// Setting Dialog Title
		alertDialog.setTitle(Title);

		// Setting Dialog Message
		alertDialog.setMessage(Message);

		// Setting OK Button
		alertDialog.setButton("Ok", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int which) {
				// Write your code here to execute after dialog closed
				dialog.dismiss();
			}
		});

		// Showing Alert Message
		alertDialog.show();
	}
}