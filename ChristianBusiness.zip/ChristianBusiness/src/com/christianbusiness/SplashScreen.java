package com.christianbusiness;

import java.io.IOException;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import com.christianbusiness.utils.Constant;
import com.christianbusiness.preference.PreferenceConnector;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

public class SplashScreen extends Activity {

	final Context context = this;
	String Id, Country_name, Short_name;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.splash);

		if (isInternetAvailable()) {

			GetData();

		} else {
			AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
					context);

			// set title
			alertDialogBuilder.setTitle("Internet Service");

			// set dialog message
			alertDialogBuilder
					.setMessage("Internet Service Not Available In your Device")
					.setCancelable(false)
					.setPositiveButton("OK",
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int id) {
									SplashScreen.this.finish();
								}
							});

			// create alert dialog
			AlertDialog alertDialog = alertDialogBuilder.create();

			// show it
			alertDialog.show();
		}

	}

	public boolean isInternetAvailable() {
		ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		if (cm.getActiveNetworkInfo() != null)
			return (cm.getActiveNetworkInfo().isConnected() && cm
					.getActiveNetworkInfo().isAvailable());
		else
			return false;
	}

	protected void GetData() {
		// TODO Auto-generated method stub

		AsyncTask<Void, Void, Boolean> waitForCompletion = new AsyncTask<Void, Void, Boolean>() {

			@Override
			protected void onPreExecute() {
				// TODO Auto-generated method stub
				super.onPreExecute();

			}

			@Override
			protected Boolean doInBackground(Void... params) {
				// TODO Auto-generated method stub
				Cons.ListCountry.clear();
				try {

					HttpClient httpClient = new DefaultHttpClient();
					String url = Constant.CountryUrl;
					HttpGet httpGet = new HttpGet(url);
					Log.i("URL", url);

					HttpResponse response = httpClient.execute(httpGet);
					String json = EntityUtils.toString(response.getEntity());
					JSONTokener tokener = new JSONTokener(json);
					JSONObject finalResult = new JSONObject(tokener);
					JSONArray dataarrray = finalResult.getJSONArray("data");
					Log.i("Response Json", "" + finalResult.toString());

					if (finalResult.getString("success").equals("1")) {

						for (int i = 0; i < dataarrray.length(); i++) {
							JSONObject jbjdata = dataarrray.getJSONObject(i);
							CountryManager cm = new CountryManager();
							for (int j = 0; j < jbjdata.length(); j++) {

								cm.setId(jbjdata.getString("id"));
								cm.setCountryname(jbjdata
										.getString("countryname"));
								cm.setShort_name(jbjdata
										.getString("short_name"));

							}
							Cons.ListCountry.add(cm);
						}
					}

				} catch (ClientProtocolException e) {
					// TODO Auto-generated catch block
					Log.i("Exception",
							"ClientProtocolException : " + e.getMessage());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Log.i("Exception", "IOException : " + e.getMessage());
				} catch (Exception e) {
					// TODO: handle exception
					Log.i("Exception", "Http Response : " + e.getMessage());
				}
				return null;
			}

			@Override
			protected void onPostExecute(Boolean result) {
				// TODO Auto-generated method stub

				if (PreferenceConnector.readBoolean(getApplicationContext(),
						PreferenceConnector.IS_USER_LOGIN, false)) {
					Intent intent = new Intent(SplashScreen.this,
							ActivityFeatured.class);
					startActivity(intent);

				} else {

					startActivity(new Intent(SplashScreen.this,
							ActivityLogin.class));
				}
				finish();
			}

		};

		if (isInternetAvailable())
			waitForCompletion.execute();
		else
			Toast.makeText(getApplicationContext(),
					"Internet service not available", Toast.LENGTH_SHORT)
					.show();
	}
}
