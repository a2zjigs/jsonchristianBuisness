package com.christianbusiness;

import java.io.IOException;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.json.JSONTokener;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

import com.animation.AnimationLayout;
import com.christianbusiness.preference.PreferenceConnector;
import com.christianbusiness.utils.Constant;

public class ActivityChangePassword extends Activity {

	Button activity_change_password_back_btn;
	Button activity_change_password_change_btn;

	EditText activity_change_password_old_pass_edittxt;
	EditText activity_change_password_new_pass_edittxt;
	EditText activity_change_password_confirm_pass_edittxt;

	String oldpass, newpass, confirmpass, prefPass;
	String finalString;

	protected String[] mStrings = { "Featured Business", "Search Business",
			"Near By Business", "Business Categories", "Favorite Business",
			"Resource", "Edit Profile", "Change Password", "Business Register",
			"GPS Live Map", "Logout" };

	SettingsAdapter madapter;
	ListView mList;

	protected AnimationLayout mChangePassLayout;

	int flag;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_change_password);

		initwidget();

		activity_change_password_back_btn
				.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						// Intent intent = new
						// Intent(ActivityChangePassword.this,
						// ActivityBusinessName.class);
						// startActivity(intent);
						// finish();
						mChangePassLayout.toggleSidebar();
					}
				});

		activity_change_password_change_btn
				.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub

						FeasibilityChecking();

					}
				});
	}

	private void initwidget() {
		activity_change_password_back_btn = (Button) findViewById(R.id.activity_change_password_back_btn);
		activity_change_password_change_btn = (Button) findViewById(R.id.activity_change_password_change_btn);

		activity_change_password_old_pass_edittxt = (EditText) findViewById(R.id.activity_change_password_old_pass_edittxt);
		activity_change_password_new_pass_edittxt = (EditText) findViewById(R.id.activity_change_password_new_pass_edittxt);
		activity_change_password_confirm_pass_edittxt = (EditText) findViewById(R.id.activity_change_password_confirm_pass_edittxt);

		mChangePassLayout = (AnimationLayout) findViewById(R.id.activity_change_password_mainlayout);

		prefPass = PreferenceConnector.readString(getApplicationContext(),
				PreferenceConnector.USER_PASSWORD, "");

		madapter = new SettingsAdapter(getApplicationContext());

		mList = (ListView) findViewById(R.id.sidebar_list);

		mList.setAdapter(madapter);
		mList.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				// TODO Auto-generated method stub
				switch (arg2) {
				case 0:

					mChangePassLayout.toggleSidebar();
					Intent IntentNearby = new Intent(
							ActivityChangePassword.this, ActivityFeatured.class);
					startActivity(IntentNearby);
					finish();
					break;

				case 1:

					mChangePassLayout.toggleSidebar();
					Intent IntentActivitySearch = new Intent(
							ActivityChangePassword.this,
							ActivitySearchOption.class);
					startActivity(IntentActivitySearch);
					finish();

					break;

				case 2:
					mChangePassLayout.toggleSidebar();
					Intent intentchangepasswor2 = new Intent(
							ActivityChangePassword.this,
							ActivityNearByBusiness.class);
					startActivity(intentchangepasswor2);
					finish();

					break;

				case 3:
					mChangePassLayout.toggleSidebar();
					Intent intentchangepasswor = new Intent(
							ActivityChangePassword.this, ActivityEvents.class);
					startActivity(intentchangepasswor);
					finish();
					break;
				case 4:
					mChangePassLayout.toggleSidebar();
					Intent intentfavbusi = new Intent(
							ActivityChangePassword.this,
							ActivityFavouriteBusiness.class);
					startActivity(intentfavbusi);
					finish();

					break;

				case 5:
					mChangePassLayout.toggleSidebar();
					Intent IntentResource = new Intent(
							ActivityChangePassword.this, ActivityResource.class);
					startActivity(IntentResource);
					finish();
					break;
				case 6:
					// Toast.makeText(getApplicationContext(),
					// "Item Selected::" + arg2, Toast.LENGTH_LONG).show();
					mChangePassLayout.toggleSidebar();
					Intent intentchangepasswor3 = new Intent(
							ActivityChangePassword.this,
							ActivityRegistrationUpdate.class);
					startActivity(intentchangepasswor3);
					finish();
					break;

				case 7:
					// Toast.makeText(getApplicationContext(),
					// "Item Selected::" + arg2, Toast.LENGTH_LONG).show();
					mChangePassLayout.toggleSidebar();

					break;

				case 8:
					mChangePassLayout.toggleSidebar();
					Intent regActivity = new Intent(
							ActivityChangePassword.this,
							ActivityRegisterBusiness.class);
					startActivity(regActivity);
					finish();

					break;
				case 9:

					mChangePassLayout.toggleSidebar();
					Intent Intengps = new Intent(ActivityChangePassword.this,
							ActivityGPSLive.class);
					startActivity(Intengps);
					finish();
					break;
				case 10:
					PreferenceConnector.writeBoolean(getApplicationContext(),
							PreferenceConnector.IS_USER_LOGIN, false);

					AlertDialog.Builder alert = new AlertDialog.Builder(
							ActivityChangePassword.this);

					alert.setTitle("ChristianBusinessDirectory");
					alert.setMessage("Are You sure You Want to logout?");

					alert.setPositiveButton("Ok",
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int whichButton) {
									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.EMAIL, "");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.FIRSTNAME, "");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.LASTNAME, "");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.COUNTRYID, "");

									PreferenceConnector
											.writeString(
													getApplicationContext(),
													PreferenceConnector.COUNTRYNAME,
													"");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.STATEID, "");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.STATENAME, "");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.CITYNAME, "");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.CITYID, "");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.BUSINESS_NAME,
											"");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.USER_ID, "");
									Intent intent = new Intent(
											ActivityChangePassword.this,
											ActivityLogin.class);
									startActivity(intent);
									ActivityChangePassword.this.finish();
								}

							});
					alert.setNegativeButton("Cancel",
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int which) {
									// TODO Auto-generated method stub

								}

							});

					alert.show();

					break;
				default:
					break;
				}

			}
		});

	}

	protected void changePassword() {

		final ProgressDialog dialog;
		dialog = new ProgressDialog(this);
		dialog.setTitle("");
		dialog.setMessage("Please Wait...");
		dialog.setCancelable(false);

		AsyncTask<Void, Void, Boolean> waitForCompletion = new AsyncTask<Void, Void, Boolean>() {

			@Override
			protected void onPreExecute() {
				// TODO Auto-generated method stub
				super.onPreExecute();
				dialog.show();
			}

			boolean isChangePasswordSuccess = false;

			@Override
			protected Boolean doInBackground(Void... arg0) {
				// TODO Auto-generated method stub
				try {
					HttpClient httpClient = new DefaultHttpClient();
					// String url = Constant.ChangePassUrl;

					String uname = PreferenceConnector.readString(
							getApplicationContext(),
							PreferenceConnector.USER_NAME, "");

					Log.v("Username :", uname);

					String url = Constant.ChangePassUrl
							+ "?username="
							+ uname
							+ "&currentpassword="
							+ oldpass
							+ "&newpassword="
							+ newpass
							+ "&user_id="
							+ PreferenceConnector.readString(
									getApplicationContext(),
									PreferenceConnector.USER_ID, "");

					HttpGet httpGet = new HttpGet(url);
					Log.i("URL", url);

					HttpResponse response = httpClient.execute(httpGet);
					String json = EntityUtils.toString(response.getEntity());
					JSONTokener tokener = new JSONTokener(json);
					Log.i("String response", "" + json);
					JSONObject finalResult = new JSONObject(tokener);
					Log.i("Response Json", "" + finalResult.toString());

					if (finalResult.has("success")) {
						String mSuccess = finalResult.getString("success");
						if (mSuccess.equals("1")) {
							flag = 1;
							isChangePasswordSuccess = true;
						} else {
							flag = 0;

						}
					} else {
						flag = -1;
					}

				} catch (ClientProtocolException e) {
					// TODO Auto-generated catch block
					Log.i("Exception",
							"ClientProtocolException : " + e.getMessage());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Log.i("Exception", "IOException : " + e.getMessage());
				} catch (Exception e) {
					// TODO: handle exception
					Log.i("Exception", "Http Response : " + e.getMessage());
				}
				return null;
			}

			@Override
			protected void onPostExecute(Boolean result) {
				// TODO Auto-generated method stub
				if (isChangePasswordSuccess) {

					// Toast.makeText(getApplicationContext(),
					// "Successfully ChangePassword", Toast.LENGTH_LONG)
					// .show();

					AlertDialog.Builder alert = new AlertDialog.Builder(
							ActivityChangePassword.this);

					alert.setTitle("ChristianBusinessDirectory");
					alert.setMessage("ChangePassword Successfully.");

					alert.setPositiveButton("Ok",
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int whichButton) {
									Intent Assignemtnintent = new Intent(
											ActivityChangePassword.this,
											ActivityLogin.class);
									startActivity(Assignemtnintent);

									ActivityChangePassword.this.finish();
								}

							});

					alert.show();

				} else {
					// Toast.makeText(getApplicationContext(),
					// "Unauthorized data", Toast.LENGTH_LONG).show();

					AlertDialog.Builder alert = new AlertDialog.Builder(
							ActivityChangePassword.this);

					alert.setTitle("ChristianBusinessDirectory");
					alert.setMessage("Unauthorized data");

					alert.setPositiveButton("Ok",
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int whichButton) {

								}

							});

					alert.show();
				}
				dialog.dismiss();
			}

		};

		if (isInternetAvailable())
			waitForCompletion.execute();
		else
			Toast.makeText(getApplicationContext(),
					"Internet service not available", Toast.LENGTH_SHORT)
					.show();

	}

	protected void FeasibilityChecking() {
		// TODO Auto-generated method stub
		oldpass = activity_change_password_old_pass_edittxt.getText()
				.toString();
		newpass = activity_change_password_new_pass_edittxt.getText()
				.toString();
		confirmpass = activity_change_password_confirm_pass_edittxt.getText()
				.toString();

		if (oldpass.equals("") || newpass.equals("") || confirmpass.equals("")) {
			// Toast.makeText(getApplicationContext(),
			// "Please check blank field",
			// Toast.LENGTH_SHORT).show();
			AlertDialog.Builder alert = new AlertDialog.Builder(
					ActivityChangePassword.this);

			alert.setTitle("ChristianBusinessDirectory");
			alert.setMessage("Please Enter all fields.");

			alert.setPositiveButton("Ok",
					new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog,
								int whichButton) {

						}

					});

			alert.show();

		} else {
			if (oldpass.equals(prefPass)) {
				if (newpass.length() >= 8) {

					if (newpass.equals(confirmpass)) {
						changePassword();
					} else {
						// Toast.makeText(getApplicationContext(),
						// "Please check confirm password", Toast.LENGTH_SHORT)
						// .show();
						AlertDialog.Builder alert = new AlertDialog.Builder(
								ActivityChangePassword.this);

						alert.setTitle("ChristianBusinessDirectory");
						alert.setMessage("Your New Password and confirmation password do not match.");

						alert.setPositiveButton("Ok",
								new DialogInterface.OnClickListener() {
									public void onClick(DialogInterface dialog,
											int whichButton) {

									}

								});

						alert.show();

					}
				} else {
					// Toast.makeText(getApplicationContext(),
					// "password length small", Toast.LENGTH_SHORT).show();
					AlertDialog.Builder alert = new AlertDialog.Builder(
							ActivityChangePassword.this);

					alert.setTitle("ChristianBusinessDirectory");
					alert.setMessage("Password should not be less than 8 characters.");

					alert.setPositiveButton("Ok",
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int whichButton) {

								}

							});

					alert.show();
				}
			} else {
				AlertDialog.Builder alert = new AlertDialog.Builder(
						ActivityChangePassword.this);

				alert.setTitle("ChristianBusinessDirectory");
				alert.setMessage("This data is not available.");

				alert.setPositiveButton("Ok",
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog,
									int whichButton) {

							}

						});

				alert.show();
			}

		}
	}

	private boolean isInternetAvailable() {
		// TODO Auto-generated method stub
		ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		if (cm.getActiveNetworkInfo() != null)
			return (cm.getActiveNetworkInfo().isConnected() && cm
					.getActiveNetworkInfo().isAvailable());
		else
			return false;
	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
	}

	public class SettingsAdapter extends BaseAdapter {

		Context mContext;

		public SettingsAdapter(Context c) {
			mContext = c;
		}

		public int getCount() {
			return mStrings.length;
		}

		public Object getItem(int pos) {
			return pos;
		}

		public long getItemId(int pos) {
			return pos;
		}

		public View getView(final int pos, View convertView, ViewGroup parent) {
			if (convertView == null)
				convertView = View.inflate(mContext, R.layout.row_layout_file,
						null);

			final ViewHolder holder = new ViewHolder();

			holder.imgText = (TextView) convertView
					.findViewById(R.id.row_layout_file_text_title);
			holder.imgText.setText(mStrings[pos]);
			return convertView;
		}

		class ViewHolder {
			public ImageView imgIcon, imgright;
			TextView imgText;
		}
	}
}