package com.christianbusiness;

import java.io.ByteArrayOutputStream;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;

public class ActivityAddLogo extends Activity {

	protected static final int CAMERA_REQUEST = 0;
	Button btn_back, btn_next;
	public static ImageView img_view;
	public static String Base64ofImage;
	public static Bitmap photo;
	int RESULT_LOAD_IMAGE = 2;

	protected void onCreate(android.os.Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_add_logo);
		initwidget();
		img_view.setImageBitmap(photo);

		btn_back.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				finish();
				overridePendingTransition(R.anim.trans_right_in,
						R.anim.trans_right_out);
			}
		});

		btn_next.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent Intentterms = new Intent(ActivityAddLogo.this,
						ActivityTermsAndConditions.class);
				startActivity(Intentterms);
				overridePendingTransition(R.anim.trans_left_in,
						R.anim.trans_left_out);
			}
		});

		img_view.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				// Intent cameraIntent = new Intent(
				// android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
				// startActivityForResult(cameraIntent, CAMERA_REQUEST);
				Intent i = new Intent(ActivityAddLogo.this, CameraDialog.class);

				startActivityForResult(i, RESULT_LOAD_IMAGE);
				overridePendingTransition(R.anim.push_up_in, R.anim.stay);

			}
		});
	};

	private void initwidget() {
		btn_back = (Button) findViewById(R.id.activity_add_logo_back_btn);
		btn_next = (Button) findViewById(R.id.activity_add_logo_next_btn);
		img_view = (ImageView) findViewById(R.id.activity_add_logo_imageView);
	}

	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		finish();
		overridePendingTransition(R.anim.trans_right_in, R.anim.trans_right_out);
		super.onBackPressed();
	}

	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (requestCode == CAMERA_REQUEST && resultCode == RESULT_OK) {
			
			Bitmap photo = (Bitmap) data.getExtras().get("data");
			img_view.setImageBitmap(photo);
			Base64ofImage = encodeTobase64(photo);
			
		}
	}

	public static String encodeTobase64(Bitmap image) {
		Bitmap immagex = image;
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		immagex.compress(Bitmap.CompressFormat.JPEG, 50, baos);
		byte[] b = baos.toByteArray();
		String imageEncoded = Base64.encodeToString(b, Base64.DEFAULT);

		Log.i("LOOK", imageEncoded);
		return imageEncoded;
	}
}
