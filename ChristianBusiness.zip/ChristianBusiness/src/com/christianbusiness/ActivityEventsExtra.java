package com.christianbusiness;

import java.io.IOException;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import com.christianbusiness.utils.Constant;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class ActivityEventsExtra extends Activity {

	ListView listView;
	CustomBaseAdapter adapter;
	Button back, hide;
	TextView heading;
	String heading_Name;
	String url;
	public static int position;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_events);

		GetChurches();
		heading = (TextView) findViewById(R.id.activity_events_heading);
		heading.setGravity(Gravity.CENTER_VERTICAL | Gravity.CENTER_HORIZONTAL);
		heading_Name = getIntent().getStringExtra("Name");

		if (getIntent().hasExtra("Name")) {
			heading.setText(heading_Name);
		}

		back = (Button) findViewById(R.id.activity_events_back_btn);
		hide = (Button) findViewById(R.id.activity_events_list_btn);
		hide.setVisibility(View.GONE);
		back.setVisibility(View.VISIBLE);
		back.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				finish();
				overridePendingTransition(R.anim.trans_right_in,
						R.anim.trans_right_out);

			}
		});
		listView = (ListView) findViewById(R.id.activity_events_listview);
		adapter = new CustomBaseAdapter(this);
		listView.setAdapter(adapter);

		listView.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				// TODO Auto-generated method stub
				position = arg2;
				Intent ActivityEvents = new Intent(ActivityEventsExtra.this,
						ActivityEventExtraDetails.class);
				ActivityEvents.putExtra("Name", Cons.ListChurch.get(position)
						.getBusiness_name());
				startActivity(ActivityEvents);
				overridePendingTransition(R.anim.trans_left_in,
						R.anim.trans_left_out);
				// finish();
			}
		});

	}

	public class CustomBaseAdapter extends BaseAdapter {

		Context context;
		List<RowItem> rowItems;

		public CustomBaseAdapter(Context context) {
			this.context = context;

		}

		/* private view holder class */
		private class ViewHolder {
			TextView custom_raw_activity_events_names;

		}

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return Cons.ListChurch.size();
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			ViewHolder holder = null;

			LayoutInflater mInflater = (LayoutInflater) context
					.getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
			if (convertView == null) {
				convertView = mInflater.inflate(
						R.layout.custom_raw_activity_events, null);
				holder = new ViewHolder();
				holder.custom_raw_activity_events_names = (TextView) convertView
						.findViewById(R.id.custom_raw_activity_events_names);
				holder.custom_raw_activity_events_names
						.setGravity(Gravity.CENTER);

				convertView.setTag(holder);
			} else {
				holder = (ViewHolder) convertView.getTag();
			}

			holder.custom_raw_activity_events_names.setText(Cons.ListChurch
					.get(position).getBusiness_name());

			return convertView;
		}

		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return 0;
		}

	}

	protected void GetChurches() {

		final ProgressDialog dialog;
		dialog = new ProgressDialog(this);
		dialog.setTitle("");
		dialog.setMessage("Please Wait...");
		dialog.setCancelable(false);

		AsyncTask<Void, Void, Boolean> waitForCompletion = new AsyncTask<Void, Void, Boolean>() {

			@Override
			protected void onPreExecute() {
				// TODO Auto-generated method stub
				super.onPreExecute();
				dialog.show();
			}

			@Override
			protected Boolean doInBackground(Void... arg0) {
				// TODO Auto-generated method stub
				Cons.ListChurch.clear();

				try {

					HttpClient httpClient = new DefaultHttpClient();

					Log.i("Heading Name:", heading_Name);
					//url = Constant.GetURL + Cons.ListOfCategory.get(position).getLinkParam();
					
					if (heading_Name.equals("Churches")) {
						url = Constant.GetURL + "churches";

					} else if (heading_Name.equals("Schools")) {
						url = Constant.GetURL + "schools";

					} else if (heading_Name.equals("Community Organisations")) {
						url = Constant.GetURL + "community_organisations";
					}

					HttpGet httpGet = new HttpGet(url);
					Log.i("URL", url);

					HttpResponse response = httpClient.execute(httpGet);
					String json = EntityUtils.toString(response.getEntity());
					JSONTokener tokener = new JSONTokener(json);
					JSONObject finalResult = new JSONObject(tokener);
					Log.i("Response Json", "" + finalResult.toString());
					JSONArray obj = finalResult.getJSONArray("data");
					Log.i("Object of Data", obj.toString());
					for (int i = 0; i < obj.length(); i++) {

						ChurchManager chm = new ChurchManager();
						JSONObject objdata = obj.getJSONObject(i);

						chm.setId(objdata.getString("id"));
						chm.setBusiness_name(objdata.getString("business_name"));

						Cons.ListChurch.add(chm);

					}

				} catch (ClientProtocolException e) {
					// TODO Auto-generated catch block
					Log.i("Exception",
							"ClientProtocolException : " + e.getMessage());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Log.i("Exception", "IOException : " + e.getMessage());
				} catch (Exception e) {
					// TODO: handle exception
					Log.i("Exception", "Http Response : " + e.getMessage());
				}
				return null;
			}

			@Override
			protected void onPostExecute(Boolean result) {
				// TODO Auto-generated method stub
				listView.setAdapter(adapter);
				dialog.dismiss();
			}

		};

		if (isInternetAvailable())
			waitForCompletion.execute();
		else
			Toast.makeText(getApplicationContext(),
					"Internet service not available", Toast.LENGTH_SHORT)
					.show();

	}

	private boolean isInternetAvailable() {
		// TODO Auto-generated method stub
		ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		if (cm.getActiveNetworkInfo() != null)
			return (cm.getActiveNetworkInfo().isConnected() && cm
					.getActiveNetworkInfo().isAvailable());
		else
			return false;
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		// heading_Name = getIntent().getStringExtra("Name");
	}
}