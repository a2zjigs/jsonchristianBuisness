package com.christianbusiness;

import java.io.IOException;
import java.lang.reflect.Member;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import com.chirstianbusiness.classes.MemberShipLevel;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.JsonReader;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class ActivityMembershiplevel extends Activity {

	Button activity_membership_level_back_btn;
	Button activity_membership_level_next_btn;

	RadioButton radio_btn_basic, radio_btn_sponser, radio_btn_premium,
			radio_btn_deluxe;

	RadioGroup radio_group;
	public static int membershiplevel;

	String basic, sponsor, premium, deluxe;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_membership_level);

		initwidget();

		GetMemberShipLevel();

		SharedPreferences handle = getApplicationContext()
				.getSharedPreferences("ABC", 0);
		int membership_checkbox = handle.getInt("membership_checkbox", 0); // getting
																			// String

		if (membership_checkbox != 0) {
			if (membership_checkbox == 1) {
				radio_btn_basic.setChecked(true);
			} else if (membership_checkbox == 2) {
				radio_btn_sponser.setChecked(true);
			} else if (membership_checkbox == 3) {
				radio_btn_premium.setChecked(true);
			} else if (membership_checkbox == 4) {
				radio_btn_deluxe.setChecked(true);
			}
		}
		// basic = radio_btn_basic.getText().toString();
		// deluxe = radio_btn_deluxe.getText().toString();
		// premium = radio_btn_premium.getText().toString();
		// sponsor = radio_btn_sponser.getText().toString();

		activity_membership_level_back_btn
				.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub

						finish();

						overridePendingTransition(R.anim.trans_right_in,
								R.anim.trans_right_out);
					}
				});

		activity_membership_level_next_btn
				.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub

						int selectedId = radio_group.getCheckedRadioButtonId();
						getAtmos(selectedId);
						Intent activityDescrption = new Intent(
								ActivityMembershiplevel.this,
								ActivityDescription.class);
						startActivity(activityDescrption);
						overridePendingTransition(R.anim.trans_left_in,
								R.anim.trans_left_out);
					}
				});

	}

	private void initwidget() {
		activity_membership_level_back_btn = (Button) findViewById(R.id.activity_membership_level_back_btn);
		activity_membership_level_next_btn = (Button) findViewById(R.id.activity_membership_level_next_btn);

		radio_btn_basic = (RadioButton) findViewById(R.id.activity_membership_level_radio_basic);
		radio_btn_deluxe = (RadioButton) findViewById(R.id.activity_membership_level_radio_deluxe);
		radio_btn_premium = (RadioButton) findViewById(R.id.activity_membership_level_radio_premium);
		radio_btn_sponser = (RadioButton) findViewById(R.id.activity_membership_level_radio_sponsor);

		radio_group = (RadioGroup) findViewById(R.id.activity_memebership_level_radio_group);

	}

	private void getAtmos(int id) {
		switch (id) {
		case R.id.activity_membership_level_radio_basic:
			ActivityDescription.textlimit = Integer.parseInt(Cons.ListofMember
					.get(0).getDesc_limit());

			// ActivityDescription.StringTitle = "Basic";
			ActivityDescription.StringTitle = Cons.ListofMember.get(0)
					.getPlan_name();

			// membershiplevel = 1;

			membershiplevel = Integer.parseInt(Cons.ListofMember.get(0)
					.getCategory_limit());

			// ActivityCategoryList.Stringmembership = "Basic";

			ActivityCategoryList.Stringmembership = Cons.ListofMember.get(0)
					.getPlan_name();

			// ActivityCategoryList.sizeofselection = 1;

			ActivityCategoryList.sizeofselection = Integer
					.parseInt(Cons.ListofMember.get(0).getCategory_limit());

			break;
		case R.id.activity_membership_level_radio_deluxe:
			// ActivityDescription.textlimit = 2500;
			// ActivityDescription.StringTitle = "Deluxe";
			// membershiplevel = 2;
			// ActivityCategoryList.sizeofselection = 5;
			// ActivityCategoryList.Stringmembership = "Deluxe";

			ActivityDescription.textlimit = Integer.parseInt(Cons.ListofMember
					.get(3).getDesc_limit());

			ActivityDescription.StringTitle = Cons.ListofMember.get(3)
					.getPlan_name();

			membershiplevel = Integer.parseInt(Cons.ListofMember.get(3)
					.getCategory_limit());

			ActivityCategoryList.Stringmembership = Cons.ListofMember.get(3)
					.getPlan_name();

			ActivityCategoryList.sizeofselection = Integer
					.parseInt(Cons.ListofMember.get(3).getCategory_limit());

			break;
		case R.id.activity_membership_level_radio_premium:
			// ActivityDescription.textlimit = 1000;
			// ActivityDescription.StringTitle = "Premium";
			// membershiplevel = 3;
			// ActivityCategoryList.sizeofselection = 3;
			// ActivityCategoryList.Stringmembership = "Premium";

			ActivityDescription.textlimit = Integer.parseInt(Cons.ListofMember
					.get(2).getDesc_limit());

			ActivityDescription.StringTitle = Cons.ListofMember.get(2)
					.getPlan_name();

			membershiplevel = Integer.parseInt(Cons.ListofMember.get(2)
					.getCategory_limit());

			ActivityCategoryList.Stringmembership = Cons.ListofMember.get(2)
					.getPlan_name();

			ActivityCategoryList.sizeofselection = Integer
					.parseInt(Cons.ListofMember.get(2).getCategory_limit());

			break;
		case R.id.activity_membership_level_radio_sponsor:
			// ActivityDescription.StringTitle = "Sponsor";
			// ActivityCategoryList.Stringmembership = "Sponsor";
			// ActivityCategoryList.sizeofselection = 2;
			// membershiplevel = 4;
			// ActivityDescription.textlimit = 500;

			ActivityDescription.textlimit = Integer.parseInt(Cons.ListofMember
					.get(1).getDesc_limit());

			ActivityDescription.StringTitle = Cons.ListofMember.get(1)
					.getPlan_name();

			membershiplevel = Integer.parseInt(Cons.ListofMember.get(1)
					.getCategory_limit());

			ActivityCategoryList.Stringmembership = Cons.ListofMember.get(1)
					.getPlan_name();

			ActivityCategoryList.sizeofselection = Integer
					.parseInt(Cons.ListofMember.get(1).getCategory_limit());
			break;

		}

	}

	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		finish();
		overridePendingTransition(R.anim.trans_right_in, R.anim.trans_right_out);
		super.onBackPressed();
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();

	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();

		int value = 0;
		if (radio_btn_basic.isChecked()) {
			value = 1;
		} else if (radio_btn_sponser.isChecked()) {
			value = 2;
		} else if (radio_btn_premium.isChecked()) {
			value = 3;
		} else if (radio_btn_deluxe.isChecked()) {
			value = 4;
		}

		SharedPreferences socialhandle = getApplicationContext()
				.getSharedPreferences("ABC", 0); // 0 - for private mode
		Editor editorSocial = socialhandle.edit();

		editorSocial.putInt("membership_checkbox", value);

		editorSocial.commit(); // commit changes
	}

	private void GetMemberShipLevel() {

		final ProgressDialog dialog;
		dialog = new ProgressDialog(this);
		dialog.setTitle("");

		dialog.setMessage("Please Wait...");
		dialog.setCancelable(false);

		AsyncTask<Void, Void, Boolean> waitForCompletion = new AsyncTask<Void, Void, Boolean>() {

			@Override
			protected void onPreExecute() {
				// TODO Auto-generated method stub
				super.onPreExecute();
				dialog.show();
			}

			@Override
			protected Boolean doInBackground(Void... params) {
				try {
					Cons.ListofMember.clear();
					HttpClient httpClient = new DefaultHttpClient();
					String url = com.christianbusiness.utils.Constant.GetMemberShipLevel;

					HttpGet httpGet = new HttpGet(url);

					HttpResponse response = httpClient.execute(httpGet);
					String json = EntityUtils.toString(response.getEntity());
					JSONTokener tokener = new JSONTokener(json);
					JSONObject finalResult = new JSONObject(tokener);
					Log.i("Response Json", "" + finalResult.toString());
					JSONArray obj = finalResult.getJSONArray("data");

					for (int i = 0; i < obj.length(); i++) {

						JSONObject jobjdata = obj.getJSONObject(i);
						MemberShipLevel msl = new MemberShipLevel();

						if (jobjdata.has("id")) {
							msl.setId(jobjdata.getString("id"));
						} else {
							msl.setId("N.A");
						}

						if (jobjdata.has("plan_name")) {
							msl.setPlan_name(jobjdata.getString("plan_name"));
						} else {
							msl.setPlan_name("N.A");
						}

						if (jobjdata.has("plan_price")) {
							msl.setPlan_price(jobjdata.getString("plan_price"));
						} else {
							msl.setPlan_price("N.A");
						}

						if (jobjdata.has("desc_limit")) {
							msl.setDesc_limit(jobjdata.getString("desc_limit"));
						} else {
							msl.setDesc_limit("N.A");
						}

						if (jobjdata.has("category_limit")) {
							msl.setCategory_limit(jobjdata
									.getString("category_limit"));
						} else {
							msl.setCategory_limit("N.A");
						}

						Cons.ListofMember.add(msl);

						Log.i("No:", "" + i);
						Log.i("plan_name", jobjdata.getString("plan_name"));
						Log.i("plan_price", jobjdata.getString("plan_price"));
						Log.i("desc_limit", jobjdata.getString("desc_limit"));
						Log.i("category_limit",
								jobjdata.getString("category_limit"));

					}

				} catch (ClientProtocolException e) {
					// TODO Auto-generated catch block
					Log.i("Exception",
							"ClientProtocolException : " + e.getMessage());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Log.i("Exception", "IOException : " + e.getMessage());
				} catch (Exception e) {
					// TODO: handle exception
					Log.i("Exception", "Http Response : " + e.getMessage());
				}
				return null;
			};

			@Override
			protected void onPostExecute(Boolean result) {

				dialog.dismiss();

			}
		};
		if (isInternetAvailable())
			waitForCompletion.execute();
		else
			Toast.makeText(getApplicationContext(),
					"Internet service not available", Toast.LENGTH_SHORT)
					.show();
	}

	public boolean isInternetAvailable() {
		ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		if (cm.getActiveNetworkInfo() != null)
			return (cm.getActiveNetworkInfo().isConnected() && cm
					.getActiveNetworkInfo().isAvailable());
		else
			return false;
	}
}
