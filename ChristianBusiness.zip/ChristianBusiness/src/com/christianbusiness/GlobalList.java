package com.christianbusiness;

import java.util.ArrayList;

import android.view.Menu;

public class GlobalList {
	public static ArrayList<Menu> menus;
	static Menu menu;
	static Menu menu1;
	static Menu menu2;
	static Menu menu3;

	public static ArrayList<Menu> getMenuCategories() {

		menu.add("First");
		menu1.add("Seconds");
		menu2.add("Third");
		menu3.add("Fourth");

		menus.add(menu);
		menus.add(menu1);
		menus.add(menu2);
		menus.add(menu3);

		return menus;
	}
}
