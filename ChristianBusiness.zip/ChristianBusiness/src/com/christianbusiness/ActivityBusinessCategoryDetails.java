package com.christianbusiness;

import java.io.IOException;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import android.app.ProgressDialog;
import android.content.Context;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.chirstianbusiness.classes.GPSTracker;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class ActivityBusinessCategoryDetails extends
		android.support.v4.app.FragmentActivity {

	Button activity_business_details_list_btn;

	GoogleMap find_us_map;

	TextView txt_businessname, txt_businescategory, txt_businessnamedesc,
			txt_title, txt_businesdesc, txt_address, txt_contactno,
			txt_website, txt_website_title;

	static String CategoryName;
	String CountryName, StateName, Cityname;
	String cityString = "";
	static String Latitude, longitude;
	GPSTracker gps;
	LatLng DUBLIN;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_business_details);

		gps = new GPSTracker(ActivityBusinessCategoryDetails.this);

		initwidget();
		getdata();

		SupportMapFragment fragment = (SupportMapFragment) getSupportFragmentManager()
				.findFragmentById(R.id.activity_findus_maps);

		find_us_map = fragment.getMap();

		if (Cons.ListofBusinesscategorywise.get(ActivityEventDetails.position)
				.getWebsite_name().equals("")) {

			txt_website_title.setVisibility(View.GONE);
			txt_website.setVisibility(View.GONE);
			fragment.getView().setVisibility(View.GONE);

		} else {
			txt_website.setText(Cons.ListofBusinesscategorywise.get(
					ActivityEventDetails.position).getWebsite_name());
		}

		// if(PreferenceConnector
		// .readString(getApplicationContext(),
		// PreferenceConnector.MEMBERSHIP_ID, "").equals("1"))
		// {
		// txt_website.setVisibility(View.GONE);
		//
		// }

		if (Latitude == null || Latitude.trim().equals("")) {
			if (gps.canGetLocation()) {

				Latitude = String.valueOf(gps.getLatitude());
				longitude = String.valueOf(gps.getLongitude());

			}
		}

		if (longitude == null || longitude.trim().equals("")) {
			if (gps.canGetLocation()) {

				Latitude = String.valueOf(gps.getLatitude());
				longitude = String.valueOf(gps.getLongitude());

			}
		}

		DUBLIN = new LatLng(Double.valueOf(Latitude), Double.valueOf(longitude));

		find_us_map
				.addMarker(new MarkerOptions()
						.position(DUBLIN)
						.title(Cons.ListofBusinesscategorywise.get(
								ActivityEventDetails.position)
								.getBusiness_name())
						.snippet(
								Cons.ListofBusinesscategorywise.get(
										ActivityEventDetails.position)
										.getDescription())
						.icon(BitmapDescriptorFactory
								.defaultMarker(BitmapDescriptorFactory.HUE_VIOLET)));

		find_us_map.moveCamera(CameraUpdateFactory.newLatLng(DUBLIN));
		find_us_map.animateCamera(CameraUpdateFactory.zoomTo(10));

		activity_business_details_list_btn
				.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						finish();
					}
				});
	}

	private void initwidget() {
		// TODO Auto-generated method stub
		activity_business_details_list_btn = (Button) findViewById(R.id.activity_business_btn_back);

		txt_title = (TextView) findViewById(R.id.activity_business_details_heading);
		txt_businessname = (TextView) findViewById(R.id.activity_business_details_businessname);
		txt_businescategory = (TextView) findViewById(R.id.activity_business_details_businesscategory);
		txt_businesdesc = (TextView) findViewById(R.id.activity_business_details_businessdesc);
		txt_address = (TextView) findViewById(R.id.activity_business_details_businessaddresss);
		txt_contactno = (TextView) findViewById(R.id.activity_business_details_businesscontactno);
		txt_website = (TextView) findViewById(R.id.activity_business_details_businesswebsite);
		txt_website_title = (TextView) findViewById(R.id.activity_business_details_businesswebsite_title);

		txt_title.setText(Cons.ListofBusinesscategorywise.get(
				ActivityEventDetails.position).getBusiness_name());

		txt_businessname.setText(Cons.ListofBusinesscategorywise.get(
				ActivityEventDetails.position).getBusiness_name());

		txt_businescategory.setText(Cons.ListofFeature.get(
				ActivityNearByBusiness.posofrecord)
				.getFk_directory_category_names());

		txt_businesdesc.setText(Cons.ListofBusinesscategorywise.get(
				ActivityEventDetails.position).getDescription());

		// txt_address.setText(Cons.ListofBusinesscategorywise.get(
		// ActivityEventDetails.position).getStreet_name_number()
		// + "\n"
		// + Cons.ListofBusinesscategorywise.get(
		// ActivityEventDetails.position).getFk_city_name()
		// + ","
		// + Cons.ListofBusinesscategorywise.get(
		// ActivityEventDetails.position).getFk_state_name()
		// + ","
		// + Cons.ListofBusinesscategorywise.get(
		// ActivityEventDetails.position).getFk_country_name()
		// + "-"
		// + Cons.ListofBusinesscategorywise.get(
		// ActivityEventDetails.position).getPostcode());

		txt_contactno.setText(Cons.ListofBusinesscategorywise.get(
				ActivityEventDetails.position).getBusiness_phone());

		Latitude = Cons.ListofBusinesscategorywise.get(
				ActivityEventDetails.position).getLatitude();
		longitude = Cons.ListofBusinesscategorywise.get(
				ActivityEventDetails.position).getLongitude();

		// bussinessphn == null
		// || bussinessphn.trim().equals("")

	}

	private void getdata() {

		final ProgressDialog dialog;
		dialog = new ProgressDialog(this);
		dialog.setTitle("");

		dialog.setMessage("Please Wait...");
		dialog.setCancelable(false);

		AsyncTask<Void, Void, Boolean> waitForCompletion = new AsyncTask<Void, Void, Boolean>() {

			@Override
			protected void onPreExecute() {
				// TODO Auto-generated method stub
				super.onPreExecute();
				dialog.show();
			}

			@Override
			protected Boolean doInBackground(Void... params) {
				try {

					HttpClient httpClient = new DefaultHttpClient();
					String url = com.christianbusiness.utils.Constant.GetSelectedBusiness
							+ Cons.ListofBusinesscategorywise.get(
									ActivityEventDetails.position).getId();

					HttpGet httpGet = new HttpGet(url);

					HttpResponse response = httpClient.execute(httpGet);
					String json = EntityUtils.toString(response.getEntity());
					JSONTokener tokener = new JSONTokener(json);
					JSONObject finalResult = new JSONObject(tokener);

					JSONObject obj = finalResult.getJSONObject("data");

					CountryName = obj.getString("fk_country_name");
					StateName = obj.getString("fk_state_name");
					// Cityname = obj.getString("fk_city_name");
					JSONArray cityNames = obj.getJSONArray("fk_city");
					int n = cityNames.length();

					for (int j = 0; j < n; j++) {

						// if(j==n-1)
						// {
						cityString += cityNames.get(j) + ",";
						// } else {
						// cityString +=cityNames.get(j);
						// }

					}

					CategoryName = obj.getString("fk_directory_names");

				} catch (ClientProtocolException e) {
					// TODO Auto-generated catch block
					Log.i("Exception",
							"ClientProtocolException : " + e.getMessage());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Log.i("Exception", "IOException : " + e.getMessage());
				} catch (Exception e) {
					// TODO: handle exception
					Log.i("Exception", "Http Response : " + e.getMessage());
				}
				return null;
			};

			@Override
			protected void onPostExecute(Boolean result) {

				dialog.dismiss();

				txt_businescategory.setText(CategoryName);
				txt_address.setText(Cons.ListofFeature.get(
						ActivityFavouriteBusiness.posofrecord)
						.getStreet_name_number()
						+ "\n"
						+ cityString
						+ StateName
						+ ","
						+ CountryName
						+ "-"
						+ Cons.ListofFeature.get(
								ActivityFavouriteBusiness.posofrecord)
								.getPostcode());

			}
		};
		if (isInternetAvailable())
			waitForCompletion.execute();
		else
			Toast.makeText(getApplicationContext(),
					"Internet service not available", Toast.LENGTH_SHORT)
					.show();
	}

	public boolean isInternetAvailable() {
		ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		if (cm.getActiveNetworkInfo() != null)
			return (cm.getActiveNetworkInfo().isConnected() && cm
					.getActiveNetworkInfo().isAvailable());
		else
			return false;
	}
}