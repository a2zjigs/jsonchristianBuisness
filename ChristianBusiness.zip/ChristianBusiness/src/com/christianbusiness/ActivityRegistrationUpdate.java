package com.christianbusiness;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import com.animation.AnimationLayout;
import com.christianbusiness.preference.PreferenceConnector;
import com.christianbusiness.utils.Constant;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class ActivityRegistrationUpdate extends Activity {

	Button activity_update_registration_back;
	Button activity_update_registration_submit_btn;

	EditText activity_update_registration_first_name_edittxt;
	EditText activity_update_regitration_last_name_edittxt;
	EditText activity_update_registration_business_name_edittxt;
	EditText activity_update_registration_email_edittxt;

	TextView activity_update_registration_state_textview;
	TextView activity_update_registration_country_textview;
	TextView activity_update_registration_city_textview;

	EditText activity_update_registration_username_edittxt;

	String finalString;
	int flag;
	String firstname, lastname, business_name, email, state, country, city,
			username;
	String prefUname, prefPass, prefEmail, prefFirstName, prefLastName,
			prefCountry, prefCountry_ID, prefState, prefState_ID, prefCity,
			prefCity_ID, prefBusinessName, prefUserID;

	String State_Id, State_name, State_shortname;
	String CountryID, StateID, CityID;

	protected AnimationLayout mLayout;

	protected String[] mStrings = { "Featured Business", "Search Business",
			"Near By Business", "Business Categories", "Favorite Business",
			"Resource", "Edit Profile", "Change Password", "Business Register",
			"GPS Live Map", "Logout" };

	SettingsAdapter madapter;
	ListView mList;

	Dialog dialog;

	List<String> listcountry;

	CountryAdapter mAdapter;
	CityAdapter CAdapter;
	StateAdapter SAdapter;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_update_data);

		initwidget();
		CAdapter = new CityAdapter(getApplicationContext());
		SAdapter = new StateAdapter(getApplicationContext());

		activity_update_registration_back
				.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {

						mLayout.toggleSidebar();
					}
				});
		activity_update_registration_submit_btn
				.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						FeasibilityChecking();
					}
				});

		activity_update_registration_state_textview
				.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						dialog = new Dialog(ActivityRegistrationUpdate.this);
						// Include dialog.xml file
						dialog.setContentView(R.layout.custom_list_view);
						dialog.getWindow().setBackgroundDrawable(
								new ColorDrawable(
										android.graphics.Color.TRANSPARENT));

						TextView text = (TextView) dialog
								.findViewById(R.id.custom_list_view_title);
						text.setText("Select State");
						ListView ListMessage = (ListView) dialog
								.findViewById(R.id.custom_list);

						ListMessage.setAdapter(SAdapter);
						dialog.show();
					}
				});

		activity_update_registration_city_textview
				.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						dialog = new Dialog(ActivityRegistrationUpdate.this);
						// Include dialog.xml file
						dialog.setContentView(R.layout.custom_list_view);
						dialog.getWindow().setBackgroundDrawable(
								new ColorDrawable(
										android.graphics.Color.TRANSPARENT));

						TextView text = (TextView) dialog
								.findViewById(R.id.custom_list_view_title);
						text.setText("Select City");
						ListView ListMessage = (ListView) dialog
								.findViewById(R.id.custom_list);

						ListMessage.setAdapter(CAdapter);
						dialog.show();

					}
				});

		activity_update_registration_country_textview
				.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						dialog = new Dialog(ActivityRegistrationUpdate.this);
						// Include dialog.xml file
						dialog.setContentView(R.layout.custom_list_view);
						dialog.getWindow().setBackgroundDrawable(
								new ColorDrawable(
										android.graphics.Color.TRANSPARENT));

						TextView text = (TextView) dialog
								.findViewById(R.id.custom_list_view_title);
						text.setText("Select Country");
						ListView ListMessage = (ListView) dialog
								.findViewById(R.id.custom_list);
						mAdapter = new CountryAdapter(getApplicationContext());
						ListMessage.setAdapter(mAdapter);
						activity_update_registration_state_textview.setText("");
						activity_update_registration_city_textview.setText("");
						dialog.show();

					}
				});
	}

	private void initwidget() {
		// TODO Auto-generated method stub

		activity_update_registration_state_textview = (TextView) findViewById(R.id.activity_update_registration_state_textview);
		activity_update_registration_country_textview = (TextView) findViewById(R.id.activity_update_registration_country_textview);
		activity_update_registration_city_textview = (TextView) findViewById(R.id.activity_update_registration_city_textview);

		activity_update_registration_back = (Button) findViewById(R.id.activity_update_registration_back);
		activity_update_registration_submit_btn = (Button) findViewById(R.id.activity_update_registration_submit_btn);

		activity_update_registration_first_name_edittxt = (EditText) findViewById(R.id.activity_update_registration_first_name_edittxt);
		activity_update_regitration_last_name_edittxt = (EditText) findViewById(R.id.activity_update_regitration_last_name_edittxt);
		activity_update_registration_business_name_edittxt = (EditText) findViewById(R.id.activity_update_registration_business_name_edittxt);

		activity_update_registration_email_edittxt = (EditText) findViewById(R.id.activity_update_registration_email_edittxt);

		activity_update_registration_username_edittxt = (EditText) findViewById(R.id.activity_update_registration_username_edittxt);

		prefUserID = PreferenceConnector.readString(getApplicationContext(),
				PreferenceConnector.USER_ID, "");

		prefEmail = PreferenceConnector.readString(getApplicationContext(),
				PreferenceConnector.EMAIL, "");

		prefFirstName = PreferenceConnector.readString(getApplicationContext(),
				PreferenceConnector.FIRSTNAME, "");

		prefLastName = PreferenceConnector.readString(getApplicationContext(),
				PreferenceConnector.LASTNAME, "");

		prefCountry = PreferenceConnector.readString(getApplicationContext(),
				PreferenceConnector.COUNTRYNAME, "");

		prefState = PreferenceConnector.readString(getApplicationContext(),
				PreferenceConnector.STATENAME, "");

		prefCity = PreferenceConnector.readString(getApplicationContext(),
				PreferenceConnector.CITYNAME, "");

		prefBusinessName = PreferenceConnector.readString(
				getApplicationContext(), PreferenceConnector.BUSINESS_NAME, "");

		prefUname = PreferenceConnector.readString(getApplicationContext(),
				PreferenceConnector.USER_NAME, "");

		prefPass = PreferenceConnector.readString(getApplicationContext(),
				PreferenceConnector.USER_PASSWORD, "");

		activity_update_registration_first_name_edittxt.setText(prefFirstName);

		activity_update_regitration_last_name_edittxt.setText(prefLastName);

		activity_update_registration_business_name_edittxt
				.setText(prefBusinessName);

		activity_update_registration_email_edittxt.setText(prefEmail);
		activity_update_registration_email_edittxt.setEnabled(false);

		activity_update_registration_country_textview.setText(prefCountry);

		activity_update_registration_state_textview.setText(prefState);

		activity_update_registration_city_textview.setText(prefCity);

		activity_update_registration_username_edittxt.setText(prefUname);
		activity_update_registration_username_edittxt.setEnabled(false);

		mLayout = (AnimationLayout) findViewById(R.id.activity_update_data_mainlayout);
		madapter = new SettingsAdapter(getApplicationContext());

		mList = (ListView) findViewById(R.id.sidebar_list1);

		mList.setAdapter(madapter);
		mList.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				// TODO Auto-generated method stub
				switch (arg2) {
				case 0:

					mLayout.toggleSidebar();
					Intent IntentNearby = new Intent(
							ActivityRegistrationUpdate.this,
							ActivityFeatured.class);
					startActivity(IntentNearby);
					finish();
					break;

				case 1:

					mLayout.toggleSidebar();
					Intent IntentActivitySearch = new Intent(
							ActivityRegistrationUpdate.this,
							ActivitySearchOption.class);
					startActivity(IntentActivitySearch);
					finish();

					break;

				case 2:
					mLayout.toggleSidebar();
					Intent intentchangepasswor2 = new Intent(
							ActivityRegistrationUpdate.this,
							ActivityNearByBusiness.class);
					startActivity(intentchangepasswor2);
					finish();

					break;

				case 3:
					mLayout.toggleSidebar();
					Intent intentchangepasswor = new Intent(
							ActivityRegistrationUpdate.this,
							ActivityEvents.class);
					startActivity(intentchangepasswor);
					finish();
					break;
				case 4:
					mLayout.toggleSidebar();
					Intent IntenFavbus = new Intent(
							ActivityRegistrationUpdate.this,
							ActivityFavouriteBusiness.class);
					startActivity(IntenFavbus);
					finish();
					break;

				case 5:
					mLayout.toggleSidebar();
					Intent IntentResource = new Intent(
							ActivityRegistrationUpdate.this,
							ActivityResource.class);
					startActivity(IntentResource);
					finish();
					break;
				case 6:
					// Toast.makeText(getApplicationContext(),
					// "Item Selected::" + arg2, Toast.LENGTH_LONG).show();
					mLayout.toggleSidebar();

					break;

				case 7:
					// Toast.makeText(getApplicationContext(),
					// "Item Selected::" + arg2, Toast.LENGTH_LONG).show();
					mLayout.toggleSidebar();
					Intent intentchangepasswor3 = new Intent(
							ActivityRegistrationUpdate.this,
							ActivityChangePassword.class);
					startActivity(intentchangepasswor3);
					finish();
					break;

				case 8:
					mLayout.toggleSidebar();
					Intent regActivity = new Intent(
							ActivityRegistrationUpdate.this,
							ActivityRegisterBusiness.class);
					startActivity(regActivity);
					finish();

					break;

				case 9:
					mLayout.toggleSidebar();
					Intent Intengps = new Intent(ActivityRegistrationUpdate.this,
							ActivityGPSLive.class);
					startActivity(Intengps);
					finish();
					
					break;

				case 10:
					PreferenceConnector.writeBoolean(getApplicationContext(),
							PreferenceConnector.IS_USER_LOGIN, false);

					AlertDialog.Builder alert = new AlertDialog.Builder(
							ActivityRegistrationUpdate.this);

					alert.setTitle("ChristianBusinessDirectory");
					alert.setMessage("Are You sure You Want to logout?");

					alert.setPositiveButton("Ok",
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int whichButton) {
									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.EMAIL, "");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.FIRSTNAME, "");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.LASTNAME, "");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.COUNTRYID, "");

									PreferenceConnector
											.writeString(
													getApplicationContext(),
													PreferenceConnector.COUNTRYNAME,
													"");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.STATEID, "");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.STATENAME, "");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.CITYNAME, "");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.CITYID, "");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.BUSINESS_NAME,
											"");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.USER_ID, "");

									Intent intent = new Intent(
											ActivityRegistrationUpdate.this,
											ActivityLogin.class);
									startActivity(intent);
									ActivityRegistrationUpdate.this.finish();
								}

							});
					alert.setNegativeButton("Cancel",
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int which) {
									// TODO Auto-generated method stub

								}

							});

					alert.show();

					break;
				default:
					break;
				}

			}
		});

	}

	protected void Update() {
		// TODO Auto-generated method stub

		final ProgressDialog dialog;
		dialog = new ProgressDialog(this);
		dialog.setTitle("");
		dialog.setMessage("Please Wait...");
		dialog.setCancelable(false);

		AsyncTask<Void, Void, Boolean> waitForCompletion = new AsyncTask<Void, Void, Boolean>() {

			@Override
			protected void onPreExecute() {
				// TODO Auto-generated method stub
				super.onPreExecute();
				dialog.show();
			}

			boolean isUpdateSuccess = false;

			@Override
			protected Boolean doInBackground(Void... params) {
				// TODO Auto-generated method stub
				try {
					HttpClient httpClient = new DefaultHttpClient();
					String url = Constant.RegisterUpdateUrl;
					HttpPost httpPost = new HttpPost(url);
					List<NameValuePair> parameters = new ArrayList<NameValuePair>();
					parameters.add(new BasicNameValuePair("data", finalString));
					httpPost.setEntity(new UrlEncodedFormEntity(parameters,
							"UTF-8"));

					HttpResponse response = httpClient.execute(httpPost);
					BufferedReader reader = new BufferedReader(
							new InputStreamReader(response.getEntity()
									.getContent(), "UTF-8"));
					String json = reader.readLine();

					Log.i("String response", "" + json);
					JSONTokener tokener = new JSONTokener(json);
					JSONObject finalResult = new JSONObject(tokener);

					Log.i("Response Json", "" + finalResult.toString());

					if (finalResult.has("success")) {
						String mSuccess = finalResult.getString("success");
						if (mSuccess.equals("1")) {
							flag = 1;
							isUpdateSuccess = true;

						} else {
							flag = 0;

						}
					} else {
						flag = -1;
					}

				} catch (ClientProtocolException e) {
					// TODO Auto-generated catch block
					Log.i("Exception",
							"ClientProtocolException : " + e.getMessage());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Log.i("Exception", "IOException : " + e.getMessage());
				} catch (Exception e) {
					// TODO: handle exception
					Log.i("Exception", "Http Response : " + e.getMessage());
				}
				return null;
			}

			@Override
			protected void onPostExecute(Boolean result) {
				// TODO Auto-generated method stub
				if (isUpdateSuccess) {

					// Toast.makeText(getApplicationContext(),
					// "Successfully Update", Toast.LENGTH_LONG).show();
					PreferenceConnector.writeString(getApplicationContext(),
							PreferenceConnector.FIRSTNAME, firstname);

					PreferenceConnector.writeString(getApplicationContext(),
							PreferenceConnector.LASTNAME, lastname);

					PreferenceConnector.writeString(getApplicationContext(),
							PreferenceConnector.BUSINESS_NAME, business_name);

					PreferenceConnector.writeString(getApplicationContext(),
							PreferenceConnector.COUNTRYID, country);

					PreferenceConnector.writeString(getApplicationContext(),
							PreferenceConnector.STATEID, state);

					PreferenceConnector.writeString(getApplicationContext(),
							PreferenceConnector.CITYID, city);

					AlertDialog.Builder alert = new AlertDialog.Builder(
							ActivityRegistrationUpdate.this);

					alert.setTitle("ChristianBusinessDirectory");
					alert.setMessage("Update Successfully.");

					alert.setPositiveButton("Ok",
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int whichButton) {
									// Intent Assignemtnintent = new Intent(
									// ActivityRegistrationUpdate.this,
									// ActivityFeatured.class);
									// startActivity(Assignemtnintent);
									// ActivityRegistrationUpdate.this.finish();
									mLayout.toggleSidebar();
								}

							});

					alert.show();

				} else {
					// Toast.makeText(getApplicationContext(),
					// "Unauthorized data", Toast.LENGTH_LONG).show();
					AlertDialog.Builder alert = new AlertDialog.Builder(
							ActivityRegistrationUpdate.this);

					alert.setTitle("ChristianBusinessDirectory");
					alert.setMessage("Unauthorized data");

					alert.setPositiveButton("Ok",
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int whichButton) {

								}

							});

					alert.show();
				}
				dialog.dismiss();
			}
		};
		if (isInternetAvailable())
			waitForCompletion.execute();
		else
			Toast.makeText(getApplicationContext(),
					"Internet service not available", Toast.LENGTH_SHORT)
					.show();
	}

	protected void FeasibilityChecking() {
		// TODO Auto-generated method stub
		firstname = activity_update_registration_first_name_edittxt.getText()
				.toString();
		lastname = activity_update_regitration_last_name_edittxt.getText()
				.toString();
		business_name = activity_update_registration_business_name_edittxt
				.getText().toString();

		country = activity_update_registration_country_textview.getText()
				.toString();
		state = activity_update_registration_state_textview.getText()
				.toString();
		city = activity_update_registration_city_textview.getText().toString();

		JSONObject jbjdata = new JSONObject();
		JSONObject jbj = new JSONObject();

		try {
			jbj.put("id", prefUserID);
			jbj.put("firstname", firstname);
			jbj.put("lastname", lastname);
			jbj.put("business_name", business_name);
			jbj.put("password", prefPass);
			jbj.put("device_type", "2");
			jbj.put("deviceToken", "123456");
			jbj.put("fk_country", CountryID);
			jbj.put("fk_state", StateID);
			jbj.put("fk_city", CityID);

			jbjdata.put("data", jbj);

		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		finalString = jbjdata.toString();
		Log.i("String final", "" + finalString);

		if (firstname.equals("") || lastname.equals("")
				|| business_name.equals("") || state.equals("")
				|| country.equals("") || city.equals("")) {
			// Toast.makeText(getApplicationContext(),
			// "Please check blank field",
			// Toast.LENGTH_SHORT).show();

			AlertDialog.Builder alert = new AlertDialog.Builder(
					ActivityRegistrationUpdate.this);

			alert.setTitle("ChristianBusinessDirectory");
			alert.setMessage("Please Enter all fields.");

			alert.setPositiveButton("Ok",
					new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog,
								int whichButton) {

						}

					});

			alert.show();
		} else {
			Update();
		}
	}

	private boolean isInternetAvailable() {
		ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		if (cm.getActiveNetworkInfo() != null)
			return (cm.getActiveNetworkInfo().isConnected() && cm
					.getActiveNetworkInfo().isAvailable());
		else
			return false;
	}

	private void GetStatedata() {

		final ProgressDialog dialog;
		dialog = new ProgressDialog(this);
		dialog.setTitle("");
		dialog.setMessage("Please Wait...");
		dialog.setCancelable(false);

		AsyncTask<Void, Void, Boolean> waitForCompletion = new AsyncTask<Void, Void, Boolean>() {

			@Override
			protected void onPreExecute() {
				// TODO Auto-generated method stub
				super.onPreExecute();
				dialog.show();
			}

			@Override
			protected Boolean doInBackground(Void... params) {
				Cons.ListState.clear();
				try {
					JSONObject objss = new JSONObject();
					JSONObject objs = new JSONObject();
					objs.put("country_id", CountryID);
					objss.put("data", objs);
					String FinalString = objss.toString();
					HttpClient httpClient = new DefaultHttpClient();
					String url = Constant.StateURL;
					HttpPost httpGet = new HttpPost(url);
					Log.i("URL", url);

					List<NameValuePair> parameters = new ArrayList<NameValuePair>();
					parameters.add(new BasicNameValuePair("data", FinalString));
					httpGet.setEntity(new UrlEncodedFormEntity(parameters,
							"UTF-8"));

					HttpResponse response = httpClient.execute(httpGet);
					String json = EntityUtils.toString(response.getEntity());
					JSONTokener tokener = new JSONTokener(json);
					JSONObject finalResult = new JSONObject(tokener);
					JSONArray JsonData = finalResult.getJSONArray("data");
					if (finalResult.getString("success").equals("1")) {

						for (int i = 0; i < JsonData.length(); i++) {
							JSONObject jbjdata = JsonData.getJSONObject(i);
							StateManager sm = new StateManager();
							for (int j = 0; j < jbjdata.length(); j++) {

								sm.setStateId(jbjdata.getString("id"));
								sm.setState_name(jbjdata
										.getString("state_name"));
								sm.setState_short_name(jbjdata
										.getString("short_name"));

							}
							Cons.ListState.add(sm);
						}
					}

				} catch (ClientProtocolException e) {
					// TODO Auto-generated catch block
					Log.i("Exception",
							"ClientProtocolException : " + e.getMessage());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Log.i("Exception", "IOException : " + e.getMessage());
				} catch (Exception e) {
					// TODO: handle exception
					Log.i("Exception", "Http Response : " + e.getMessage());
				}
				return null;
			};

			@Override
			protected void onPostExecute(Boolean result) {

				dialog.dismiss();
				setStatedata();
			}
		};
		if (isInternetAvailable())
			waitForCompletion.execute();
		else
			Toast.makeText(getApplicationContext(),
					"Internet service not available", Toast.LENGTH_SHORT)
					.show();
	}

	private void setStatedata() {
		List<String> liststate = new ArrayList<String>();
		for (int i = 0; i < Cons.ListState.size(); i++) {
			liststate.add(Cons.ListState.get(i).getState_name());
		}

		ArrayAdapter<String> dataAdapters = new ArrayAdapter<String>(this,
				android.R.layout.simple_spinner_item, liststate);

		dataAdapters
				.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		// activity_update_registration_state_spinner.setAdapter(dataAdapters);
	}

	protected void GetCitydata() {
		// TODO Auto-generated method stub
		final ProgressDialog dialog;
		dialog = new ProgressDialog(this);
		dialog.setTitle("");
		dialog.setMessage("Please Wait...");
		dialog.setCancelable(false);

		AsyncTask<Void, Void, Boolean> waitForCompletion = new AsyncTask<Void, Void, Boolean>() {

			@Override
			protected void onPreExecute() {
				// TODO Auto-generated method stub
				super.onPreExecute();
				dialog.show();
			}

			@Override
			protected Boolean doInBackground(Void... params) {
				Cons.ListCity.clear();
				try {
					JSONObject objss = new JSONObject();
					JSONObject objs = new JSONObject();
					objs.put("state_id", StateID);
					objss.put("data", objs);
					String FinalString = objss.toString();
					HttpClient httpClient = new DefaultHttpClient();
					String url = Constant.CityUrl;
					HttpPost httpGet = new HttpPost(url);
					Log.i("URL", url);

					List<NameValuePair> parameters = new ArrayList<NameValuePair>();
					parameters.add(new BasicNameValuePair("data", FinalString));
					httpGet.setEntity(new UrlEncodedFormEntity(parameters,
							"UTF-8"));

					HttpResponse response = httpClient.execute(httpGet);
					String json = EntityUtils.toString(response.getEntity());
					JSONTokener tokener = new JSONTokener(json);
					JSONObject finalResult = new JSONObject(tokener);
					JSONArray JsonData = finalResult.getJSONArray("data");
					if (finalResult.getString("success").equals("1")) {

						for (int i = 0; i < JsonData.length(); i++) {
							JSONObject jbjdata = JsonData.getJSONObject(i);
							CityManager cm = new CityManager();
							for (int j = 0; j < jbjdata.length(); j++) {

								cm.setCity_id(jbjdata.getString("id"));
								cm.setCity_name(jbjdata.getString("city_name"));
								cm.setCity_short_name(jbjdata
										.getString("short_name"));

							}
							Cons.ListCity.add(cm);
						}
					}

				} catch (ClientProtocolException e) {
					// TODO Auto-generated catch block
					Log.i("Exception",
							"ClientProtocolException : " + e.getMessage());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Log.i("Exception", "IOException : " + e.getMessage());
				} catch (Exception e) {
					// TODO: handle exception
					Log.i("Exception", "Http Response : " + e.getMessage());
				}
				return null;
			}

			@Override
			protected void onPostExecute(Boolean result) {
				// TODO Auto-generated method stub
				super.onPostExecute(result);
				dialog.dismiss();
				// setCitydata();
			}
		};
		if (isInternetAvailable())
			waitForCompletion.execute();
		else
			Toast.makeText(getApplicationContext(),
					"Internet service not available", Toast.LENGTH_SHORT)
					.show();
	}

	protected void setCitydata() {
		// TODO Auto-generated method stub
		List<String> listcity = new ArrayList<String>();
		for (int i = 0; i < Cons.ListCity.size(); i++) {
			listcity.add(Cons.ListCity.get(i).getCity_name());
		}

		ArrayAdapter<String> dataAdapters1 = new ArrayAdapter<String>(this,
				android.R.layout.simple_spinner_item, listcity);

		dataAdapters1
				.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		// activity_update_registration_city_spinner.setAdapter(dataAdapters1);
	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub

		super.onPause();
	}

	public class SettingsAdapter extends BaseAdapter {

		Context mContext;

		public SettingsAdapter(Context c) {
			mContext = c;
		}

		public int getCount() {
			return mStrings.length;
		}

		public Object getItem(int pos) {
			return pos;
		}

		public long getItemId(int pos) {
			return pos;
		}

		public View getView(final int pos, View convertView, ViewGroup parent) {
			if (convertView == null)
				convertView = View.inflate(mContext, R.layout.row_layout_file,
						null);

			final ViewHolder holder = new ViewHolder();

			holder.imgText = (TextView) convertView
					.findViewById(R.id.row_layout_file_text_title);
			holder.imgText.setText(mStrings[pos]);
			return convertView;
		}

		class ViewHolder {
			public ImageView imgIcon, imgright;
			TextView imgText;
		}
	}

	public class CountryAdapter extends BaseAdapter {

		Context mContext;

		public CountryAdapter(Context c) {
			mContext = c;
		}

		public int getCount() {
			return Cons.ListCountry.size();
		}

		public Object getItem(int pos) {
			return pos;
		}

		public long getItemId(int pos) {
			return pos;
		}

		public View getView(final int pos, View convertView, ViewGroup parent) {
			if (convertView == null)
				convertView = View.inflate(mContext, R.layout.row_item, null);

			final ViewHolder holder = new ViewHolder();
			holder.imgText = (TextView) convertView
					.findViewById(R.id.row_item_textview);
			holder.imgText.setText(Cons.ListCountry.get(pos).getCountryname());

			convertView.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					activity_update_registration_country_textview
							.setText(Cons.ListCountry.get(pos).getCountryname());
					CountryID = Cons.ListCountry.get(pos).getId();
					dialog.dismiss();
					GetStatedata();
				}
			});
			return convertView;
		}

		class ViewHolder {
			// public ImageView imgIcon, imgright;
			// CheckBox check;
			TextView imgText;
		}
	}

	public class StateAdapter extends BaseAdapter {

		Context mContext;

		public StateAdapter(Context c) {
			mContext = c;
		}

		public int getCount() {
			return Cons.ListState.size();
		}

		public Object getItem(int pos) {
			return pos;
		}

		public long getItemId(int pos) {
			return pos;
		}

		public View getView(final int pos, View convertView, ViewGroup parent) {
			if (convertView == null)
				convertView = View.inflate(mContext, R.layout.row_item, null);

			final ViewHolder holder = new ViewHolder();
			holder.imgText = (TextView) convertView
					.findViewById(R.id.row_item_textview);
			holder.imgText.setText(Cons.ListState.get(pos).getState_name());

			convertView.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					activity_update_registration_state_textview
							.setText(Cons.ListState.get(pos).getState_name());
					StateID = Cons.ListState.get(pos).getStateId();
					dialog.dismiss();
					GetCitydata();
				}
			});
			return convertView;
		}

		class ViewHolder {
			// public ImageView imgIcon, imgright;
			// CheckBox check;
			TextView imgText;
		}
	}

	public class CityAdapter extends BaseAdapter {

		Context mContext;

		public CityAdapter(Context c) {
			mContext = c;
		}

		public int getCount() {
			return Cons.ListCity.size();
		}

		public Object getItem(int pos) {
			return pos;
		}

		public long getItemId(int pos) {
			return pos;
		}

		public View getView(final int pos, View convertView, ViewGroup parent) {
			if (convertView == null)
				convertView = View.inflate(mContext, R.layout.row_item, null);

			final ViewHolder holder = new ViewHolder();
			holder.imgText = (TextView) convertView
					.findViewById(R.id.row_item_textview);
			holder.imgText.setText(Cons.ListCity.get(pos).getCity_name());

			convertView.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					activity_update_registration_city_textview
							.setText(Cons.ListCity.get(pos).getCity_name());
					CityID = Cons.ListCity.get(pos).getCity_id();
					dialog.dismiss();

				}
			});
			return convertView;
		}

		class ViewHolder {
			// public ImageView imgIcon, imgright;
			// CheckBox check;
			TextView imgText;
		}
	}

}
