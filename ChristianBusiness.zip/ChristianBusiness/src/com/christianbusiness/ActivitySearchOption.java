package com.christianbusiness;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import com.animation.AnimationLayout;
import com.chirstianbusiness.classes.GPSTracker;
import com.chirstianbusiness.classes.SearchBusinessManager;
import com.christianbusiness.preference.PreferenceConnector;
import com.christianbusiness.utils.Constant;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

public class ActivitySearchOption extends Activity {

	EditText activity_search_option_business_category_edittext,
			activity_serach_option_state_edittext,
			activity_search_option_kilopmter_edittext;
	Button activity_search_btn, btn_back;

	String business_name, state_search, kilometer_search, finalString,
			Latitude, longitude;
	int flag;

	ListView mList;
	protected AnimationLayout mLayout;
	SettingsAdapter madapter;

	protected String[] mStrings = { "Featured Business", "Search Business",
			"Near By Business", "Business Categories", "Favorite Business",
			"Resource", "Edit Profile", "Change Password", "Business Register",
			"GPS Live Map", "Logout" };

	GPSTracker gps;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_search_option);
		initwidget();

		gps = new GPSTracker(ActivitySearchOption.this);
		if (gps.canGetLocation()) {

			Latitude = String.valueOf(gps.getLatitude());
			longitude = String.valueOf(gps.getLongitude());

		}
		activity_search_btn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

				String details = activity_search_option_business_category_edittext
						.getText().toString();
				String Kilometer = activity_search_option_kilopmter_edittext
						.getText().toString();

				String state = activity_serach_option_state_edittext.getText()
						.toString();

				if (!details.trim().equals("")) {
					searchBusiness();
				} else if (!Kilometer.trim().equals("")) {
					searchBusiness();
				} else if (!state.trim().equals("")) {
					searchBusiness();
				} else {

					ShowAlertmessage("ChristianBusinessDirectory",
							"Please enter search keyword.");
				}

			}
		});
		btn_back.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				mLayout.toggleSidebar();
			}
		});
	}

	private void initwidget() {
		// TODO Auto-generated method stub
		activity_search_option_business_category_edittext = (EditText) findViewById(R.id.activity_search_option_business_category_edittext);
		activity_serach_option_state_edittext = (EditText) findViewById(R.id.activity_serach_option_state_edittext);
		activity_search_option_kilopmter_edittext = (EditText) findViewById(R.id.activity_search_option_kilopmter_edittext);
		activity_search_btn = (Button) findViewById(R.id.avtivity_search_option_btn);

		btn_back = (Button) findViewById(R.id.activity_search_option_left_btn);

		mLayout = (AnimationLayout) findViewById(R.id.activity_search_layout);

		madapter = new SettingsAdapter(getApplicationContext());

		mList = (ListView) findViewById(R.id.sidebar_list);

		mList.setAdapter(madapter);

		mList.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				// TODO Auto-generated method stub
				switch (arg2) {
				case 0:
					mLayout.toggleSidebar();
					Intent IntentActivitySearch = new Intent(
							ActivitySearchOption.this, ActivityFeatured.class);
					startActivity(IntentActivitySearch);
					finish();
					break;

				case 1:

					mLayout.toggleSidebar();
					break;

				case 2:
					mLayout.toggleSidebar();
					Intent IntentNearby = new Intent(ActivitySearchOption.this,
							ActivityNearByBusiness.class);
					startActivity(IntentNearby);
					finish();

					break;

				case 3:
					mLayout.toggleSidebar();
					Intent intentchangepasswor = new Intent(
							ActivitySearchOption.this, ActivityEvents.class);
					startActivity(intentchangepasswor);
					finish();
					break;
				case 4:
					mLayout.toggleSidebar();
					Intent intentfavbus = new Intent(ActivitySearchOption.this,
							ActivityFavouriteBusiness.class);
					startActivity(intentfavbus);
					finish();

					break;

				case 5:
					mLayout.toggleSidebar();
					Intent IntentResource = new Intent(
							ActivitySearchOption.this, ActivityResource.class);
					startActivity(IntentResource);
					finish();
					break;
				case 6:
					// Toast.makeText(getApplicationContext(),
					// "Item Selected::" + arg2, Toast.LENGTH_LONG).show();
					mLayout.toggleSidebar();
					Intent intentchangepasswor2 = new Intent(
							ActivitySearchOption.this,
							ActivityRegistrationUpdate.class);
					startActivity(intentchangepasswor2);
					finish();
					break;

				case 7:
					// Toast.makeText(getApplicationContext(),
					// "Item Selected::" + arg2, Toast.LENGTH_LONG).show();
					mLayout.toggleSidebar();
					Intent intentchangepasswor3 = new Intent(
							ActivitySearchOption.this,
							ActivityChangePassword.class);
					startActivity(intentchangepasswor3);
					finish();
					break;

				case 8:
					mLayout.toggleSidebar();
					Intent regActivity = new Intent(ActivitySearchOption.this,
							ActivityRegisterBusiness.class);
					startActivity(regActivity);
					finish();

					break;

				case 9:

					mLayout.toggleSidebar();
					Intent Intengps = new Intent(ActivitySearchOption.this,
							ActivityGPSLive.class);
					startActivity(Intengps);
					finish();
					break;
				case 10:
					PreferenceConnector.writeBoolean(getApplicationContext(),
							PreferenceConnector.IS_USER_LOGIN, false);

					AlertDialog.Builder alert = new AlertDialog.Builder(
							ActivitySearchOption.this);

					alert.setTitle("ChristianBusinessDirectory");
					alert.setMessage("Are You sure You Want to logout?");

					alert.setPositiveButton("Ok",
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int whichButton) {
									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.EMAIL, "");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.FIRSTNAME, "");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.LASTNAME, "");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.COUNTRYID, "");

									PreferenceConnector
											.writeString(
													getApplicationContext(),
													PreferenceConnector.COUNTRYNAME,
													"");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.STATEID, "");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.STATENAME, "");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.CITYNAME, "");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.CITYID, "");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.BUSINESS_NAME,
											"");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.USER_ID, "");
									
									Intent intent = new Intent(
											ActivitySearchOption.this,
											ActivityLogin.class);
									startActivity(intent);
									ActivitySearchOption.this.finish();
								}

							});
					alert.setNegativeButton("Cancel",
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int which) {
									// TODO Auto-generated method stub

								}

							});

					alert.show();

					break;
				default:
					break;
				}

			}
		});
	}

	protected void searchBusiness() {
		business_name = activity_search_option_business_category_edittext
				.getText().toString();
		state_search = activity_serach_option_state_edittext.getText()
				.toString();
		kilometer_search = activity_search_option_kilopmter_edittext.getText()
				.toString();

		final ProgressDialog dialog;
		dialog = new ProgressDialog(this);
		dialog.setTitle("");
		dialog.setMessage("Please Wait...");
		dialog.setCancelable(false);

		AsyncTask<Void, Void, Boolean> waitForCompletion = new AsyncTask<Void, Void, Boolean>() {

			@Override
			protected void onPreExecute() {
				// TODO Auto-generated method stub
				super.onPreExecute();
				dialog.show();
			}

			@Override
			protected Boolean doInBackground(Void... arg0) {
				// TODO Auto-generated method stub
				Cons.ListSearchBusiness.clear();

				try {
					JSONObject jbjdata = new JSONObject();
					JSONObject jbj = new JSONObject();

					try {
						jbj.put("latitude", Latitude);
						jbj.put("longitude", longitude);
						jbj.put("business_cat_name", business_name);
						jbj.put("suburb_state_region", state_search);
						jbj.put("area_meter", kilometer_search);

						jbjdata.put("data", jbj);

					} catch (JSONException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

					finalString = jbjdata.toString();
					HttpClient httpClient = new DefaultHttpClient();

					String url = Constant.SearchBusiness;
					HttpPost httpPost = new HttpPost(url);

					List<NameValuePair> parameters = new ArrayList<NameValuePair>();
					parameters.add(new BasicNameValuePair("data", finalString));
					httpPost.setEntity(new UrlEncodedFormEntity(parameters,
							"UTF-8"));

					HttpResponse response = httpClient.execute(httpPost);
					BufferedReader reader = new BufferedReader(
							new InputStreamReader(response.getEntity()
									.getContent(), "UTF-8"));
					String json = reader.readLine();

					JSONTokener tokener = new JSONTokener(json);
					JSONObject finalResult = new JSONObject(tokener);
					JSONArray dataarray = finalResult.getJSONArray("data");

					Log.i("Json Response ::", json);
					for (int i = 0; i < dataarray.length(); i++) {

						SearchBusinessManager sm = new SearchBusinessManager();
						JSONObject Objdata = dataarray.getJSONObject(i);

						sm.setId(Objdata.getString("id"));

						if (Objdata.has("fk_directory_category")) {
							sm.setFk_directory_category(Objdata
									.getString("fk_directory_category"));
						} else {
							sm.setFk_directory_category("N.A");
						}

						sm.setFk_membership_level(Objdata
								.getString("fk_membership_level"));
						sm.setFk_user_id(Objdata.getString("fk_user_id"));
						sm.setParent_dir_id(Objdata.getString("parent_dir_id"));
						sm.setBusiness_name(Objdata.getString("business_name"));
						sm.setDescription(Objdata.getString("description"));
						sm.setBusiness_phone(Objdata
								.getString("business_phone"));
						sm.setWebsite_name(Objdata.getString("website_name"));
						sm.setEmail(Objdata.getString("email"));
						sm.setContact_person(Objdata
								.getString("contact_person"));
						sm.setFk_country(Objdata.getString("fk_country"));

						sm.setFk_state(Objdata.getString("fk_state"));

						sm.setFk_city(Objdata.getString("fk_city"));

						sm.setStreet_name_number(Objdata
								.getString("street_name_number"));
						sm.setPostcode(Objdata.getString("postcode"));
						sm.setLatitude(Objdata.getString("latitude"));
						sm.setLongitude(Objdata.getString("longitude"));

						if (Objdata.has("region")) {
							sm.setRegion(Objdata.getString("region"));
						} else {
							sm.setRegion("N.A");
						}
						sm.setBusiness_logo(Objdata.getString("business_logo"));
						sm.setPayment_status(Objdata
								.getString("payment_status"));
						sm.setPlan_startdate(Objdata
								.getString("plan_startdate"));

						sm.setPlan_enddate(Objdata.getString("plan_enddate"));
						sm.setIs_featured(Objdata.getString("is_featured"));
						sm.setCreated_at(Objdata.getString("created_at"));
						sm.setUpdated_at(Objdata.getString("updated_at"));
						sm.setStatus(Objdata.getString("status"));
						Cons.ListSearchBusiness.add(sm);

						Log.i("Record Data NO ::", "" + i);
						Log.i("Record Data  ::",
								Cons.ListSearchBusiness.toString());

					}

				} catch (ClientProtocolException e) {
					// TODO Auto-generated catch block
					Log.i("Exception",
							"ClientProtocolException : " + e.getMessage());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Log.i("Exception", "IOException : " + e.getMessage());
				} catch (Exception e) {
					// TODO: handle exception
					Log.i("Exception", "Http Response : " + e.getMessage());
				}
				return null;
			}

			@Override
			protected void onPostExecute(Boolean result) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(ActivitySearchOption.this,
						ActivitySearch.class);

				startActivity(intent);

				dialog.dismiss();
			}
		};
		if (isInternetAvailable())
			waitForCompletion.execute();
		else
			Toast.makeText(getApplicationContext(),
					"Internet service not available", Toast.LENGTH_SHORT)
					.show();
	}

	private boolean isInternetAvailable() {
		ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		if (cm.getActiveNetworkInfo() != null)
			return (cm.getActiveNetworkInfo().isConnected() && cm
					.getActiveNetworkInfo().isAvailable());
		else
			return false;
	}

	public class SettingsAdapter extends BaseAdapter {

		Context mContext;

		public SettingsAdapter(Context c) {
			mContext = c;
		}

		public int getCount() {
			return mStrings.length;
		}

		public Object getItem(int pos) {
			return pos;
		}

		public long getItemId(int pos) {
			return pos;
		}

		public View getView(final int pos, View convertView, ViewGroup parent) {
			if (convertView == null)
				convertView = View.inflate(mContext, R.layout.row_layout_file,
						null);

			final ViewHolder holder = new ViewHolder();

			holder.imgText = (TextView) convertView
					.findViewById(R.id.row_layout_file_text_title);
			holder.imgText.setText(mStrings[pos]);
			return convertView;
		}

		class ViewHolder {
			public ImageView imgIcon, imgright;
			TextView imgText;
		}

	}

	private void ShowAlertmessage(String Title, String message) {
		AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
		builder1.setMessage(message);
		builder1.setTitle(Title);
		builder1.setCancelable(true);
		builder1.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int id) {
				dialog.cancel();
			}
		});

		AlertDialog alert11 = builder1.create();
		alert11.show();
	}
}
