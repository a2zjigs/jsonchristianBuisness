package com.christianbusiness;

public class StateManager {

	private String StateId;
	private String state_name;
	private String state_short_name;

	public String getStateId() {
		return StateId;
	}

	public void setStateId(String stateId) {
		StateId = stateId;
	}

	public String getState_name() {
		return state_name;
	}

	public void setState_name(String state_name) {
		this.state_name = state_name;
	}

	public String getState_short_name() {
		return state_short_name;
	}

	public void setState_short_name(String state_short_name) {
		this.state_short_name = state_short_name;
	}

}
