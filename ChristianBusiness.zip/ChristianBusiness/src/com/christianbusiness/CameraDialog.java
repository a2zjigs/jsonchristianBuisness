package com.christianbusiness;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;

public class CameraDialog extends Activity {

	Button galary, camera, cancel;
	int RESULT_LOAD_IMAGE = 2000;
	// static Uri imageUri;
	protected static final int CAMERA_REQUEST = 0;

	// Bitmap photo;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setGravity(Gravity.BOTTOM);
		setContentView(R.layout.customk_dialog_button);

		getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT,
				ViewGroup.LayoutParams.WRAP_CONTENT);
		overridePendingTransition(R.anim.push_up_in, R.anim.push_up_out);
		galary = (Button) findViewById(R.id.galary);
		camera = (Button) findViewById(R.id.camera);
		cancel = (Button) findViewById(R.id.cancel);

		galary.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

				Intent galleryIntent = new Intent(Intent.ACTION_PICK);
				galleryIntent.setType("image/*");
				startActivityForResult(galleryIntent, RESULT_LOAD_IMAGE);

			}
		});

		camera.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

				Intent cameraIntent = new Intent(
						android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
				startActivityForResult(cameraIntent, CAMERA_REQUEST);
			}
		});

		cancel.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				finish();
				overridePendingTransition(R.anim.push_down_in,
						R.anim.push_down_out);
			}
		});

	}

	public boolean checkImageType(String picturePath) {
		String ext = picturePath.substring(picturePath.lastIndexOf(".") + 1);

		if (ext.equalsIgnoreCase("jpeg") || ext.equalsIgnoreCase("jpg")
				|| ext.equalsIgnoreCase("png")) {
			return true;
		}

		return false;
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {

		if (requestCode == RESULT_LOAD_IMAGE && resultCode == RESULT_OK
				&& null != data) {
			try {
				Uri selectedImage = data.getData();
				String[] filePathColumn = { MediaStore.Images.Media.DATA };
				Cursor cursor = getContentResolver().query(selectedImage,
						filePathColumn, null, null, null);
				cursor.moveToFirst();
				int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
				String picturePath = cursor.getString(columnIndex);

				if (checkImageType(picturePath)) {

					ActivityAddLogo.photo = decodeSampledBitmapFromResource(
							getResources(), picturePath, 500, 500);

					ActivityAddLogo.img_view
							.setImageBitmap(ActivityAddLogo.photo);

					ActivityAddLogo.Base64ofImage = ActivityAddLogo
							.encodeTobase64(ActivityAddLogo.photo);

				}

				finish();
			} catch (Exception e) {
				// TODO: handle exception
			}

		} else if (requestCode == CAMERA_REQUEST && resultCode == RESULT_OK) {
			try {
				if (requestCode == CAMERA_REQUEST && resultCode == RESULT_OK) {
					Bitmap photo = (Bitmap) data.getExtras().get("data");

					ActivityAddLogo.img_view.setImageBitmap(photo);

					ActivityAddLogo.Base64ofImage = ActivityAddLogo
							.encodeTobase64(photo);

					ActivityAddLogo.photo = photo;
				}

				finish();
			} catch (Exception e) {

			}
		}
	}

	public static Bitmap decodeSampledBitmapFromResource(Resources res,
			String res_path, int reqWidth, int reqHeight) {

		// First decode with inJustDecodeBounds=true to check dimensions
		final BitmapFactory.Options options = new BitmapFactory.Options();
		options.inJustDecodeBounds = true;
		BitmapFactory.decodeFile(res_path, options);

		// Calculate inSampleSize
		options.inSampleSize = calculateInSampleSize(options, reqWidth,
				reqHeight);

		// Decode bitmap with inSampleSize set
		options.inJustDecodeBounds = false;
		return BitmapFactory.decodeFile(res_path, options);
		// return BitmapFactory.decodeResource(res, resId, options);
	}

	public static int calculateInSampleSize(BitmapFactory.Options options,
			int reqWidth, int reqHeight) {
		// Raw height and width of image
		final int height = options.outHeight;
		final int width = options.outWidth;
		int inSampleSize = 1;

		if (height > reqHeight || width > reqWidth) {

			final int halfHeight = height / 2;
			final int halfWidth = width / 2;

			// Calculate the largest inSampleSize value that is a power of 2 and
			// keeps both
			// height and width larger than the requested height and width.
			while ((halfHeight / inSampleSize) > reqHeight
					&& (halfWidth / inSampleSize) > reqWidth) {
				inSampleSize *= 2;
			}
		}

		return inSampleSize;
	}

	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		super.onBackPressed();

	}
}
