package com.christianbusiness;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

@SuppressLint("DefaultLocale")
public class ActivitySearch extends Activity {

	EditText activity_search_edittext;
	ListView activity_search_lsitview;

	Button activity_search_option_left_btn;

	SettingsAdapter mCFAdapter;
	public static int posofrecord;
	static int flag = 0;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_search_business);
		initWidget();
		flag = 0;

		if (Cons.ListSearchBusiness.size() == 0) {
			ShowAlertmessage("ChristianBusinessDirectory", "Data Not Found");
		}
		Cons.ListSearchBusinessFinal.addAll(Cons.ListSearchBusiness);
		mCFAdapter = new SettingsAdapter(getApplicationContext());

		activity_search_lsitview.setAdapter(mCFAdapter);

		activity_search_option_left_btn
				.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						finish();
					}
				});

		activity_search_lsitview
				.setOnItemClickListener(new OnItemClickListener() {

					@Override
					public void onItemClick(AdapterView<?> arg0, View arg1,
							int arg2, long arg3) {
						// TODO Auto-generated method stub
						posofrecord = arg2;
						Intent activityIntent = new Intent(ActivitySearch.this,
								ActivitySearchDetails.class);
						startActivity(activityIntent);
					}
				});

		// activity_search_edittext.addTextChangedListener(new TextWatcher() {
		//
		// @Override
		// public void onTextChanged(CharSequence s, int start, int before,
		// int count) {
		// // TODO Auto-generated method stub
		// // mCFAdapter.getFilter().filter(s);
		// String strSearch = activity_search_edittext.getText()
		// .toString();
		// // search_file(Cons.ListSearchBusiness, s);
		// if (strSearch.trim().equals("")) {
		// Cons.ListSearchBusiness = Cons.ListSearchBusinessFinal;
		// mCFAdapter.notifyDataSetChanged();
		// } else {
		//
		// getSearchNetworks(String.valueOf(s));
		// Cons.ListSearchBusinessQuery.clear();
		// }
		//
		// }

		activity_search_edittext
				.setOnEditorActionListener(new TextView.OnEditorActionListener() {

					public boolean onEditorAction(TextView v, int actionId,
							KeyEvent event) {
						if (actionId == EditorInfo.IME_ACTION_SEARCH) {
							String strSearch = activity_search_edittext
									.getText().toString();
							Log.i("Search Keyword", "" + strSearch);
							Cons.ListSearchBusiness.clear();
							Cons.ListSearchBusiness
									.addAll(Cons.ListSearchBusinessFinal);
							if (strSearch != null
									&& activity_search_edittext.getText()
											.length() > 2) {

								if (strSearch.trim().equals("")) {
									Toast.makeText(
											getApplicationContext(),
											"Search keyword should not contain only blank spaces",
											Toast.LENGTH_LONG).show();
									Cons.ListSearchBusiness = Cons.ListSearchBusinessFinal;
									mCFAdapter.notifyDataSetChanged();
								} else {
									getSearchNetworks(String.valueOf(strSearch));
									Cons.ListSearchBusinessQuery.clear();
								}
							} else {
								Cons.ListSearchBusiness
										.addAll(Cons.ListSearchBusinessFinal);
								mCFAdapter.notifyDataSetChanged();
							}
							InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
							imm.hideSoftInputFromWindow(
									activity_search_edittext.getWindowToken(),
									0);
							activity_search_edittext.setText("");
							return true;
						}
						return false;
					}

				});

	}

	private void getSearchNetworks(String keyword) {
		keyword = keyword.toLowerCase();
		for (int i = 0; i < Cons.ListSearchBusiness.size(); i++) {
			if (Cons.ListSearchBusiness.get(i).getBusiness_name()
					.startsWith(keyword)) {

				Cons.ListSearchBusinessQuery
						.add(Cons.ListSearchBusiness.get(i));

			}

		}
		Cons.ListSearchBusiness.clear();
		Cons.ListSearchBusiness.addAll(Cons.ListSearchBusinessQuery);
		activity_search_lsitview.setAdapter(mCFAdapter);

	}

	// @SuppressWarnings("null")
	// public void search_file(ArrayList<SearchBusinessManager> array,
	// CharSequence s) {
	// int n = array.size();
	// ArrayList<SearchBusinessManager> finalResult = null;
	//
	// for (int i = 0; i < n; i++) {
	// if (array.get(i).getBusiness_name().contains(s)) {
	// finalResult.add(array.get(i));
	// }
	//
	// }
	//
	// if (finalResult.size() == 0) {
	//
	// }
	// // return finalResult;
	// mCFAdapter.notifyDataSetChanged();
	// }

	private void ShowAlertmessage(String Title, String message) {
		AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
		builder1.setMessage(message);
		builder1.setTitle(Title);
		builder1.setCancelable(true);
		builder1.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int id) {
				dialog.cancel();
			}
		});

		AlertDialog alert11 = builder1.create();
		alert11.show();
	}

	private void initWidget() {
		activity_search_edittext = (EditText) findViewById(R.id.activity_search_edittext);
		activity_search_lsitview = (ListView) findViewById(R.id.activity_search_lsitview);
		activity_search_option_left_btn = (Button) findViewById(R.id.activity_search_option_left_btn);
		activity_search_lsitview.setAdapter(mCFAdapter);
	}

	public class SettingsAdapter extends BaseAdapter {

		Context mContext;

		public SettingsAdapter(Context c) {
			mContext = c;
		}

		public int getCount() {
			return Cons.ListSearchBusiness.size();
		}

		public Object getItem(int pos) {
			return pos;
		}

		public long getItemId(int pos) {
			return pos;
		}

		public View getView(final int pos, View convertView, ViewGroup parent) {
			if (convertView == null)
				convertView = View.inflate(mContext, R.layout.row_layout_file,
						null);

			final ViewHolder holder = new ViewHolder();

			holder.imgText = (TextView) convertView
					.findViewById(R.id.row_layout_file_text_title);

			// holder.imgright.setVisibility(View.GONE);
			holder.imgText.setText(Cons.ListSearchBusiness.get(pos)
					.getBusiness_name());
			holder.imgText.setTextColor(Color.GRAY);
			return convertView;
		}

		class ViewHolder {
			public ImageView imgIcon, imgright;
			TextView imgText;
		}
	}

}
