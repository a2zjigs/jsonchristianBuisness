package com.christianbusiness;

public class BusinesCategoryManager {

	private String id;
	private String fk_directory_category;
	private String fk_membership_level;
	private String fk_user_id;
	private String parent_dir_id;
	private String business_name;
	
	private String description;
	private String business_phone;
	private String website_name;
	private String email;
	private String contact_person;
	private String fk_country;
	private String fk_state;
	private String fk_city;
	private String street_name_number;
	private String postcode;
	private String latitude;
	private String longitude;
	private String region;
	private String business_logo;
	private String payment_status;
	private String plan_startdate;
	private String plan_enddate;
	private String is_featured;
	private String created_at;
	private String updated_at;
	private String status;
	private String is_fevorite;
	private String fk_country_name;
	private String fk_state_name;
	private String fk_city_name;

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the fk_directory_category
	 */
	public String getFk_directory_category() {
		return fk_directory_category;
	}

	/**
	 * @param fk_directory_category
	 *            the fk_directory_category to set
	 */
	public void setFk_directory_category(String fk_directory_category) {
		this.fk_directory_category = fk_directory_category;
	}

	/**
	 * @return the fk_membership_level
	 */
	public String getFk_membership_level() {
		return fk_membership_level;
	}

	/**
	 * @param fk_membership_level
	 *            the fk_membership_level to set
	 */
	public void setFk_membership_level(String fk_membership_level) {
		this.fk_membership_level = fk_membership_level;
	}

	/**
	 * @return the fk_user_id
	 */
	public String getFk_user_id() {
		return fk_user_id;
	}

	/**
	 * @param fk_user_id
	 *            the fk_user_id to set
	 */
	public void setFk_user_id(String fk_user_id) {
		this.fk_user_id = fk_user_id;
	}

	/**
	 * @return the parent_dir_id
	 */
	public String getParent_dir_id() {
		return parent_dir_id;
	}

	/**
	 * @param parent_dir_id
	 *            the parent_dir_id to set
	 */
	public void setParent_dir_id(String parent_dir_id) {
		this.parent_dir_id = parent_dir_id;
	}

	/**
	 * @return the business_name
	 */
	public String getBusiness_name() {
		return business_name;
	}

	/**
	 * @param business_name
	 *            the business_name to set
	 */
	public void setBusiness_name(String business_name) {
		this.business_name = business_name;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description
	 *            the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the business_phone
	 */
	public String getBusiness_phone() {
		return business_phone;
	}

	/**
	 * @param business_phone
	 *            the business_phone to set
	 */
	public void setBusiness_phone(String business_phone) {
		this.business_phone = business_phone;
	}

	/**
	 * @return the website_name
	 */
	public String getWebsite_name() {
		return website_name;
	}

	/**
	 * @param website_name
	 *            the website_name to set
	 */
	public void setWebsite_name(String website_name) {
		this.website_name = website_name;
	}

	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @param email
	 *            the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * @return the contact_person
	 */
	public String getContact_person() {
		return contact_person;
	}

	/**
	 * @param contact_person
	 *            the contact_person to set
	 */
	public void setContact_person(String contact_person) {
		this.contact_person = contact_person;
	}

	/**
	 * @return the fk_country
	 */
	public String getFk_country() {
		return fk_country;
	}

	/**
	 * @param fk_country
	 *            the fk_country to set
	 */
	public void setFk_country(String fk_country) {
		this.fk_country = fk_country;
	}

	/**
	 * @return the fk_state
	 */
	public String getFk_state() {
		return fk_state;
	}

	/**
	 * @param fk_state
	 *            the fk_state to set
	 */
	public void setFk_state(String fk_state) {
		this.fk_state = fk_state;
	}

	/**
	 * @return the fk_city
	 */
	public String getFk_city() {
		return fk_city;
	}

	/**
	 * @param fk_city
	 *            the fk_city to set
	 */
	public void setFk_city(String fk_city) {
		this.fk_city = fk_city;
	}

	/**
	 * @return the street_name_number
	 */
	public String getStreet_name_number() {
		return street_name_number;
	}

	/**
	 * @param street_name_number
	 *            the street_name_number to set
	 */
	public void setStreet_name_number(String street_name_number) {
		this.street_name_number = street_name_number;
	}

	/**
	 * @return the postcode
	 */
	public String getPostcode() {
		return postcode;
	}

	/**
	 * @param postcode
	 *            the postcode to set
	 */
	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}

	/**
	 * @return the latitude
	 */
	public String getLatitude() {
		return latitude;
	}

	/**
	 * @param latitude
	 *            the latitude to set
	 */
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	/**
	 * @return the longitude
	 */
	public String getLongitude() {
		return longitude;
	}

	/**
	 * @param longitude
	 *            the longitude to set
	 */
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	/**
	 * @return the region
	 */
	public String getRegion() {
		return region;
	}

	/**
	 * @param region
	 *            the region to set
	 */
	public void setRegion(String region) {
		this.region = region;
	}

	/**
	 * @return the business_logo
	 */
	public String getBusiness_logo() {
		return business_logo;
	}

	/**
	 * @param business_logo
	 *            the business_logo to set
	 */
	public void setBusiness_logo(String business_logo) {
		this.business_logo = business_logo;
	}

	/**
	 * @return the payment_status
	 */
	public String getPayment_status() {
		return payment_status;
	}

	/**
	 * @param payment_status
	 *            the payment_status to set
	 */
	public void setPayment_status(String payment_status) {
		this.payment_status = payment_status;
	}

	/**
	 * @return the plan_startdate
	 */
	public String getPlan_startdate() {
		return plan_startdate;
	}

	/**
	 * @param plan_startdate
	 *            the plan_startdate to set
	 */
	public void setPlan_startdate(String plan_startdate) {
		this.plan_startdate = plan_startdate;
	}

	/**
	 * @return the plan_enddate
	 */
	public String getPlan_enddate() {
		return plan_enddate;
	}

	/**
	 * @param plan_enddate
	 *            the plan_enddate to set
	 */
	public void setPlan_enddate(String plan_enddate) {
		this.plan_enddate = plan_enddate;
	}

	/**
	 * @return the is_featured
	 */
	public String getIs_featured() {
		return is_featured;
	}

	/**
	 * @param is_featured
	 *            the is_featured to set
	 */
	public void setIs_featured(String is_featured) {
		this.is_featured = is_featured;
	}

	/**
	 * @return the created_at
	 */
	public String getCreated_at() {
		return created_at;
	}

	/**
	 * @param created_at
	 *            the created_at to set
	 */
	public void setCreated_at(String created_at) {
		this.created_at = created_at;
	}

	/**
	 * @return the updated_at
	 */
	public String getUpdated_at() {
		return updated_at;
	}

	/**
	 * @param updated_at
	 *            the updated_at to set
	 */
	public void setUpdated_at(String updated_at) {
		this.updated_at = updated_at;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status
	 *            the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the is_fevorite
	 */
	public String getIs_fevorite() {
		return is_fevorite;
	}

	/**
	 * @param is_fevorite
	 *            the is_fevorite to set
	 */
	public void setIs_fevorite(String is_fevorite) {
		this.is_fevorite = is_fevorite;
	}

	/**
	 * @return the fk_country_name
	 */
	public String getFk_country_name() {
		return fk_country_name;
	}

	/**
	 * @param fk_country_name
	 *            the fk_country_name to set
	 */
	public void setFk_country_name(String fk_country_name) {
		this.fk_country_name = fk_country_name;
	}

	/**
	 * @return the fk_state_name
	 */
	public String getFk_state_name() {
		return fk_state_name;
	}

	/**
	 * @param fk_state_name
	 *            the fk_state_name to set
	 */
	public void setFk_state_name(String fk_state_name) {
		this.fk_state_name = fk_state_name;
	}

	/**
	 * @return the fk_city_name
	 */
	public String getFk_city_name() {
		return fk_city_name;
	}

	/**
	 * @param fk_city_name
	 *            the fk_city_name to set
	 */
	public void setFk_city_name(String fk_city_name) {
		this.fk_city_name = fk_city_name;
	}

}
