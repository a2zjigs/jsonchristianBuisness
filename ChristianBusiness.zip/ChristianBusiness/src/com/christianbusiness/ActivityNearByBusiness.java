package com.christianbusiness;

import java.io.IOException;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import com.animation.AnimationLayout;
import com.chirstianbusiness.classes.GPSTracker;
import com.chirstianbusiness.classes.NearByManager;
import com.christianbusiness.preference.PreferenceConnector;
import com.christianbusiness.utils.Constant;
import com.nostra13.universalimageloader.cache.disc.naming.HashCodeFileNameGenerator;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.ImageScaleType;
import com.nostra13.universalimageloader.core.assist.QueueProcessingType;
import com.nostra13.universalimageloader.core.decode.BaseImageDecoder;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

public class ActivityNearByBusiness extends Activity {

	Button activity_near_by_business_list_btn;
	public ImageLoader imageLoader;
	public static DisplayImageOptions optionsItems;
	public static DisplayImageOptions optionsDetails;
	public static DisplayImageOptions options;

	public static int posofrecord;
	ListView listBusiness;

	ListView mList;
	CustomBaseAdapter adapter;
	SettingsAdapter madapter;
	String Latitude, longitude;

	protected String[] mStrings = { "Featured Business", "Search Business",
			"Near By Business", "Business Categories", "Favorite Business",
			"Resource", "Edit Profile", "Change Password", "Business Register",
			"GPS Live Map", "Logout" };

	protected AnimationLayout mLayout;

	GPSTracker gps;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_near_by_business);

		Initwdiget();
		initImageLoader();
		gps = new GPSTracker(ActivityNearByBusiness.this);
		if (gps.canGetLocation()) {

			Latitude = String.valueOf(gps.getLatitude());
			longitude = String.valueOf(gps.getLongitude());

		}
		getdata();

		adapter = new CustomBaseAdapter(getApplicationContext());
		activity_near_by_business_list_btn
				.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						// Intent intent = new
						// Intent(ActivityNearByBusiness.this,
						// ActivityBusinessName.class);
						// startActivity(intent);
						// finish();
						mLayout.toggleSidebar();
					}
				});
	}

	private void Initwdiget() {
		listBusiness = (ListView) findViewById(R.id.activity_near_by_business_listview);
		activity_near_by_business_list_btn = (Button) findViewById(R.id.activity_near_by_business_list_btn);

		mLayout = (AnimationLayout) findViewById(R.id.activity_nearbybusines_top);
		madapter = new SettingsAdapter(getApplicationContext());

		mList = (ListView) findViewById(R.id.sidebar_list);

		mList.setAdapter(madapter);
		mList.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				// TODO Auto-generated method stub
				switch (arg2) {
				case 0:

					mLayout.toggleSidebar();
					Intent IntentNearby = new Intent(
							ActivityNearByBusiness.this, ActivityFeatured.class);
					startActivity(IntentNearby);
					finish();
					break;

				case 1:

					mLayout.toggleSidebar();
					Intent IntentActivitySearch = new Intent(
							ActivityNearByBusiness.this,
							ActivitySearchOption.class);
					startActivity(IntentActivitySearch);
					finish();

					break;

				case 2:
					mLayout.toggleSidebar();

					break;

				case 3:
					mLayout.toggleSidebar();
					Intent intentchangepasswor = new Intent(
							ActivityNearByBusiness.this, ActivityEvents.class);
					startActivity(intentchangepasswor);
					finish();
					break;
				case 4:
					mLayout.toggleSidebar();
					Intent intentfavbus = new Intent(
							ActivityNearByBusiness.this,
							ActivityFavouriteBusiness.class);
					startActivity(intentfavbus);
					finish();
					break;

				case 5:
					mLayout.toggleSidebar();
					Intent IntentResource = new Intent(
							ActivityNearByBusiness.this, ActivityResource.class);
					startActivity(IntentResource);
					finish();
					break;
				case 6:
					// Toast.makeText(getApplicationContext(),
					// "Item Selected::" + arg2, Toast.LENGTH_LONG).show();
					mLayout.toggleSidebar();
					Intent intentchangepasswor2 = new Intent(
							ActivityNearByBusiness.this,
							ActivityRegistrationUpdate.class);
					startActivity(intentchangepasswor2);
					finish();
					break;

				case 7:
					// Toast.makeText(getApplicationContext(),
					// "Item Selected::" + arg2, Toast.LENGTH_LONG).show();
					mLayout.toggleSidebar();
					Intent intentchangepasswor3 = new Intent(
							ActivityNearByBusiness.this,
							ActivityChangePassword.class);
					startActivity(intentchangepasswor3);
					finish();
					break;

				case 8:

					mLayout.toggleSidebar();
					Intent regActivity = new Intent(
							ActivityNearByBusiness.this,
							ActivityRegisterBusiness.class);
					startActivity(regActivity);
					finish();

					break;

				case 9:
					mLayout.toggleSidebar();
					Intent Intengps = new Intent(ActivityNearByBusiness.this,
							ActivityGPSLive.class);
					startActivity(Intengps);
					finish();

					break;
				case 10:
					PreferenceConnector.writeBoolean(getApplicationContext(),
							PreferenceConnector.IS_USER_LOGIN, false);

					AlertDialog.Builder alert = new AlertDialog.Builder(
							ActivityNearByBusiness.this);

					alert.setTitle("ChristianBusinessDirectory");
					alert.setMessage("Are You sure You Want to logout?");

					alert.setPositiveButton("Ok",
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int whichButton) {
									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.EMAIL, "");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.FIRSTNAME, "");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.LASTNAME, "");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.COUNTRYID, "");

									PreferenceConnector
											.writeString(
													getApplicationContext(),
													PreferenceConnector.COUNTRYNAME,
													"");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.STATEID, "");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.STATENAME, "");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.CITYNAME, "");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.CITYID, "");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.BUSINESS_NAME,
											"");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.USER_ID, "");

									Intent intent = new Intent(
											ActivityNearByBusiness.this,
											ActivityLogin.class);
									startActivity(intent);
									ActivityNearByBusiness.this.finish();
								}

							});
					alert.setNegativeButton("Cancel",
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int which) {
									// TODO Auto-generated method stub

								}

							});

					alert.show();
					break;
				default:
					break;
				}

			}
		});
	}

	public class CustomBaseAdapter extends BaseAdapter {

		Context context;
		List<RowItem> rowItems;

		public CustomBaseAdapter(Context context) {
			this.context = context;

		}

		/* private view holder class */
		private class ViewHolder {
			ImageView custom_raw_activity_fearured_image;
			TextView custom_raw_activity_fearured_business_name;
			TextView custom_raw_activity_fearured_details;
			ImageView img_favourite;
		}

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return Cons.ListNearByCategory.size();
		}

		@Override
		public View getView(final int position, View convertView,
				ViewGroup parent) {
			ViewHolder holder = null;

			LayoutInflater mInflater = (LayoutInflater) context
					.getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
			if (convertView == null) {
				convertView = mInflater.inflate(
						R.layout.custom_raw_activity_fearured, null);
				holder = new ViewHolder();
				holder.custom_raw_activity_fearured_business_name = (TextView) convertView
						.findViewById(R.id.custom_raw_activity_fearured_business_name);
				holder.custom_raw_activity_fearured_business_name
						.setGravity(Gravity.CENTER);
				holder.custom_raw_activity_fearured_details = (TextView) convertView
						.findViewById(R.id.custom_raw_activity_fearured_details);
				holder.custom_raw_activity_fearured_details
						.setGravity(Gravity.CENTER);
				holder.custom_raw_activity_fearured_image = (ImageView) convertView
						.findViewById(R.id.custom_raw_activity_fearured_image);

				holder.img_favourite = (ImageView) convertView
						.findViewById(R.id.custom_row_activity_img_favourite);
				convertView.setTag(holder);
			} else {
				holder = (ViewHolder) convertView.getTag();
			}

			if (Cons.ListNearByCategory.get(position).getIs_fevorite()
					.contains("Yes")) {
				holder.img_favourite
						.setBackgroundResource(R.drawable.unfavroite);
			} else {
				holder.img_favourite.setBackgroundResource(R.drawable.favroite);
			}

			convertView.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					posofrecord = position;
					Intent Bussinessdetails = new Intent(
							ActivityNearByBusiness.this,
							ActivityNearByBusinessDetails.class);
					startActivity(Bussinessdetails);
				}
			});
			holder.img_favourite.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					posofrecord = position;
					DoFavouriteAndUnFavourite();

					// if
					// (Cons.ListNearByCategory.get(position).getIs_fevorite()
					// .contains("Yes")) {
					// Cons.ListNearByCategory.get(position).setIs_fevorite(
					// "No");
					//
					// } else {
					// Cons.ListNearByCategory.get(position).setIs_fevorite(
					// "Yes");
					// }

				}
			});
			// RowItem rowItem = (RowItem) getItem(position);

			holder.custom_raw_activity_fearured_business_name
					.setText(Cons.ListNearByCategory.get(position)
							.getBusiness_name());
			holder.custom_raw_activity_fearured_details
					.setText(Cons.ListNearByCategory.get(position)
							.getDescription());
			// holder.custom_raw_activity_fearured_image.setImageResource(rowItem
			// .getImageId());

			imageLoader.displayImage(Constant.ImageURL
					+ Cons.ListNearByCategory.get(position).getBusiness_logo(),
					holder.custom_raw_activity_fearured_image, optionsItems);

			return convertView;
		}

		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return 0;
		}

	}

	private void initImageLoader() {

		DisplayMetrics displaymetrics = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);

		ImageLoaderConfiguration config = new ImageLoaderConfiguration.Builder(
				getApplicationContext()).imageDecoder(new BaseImageDecoder())
				.threadPriority(Thread.NORM_PRIORITY - 2)
				.denyCacheImageMultipleSizesInMemory().enableLogging()
				.discCacheFileNameGenerator(new HashCodeFileNameGenerator())
				.tasksProcessingOrder(QueueProcessingType.LIFO).enableLogging()
				.build();
		// Initialize ImageLoader with configuration.
		imageLoader = ImageLoader.getInstance();
		imageLoader.init(config);
		optionsItems = new DisplayImageOptions.Builder()
				.showStubImage(R.drawable.ic_item_loading)
				.imageScaleType(ImageScaleType.IN_SAMPLE_POWER_OF_2)
				.showImageForEmptyUri(R.drawable.ic_item_loading)
				.showImageOnFail(R.drawable.noimage).cacheInMemory()
				.cacheOnDisc().bitmapConfig(Bitmap.Config.RGB_565).build();
		optionsDetails = new DisplayImageOptions.Builder()
				.showStubImage(R.drawable.ic_detail_item_loading)
				.imageScaleType(ImageScaleType.IN_SAMPLE_POWER_OF_2)
				.showImageForEmptyUri(R.drawable.ic_detail_item_loading)
				.showImageOnFail(R.drawable.noimage).cacheInMemory()
				.cacheOnDisc().bitmapConfig(Bitmap.Config.RGB_565).build();
		options = new DisplayImageOptions.Builder()
				.showStubImage(R.drawable.ic_item_loading)
				.imageScaleType(ImageScaleType.EXACTLY_STRETCHED)
				.showImageForEmptyUri(R.drawable.ic_item_loading)
				.showImageOnFail(R.drawable.noimage).cacheInMemory()
				.cacheOnDisc().bitmapConfig(Bitmap.Config.RGB_565).build();
	}

	private void getdata() {

		final ProgressDialog dialog;
		dialog = new ProgressDialog(this);
		dialog.setTitle("");

		dialog.setMessage("Please Wait...");
		dialog.setCancelable(false);

		AsyncTask<Void, Void, Boolean> waitForCompletion = new AsyncTask<Void, Void, Boolean>() {

			@Override
			protected void onPreExecute() {
				// TODO Auto-generated method stub
				super.onPreExecute();
				dialog.show();
			}

			@Override
			protected Boolean doInBackground(Void... params) {
				try {

					Cons.ListNearByCategory.clear();
					// http://testing.siliconithub.com/cbd/index.php/api/business/nearByBusiness?latitude=23.023823&longitude=72.567031&radious=100&page=2&user_id=25

					HttpClient httpClient = new DefaultHttpClient();
					String url = com.christianbusiness.utils.Constant.NearByPlaces
							+ "latitude="
							+ Latitude
							+ "&longitude="
							+ longitude
							+ "&radious=5000"
							+ "&page=0&user_id="
							+ PreferenceConnector.readString(
									getApplicationContext(),
									PreferenceConnector.USER_ID, "");
					HttpGet httpGet = new HttpGet(url);
					Log.i("URL", url);

					HttpResponse response = httpClient.execute(httpGet);
					String json = EntityUtils.toString(response.getEntity());
					JSONTokener tokener = new JSONTokener(json);
					JSONObject finalResult = new JSONObject(tokener);
					Log.i("Response Json", "" + finalResult.toString());
					JSONArray obj = finalResult.getJSONArray("data");
					Log.i("Object of Data", obj.toString());
					for (int i = 0; i < obj.length(); i++) {

						NearByManager rowitem = new NearByManager();
						JSONObject objdata = obj.getJSONObject(i);

						// for (int j = 0; j < objdata.length(); j++) {

						rowitem.setId(objdata.getString("id"));

						rowitem.setFk_directory_category(objdata
								.getString("fk_directory_category"));

						rowitem.setFk_membership_level(objdata
								.getString("fk_membership_level"));

						rowitem.setFk_user_id(objdata.getString("fk_user_id"));

						rowitem.setBusiness_name(objdata
								.getString("business_name"));

						rowitem.setDescription(objdata.getString("description"));

						rowitem.setBusiness_phone(objdata
								.getString("business_phone"));

						rowitem.setWebsite_name(objdata
								.getString("website_name"));

						rowitem.setEmail(objdata.getString("email"));

						rowitem.setContact_person(objdata
								.getString("contact_person"));

						rowitem.setFk_country(objdata.getString("fk_country"));

						rowitem.setFk_state(objdata.getString("fk_state"));

						rowitem.setFk_city(objdata.getString("fk_city"));

						rowitem.setStreet_name_number(objdata
								.getString("street_name_number"));

						rowitem.setPostcode(objdata.getString("postcode"));

						rowitem.setLatitude(objdata.getString("latitude"));

						rowitem.setLongitude(objdata.getString("longitude"));

						// rowitem.setRegion(objdata.getString("region"));

						if (objdata.has("region")) {
							rowitem.setRegion(objdata.getString("region"));
						} else {
							rowitem.setRegion("N.A");
						}

						rowitem.setBusiness_logo(objdata
								.getString("business_logo"));

						rowitem.setPayment_status(objdata
								.getString("payment_status"));

						rowitem.setPlan_startdate(objdata
								.getString("plan_startdate"));

						rowitem.setPlan_enddate(objdata
								.getString("plan_enddate"));

						rowitem.setIs_featured(objdata.getString("is_featured"));

						rowitem.setCreated_at(objdata.getString("created_at"));

						rowitem.setUpdated_at(objdata.getString("updated_at"));

						rowitem.setStatus(objdata.getString("status"));
						rowitem.setDistance(objdata.getString("distance"));

						rowitem.setIs_fevorite(objdata.getString("is_fevorite"));

						// }

						Cons.ListNearByCategory.add(rowitem);

					}

				} catch (ClientProtocolException e) {
					// TODO Auto-generated catch block
					Log.i("Exception",
							"ClientProtocolException : " + e.getMessage());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Log.i("Exception", "IOException : " + e.getMessage());
				} catch (Exception e) {
					// TODO: handle exception
					Log.i("Exception", "Http Response : " + e.getMessage());
				}
				return null;
			};

			@Override
			protected void onPostExecute(Boolean result) {

				dialog.dismiss();

				if (Cons.ListNearByCategory.size() == 0) {

					ShowAlertMessage("Christian Business", "No Data Found");

				} else {
					listBusiness.setAdapter(adapter);
				}

			}
		};
		if (isInternetAvailable())
			waitForCompletion.execute();
		else
			Toast.makeText(getApplicationContext(),
					"Internet service not available", Toast.LENGTH_SHORT)
					.show();
	}

	public void showToast(String msg) {
		Toast.makeText(ActivityNearByBusiness.this, msg, Toast.LENGTH_LONG)
				.show();
	}

	// CHECKING INTERNET AVAILABILITY
	public boolean isInternetAvailable() {
		ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		if (cm.getActiveNetworkInfo() != null)
			return (cm.getActiveNetworkInfo().isConnected() && cm
					.getActiveNetworkInfo().isAvailable());
		else
			return false;
	}

	public class SettingsAdapter extends BaseAdapter {

		Context mContext;

		public SettingsAdapter(Context c) {
			mContext = c;
		}

		public int getCount() {
			return mStrings.length;
		}

		public Object getItem(int pos) {
			return pos;
		}

		public long getItemId(int pos) {
			return pos;
		}

		public View getView(final int pos, View convertView, ViewGroup parent) {
			if (convertView == null)
				convertView = View.inflate(mContext, R.layout.row_layout_file,
						null);

			final ViewHolder holder = new ViewHolder();

			holder.imgText = (TextView) convertView
					.findViewById(R.id.row_layout_file_text_title);
			holder.imgText.setText(mStrings[pos]);
			return convertView;
		}

		class ViewHolder {
			public ImageView imgIcon, imgright;
			TextView imgText;
		}
	}

	private void DoFavouriteAndUnFavourite() {

		final ProgressDialog dialog;
		dialog = new ProgressDialog(this);
		dialog.setTitle("");

		dialog.setMessage("Please Wait...");
		dialog.setCancelable(false);

		AsyncTask<Void, Void, Boolean> waitForCompletion = new AsyncTask<Void, Void, Boolean>() {
			String Message;

			@Override
			protected void onPreExecute() {
				// TODO Auto-generated method stub
				super.onPreExecute();
				dialog.show();
			}

			@Override
			protected Boolean doInBackground(Void... params) {

				try {

					String status;

					if (Cons.ListNearByCategory.get(posofrecord)
							.getIs_fevorite().contains("yes")) {
						status = "N";
					} else {
						status = "Y";
					}

					HttpClient httpClient = new DefaultHttpClient();
					String url = com.christianbusiness.utils.Constant.Favourite
							+ "business_id="
							+ Cons.ListNearByCategory.get(posofrecord).getId()
							+ "&user_id="
							+ PreferenceConnector.readString(
									getApplicationContext(),
									PreferenceConnector.USER_ID, "")
							+ "&is_fevorite=" + status;

					Log.i("String URL ::", url);
					// business_id=388&user_id=25&is_fevorite=Y
					HttpGet httpGet = new HttpGet(url);
					HttpResponse response = httpClient.execute(httpGet);
					String json = EntityUtils.toString(response.getEntity());
					JSONTokener tokener = new JSONTokener(json);
					JSONObject finalResult = new JSONObject(tokener);
					Log.i("Response Json", "" + finalResult.toString());

					Message = finalResult.getString("data");

				} catch (ClientProtocolException e) {
					// TODO Auto-generated catch block
					Log.i("Exception",
							"ClientProtocolException : " + e.getMessage());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Log.i("Exception", "IOException : " + e.getMessage());
				} catch (Exception e) {
					// TODO: handle exception
					Log.i("Exception", "Http Response : " + e.getMessage());
				}
				return null;
			};

			@Override
			protected void onPostExecute(Boolean result) {

				dialog.dismiss();
				if (Cons.ListNearByCategory.get(posofrecord).getIs_fevorite()
						.contains("Yes")) {
					Cons.ListNearByCategory.get(posofrecord).setIs_fevorite(
							"No");

				} else {
					Cons.ListNearByCategory.get(posofrecord).setIs_fevorite(
							"Yes");
				}
				listBusiness.setAdapter(adapter);

				ShowAlertMessage("ChristianBusinessDirectory", Message);
			}
		};
		if (isInternetAvailable())
			waitForCompletion.execute();
		else
			Toast.makeText(getApplicationContext(),
					"Internet service not available", Toast.LENGTH_SHORT)
					.show();
	}

	private void ShowAlertMessage(String title, String Message) {

		AlertDialog.Builder altDialog = new AlertDialog.Builder(this);
		altDialog.setTitle(title);
		altDialog.setMessage(Message); // here add your message
		altDialog.setNeutralButton("OK", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				// TODO Auto-generated method stub
				dialog.dismiss();
			}
		});
		altDialog.show();
	}
}