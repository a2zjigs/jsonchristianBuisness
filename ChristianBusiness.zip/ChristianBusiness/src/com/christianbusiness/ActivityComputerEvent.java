package com.christianbusiness;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class ActivityComputerEvent extends Activity {

	ListView listView;
	List<RowItem> items;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_computer_event);

		items = new ArrayList<RowItem>();
		for (int i = 0; i < 10; i++) {
			RowItem item = new RowItem();

			item.setComputerEventName("Event");
			item.setComputerEventWhen("When");
			item.setComputerEventWhere("Where");
			items.add(item);
		}

		listView = (ListView) findViewById(R.id.activity_computer_events_listview);

		CustomBaseAdapter adapter = new CustomBaseAdapter(this, items);
		listView.setAdapter(adapter);
	}

	public class CustomBaseAdapter extends BaseAdapter {

		Context context;
		List<RowItem> rowItems;

		public CustomBaseAdapter(Context context, List<RowItem> items) {
			this.context = context;
			this.rowItems = items;
		}

		/* private view holder class */
		private class ViewHolder {
			TextView custom_raw_activity_computer_events_event;
			TextView custom_raw_activity_computer_events_when;
			TextView custom_raw_activity_computer_events_where;
		}

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return rowItems.size();
		}

		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			return rowItems.get(position);
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return rowItems.indexOf(getItem(position));
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			ViewHolder holder = null;

			LayoutInflater mInflater = (LayoutInflater) context
					.getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
			if (convertView == null) {
				convertView = mInflater.inflate(
						R.layout.custom_raw_activity_computer_event, null);
				holder = new ViewHolder();
				holder.custom_raw_activity_computer_events_event = (TextView) convertView
						.findViewById(R.id.custom_raw_activity_computer_events_event);
				holder.custom_raw_activity_computer_events_event
						.setGravity(Gravity.CENTER);

				holder.custom_raw_activity_computer_events_when = (TextView) convertView
						.findViewById(R.id.custom_raw_activity_computer_events_when);
				holder.custom_raw_activity_computer_events_when
						.setGravity(Gravity.CENTER);

				holder.custom_raw_activity_computer_events_where = (TextView) convertView
						.findViewById(R.id.custom_raw_activity_computer_events_where);
				holder.custom_raw_activity_computer_events_where
						.setGravity(Gravity.CENTER);

				convertView.setTag(holder);
			} else {
				holder = (ViewHolder) convertView.getTag();
			}

			RowItem rowItem = (RowItem) getItem(position);

			holder.custom_raw_activity_computer_events_event.setText(rowItem
					.getComputerEventName());
			holder.custom_raw_activity_computer_events_when.setText(rowItem
					.getComputerEventWhen());
			holder.custom_raw_activity_computer_events_where.setText(rowItem
					.getComputerEventWhere());

			return convertView;
		}

	}

}
