package com.christianbusiness;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.christianbusiness.preference.PreferenceConnector;

public class ActivityDescription extends Activity {

	Button btn_back, btn_next;
	EditText edt_data;
	TextView txt_countertext, txt_title;
	public static int textlimit;
	public static String StringTitle;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_description);
		initwidget();

		StringTitle = "";
		btn_back.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				StringTitle = edt_data.getText().toString();
				PreferenceConnector.writeString(getApplicationContext(),
						PreferenceConnector.DESCRIPTION, StringTitle);
				finish();
				overridePendingTransition(R.anim.trans_right_in,
						R.anim.trans_right_out);
			}
		});
		btn_next.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				StringTitle = edt_data.getText().toString();
				if (StringTitle != null && StringTitle.trim().equals("")) {
					ShowAlertMessage("Christian Business",
							"Please fill the description.");
				} else {
					StringTitle = edt_data.getText().toString();
					PreferenceConnector.writeString(getApplicationContext(),
							PreferenceConnector.DESCRIPTION, StringTitle);

					Intent intentAddress = new Intent(ActivityDescription.this,
							ActivityAddress.class);
					startActivity(intentAddress);
					overridePendingTransition(R.anim.trans_left_in,
							R.anim.trans_left_out);
				}
			}
		});
		edt_data.addTextChangedListener(new TextWatcher() {

			@Override
			public void onTextChanged(CharSequence s, int start, int before,
					int count) {
				// TODO Auto-generated method stub
				int strleng = edt_data.getText().toString().length();
				txt_countertext.setText(textlimit - strleng + "");
			}

			@Override
			public void beforeTextChanged(CharSequence s, int start, int count,
					int after) {
				// TODO Auto-generated method stub

			}

			@Override
			public void afterTextChanged(Editable s) {
				// TODO Auto-generated method stub

			}
		});

	}

	private void initwidget() {
		// BUTTON BINDING FROM LAYOUT
		btn_back = (Button) findViewById(R.id.activity_description_back_btn);
		btn_next = (Button) findViewById(R.id.activity_description_next_btn);

		// EDITTEXT BINDING FROM LAYOUT
		edt_data = (EditText) findViewById(R.id.activity_description_editTxt);

		txt_title = (TextView) findViewById(R.id.activity_description_text_txtview);

		InputFilter[] filters = new InputFilter[1];
		filters[0] = new InputFilter.LengthFilter(textlimit); // Filter to 10
		// characters
		edt_data.setFilters(filters);

		edt_data.setText(PreferenceConnector.readString(
				getApplicationContext(), PreferenceConnector.DESCRIPTION, ""));

		// TEXTVIEW BINDING FROM LAYOUT
		txt_countertext = (TextView) findViewById(R.id.activity_description_count_txtview);
		txt_countertext.setText("" + textlimit);
		txt_title.setText(StringTitle);

	}

	private void ShowAlertMessage(String title, String message) {
		AlertDialog alertDialog = new AlertDialog.Builder(this).create();
		alertDialog.setTitle("Reset...");
		alertDialog.setMessage("Are you sure?");
		alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int which) {
				// here you can add functions
			}
		});

		alertDialog.show();
	}

	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		finish();
		overridePendingTransition(R.anim.trans_right_in, R.anim.trans_right_out);
		super.onBackPressed();
	}
}
