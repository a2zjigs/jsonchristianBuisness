package com.christianbusiness;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.christianbusiness.preference.PreferenceConnector;
import com.christianbusiness.utils.Constant;

import com.google.android.gcm.GCMRegistrar;

public class ActivityLogin extends Activity {

	Button activity_login_register_btn;
	Button activity_login_btn;

	EditText activity_login_username_edittxt;
	EditText activity_login_password_edittxt;

	EditText forgotPass;

	TextView activity_login_forgot_password_txtview;

	CheckBox activity_login_rememberme_checkBox;
	String finalString;
	int flag;

	private SharedPreferences loginPreferences;
	private SharedPreferences.Editor loginPrefsEditor;
	private Boolean saveLogin;

	String username, password, forgotPassUsername;

	String prefEmail, prefFirstName, prefLastName, prefCountry, prefState,
			prefCity, prefBusinessName;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_login);

		initwidget();

		// registerReceiver(mHandleMessageReceiver, new IntentFilter(
		// CommonUtilities.DISPLAY_MESSAGE_ACTION));

		activity_login_register_btn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(ActivityLogin.this,
						ActivityRegistration.class);
				startActivity(intent);
				ActivityLogin.this.finish();
			}
		});

		activity_login_btn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View view) {
				// TODO Auto-generated method stub

				Login();

				if (activity_login_rememberme_checkBox.isChecked()) {
					loginPrefsEditor.putBoolean("saveLogin", true);
					loginPrefsEditor.putString("username", username);
					// loginPrefsEditor.putString("password", password);
					loginPrefsEditor.commit();

				} else {

					loginPrefsEditor.clear();
					loginPrefsEditor.commit();

				}

			}
		});

		activity_login_rememberme_checkBox
				.setOnCheckedChangeListener(new OnCheckedChangeListener() {

					@Override
					public void onCheckedChanged(CompoundButton buttonView,
							boolean isChecked) {
						// TODO Auto-generated method stub

						if (!isChecked) {

							activity_login_rememberme_checkBox
									.setButtonDrawable(R.drawable.checkbox);

						} else {

							activity_login_rememberme_checkBox
									.setButtonDrawable(R.drawable.checkbox_tick);

						}
					}
				});

		activity_login_forgot_password_txtview
				.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub

						AlertDialog.Builder alert = new AlertDialog.Builder(
								ActivityLogin.this);

						alert.setTitle("ChristianBusinessDirectory");
						alert.setMessage("Enter Username.");

						// Set an EditText view to get user input
						forgotPass = new EditText(ActivityLogin.this);
						forgotPass.setText("");
						forgotPass.setSingleLine(true);
						alert.setView(forgotPass);

						alert.setPositiveButton("Ok",
								new DialogInterface.OnClickListener() {
									public void onClick(DialogInterface dialog,
											int whichButton) {

										forgotPassUsername = forgotPass
												.getText().toString();

										if (forgotPassUsername.equals("")) {
											// Toast.makeText(
											// getApplicationContext(),
											// "Please check blank field",
											// Toast.LENGTH_SHORT).show();
											AlertDialog.Builder alert = new AlertDialog.Builder(
													ActivityLogin.this);

											alert.setTitle("ChristianBusinessDirectory");
											alert.setMessage("Please Enter Username.");

											alert.setPositiveButton(
													"Ok",
													new DialogInterface.OnClickListener() {
														public void onClick(
																DialogInterface dialog,
																int whichButton) {

														}

													});

											alert.show();
										} else {
											forgotPassword();
										}
									}

								});

						alert.show();
					}
				});

	}

	private void initwidget() {
		// TODO Auto-generated method stub
		activity_login_register_btn = (Button) findViewById(R.id.activity_login_register_btn);
		activity_login_btn = (Button) findViewById(R.id.activity_login_btn);

		activity_login_username_edittxt = (EditText) findViewById(R.id.activity_login_username_edittxt);
		activity_login_password_edittxt = (EditText) findViewById(R.id.activity_login_password_edittxt);

		activity_login_forgot_password_txtview = (TextView) findViewById(R.id.activity_login_forgot_password_txtview);

		activity_login_rememberme_checkBox = (CheckBox) findViewById(R.id.activity_login_rememberme_checkBox);
		activity_login_rememberme_checkBox.setChecked(true);

		loginPreferences = getSharedPreferences("loginPrefs", MODE_PRIVATE);
		loginPrefsEditor = loginPreferences.edit();

		saveLogin = loginPreferences.getBoolean("saveLogin", false);
		if (saveLogin == true) {
			activity_login_username_edittxt.setText(loginPreferences.getString(
					"username", ""));
			// activity_login_password_edittxt.setText(loginPreferences.getString(
			// "password", ""));
			activity_login_rememberme_checkBox.setChecked(true);
		}

		prefEmail = PreferenceConnector.readString(getApplicationContext(),
				PreferenceConnector.EMAIL, "");

		prefFirstName = PreferenceConnector.readString(getApplicationContext(),
				PreferenceConnector.FIRSTNAME, "");

		prefLastName = PreferenceConnector.readString(getApplicationContext(),
				PreferenceConnector.LASTNAME, "");

		prefCountry = PreferenceConnector.readString(getApplicationContext(),
				PreferenceConnector.COUNTRYID, "");

		prefState = PreferenceConnector.readString(getApplicationContext(),
				PreferenceConnector.STATEID, "");

		prefCity = PreferenceConnector.readString(getApplicationContext(),
				PreferenceConnector.CITYID, "");

		prefBusinessName = PreferenceConnector.readString(
				getApplicationContext(), PreferenceConnector.BUSINESS_NAME, "");

	}

	private void Login() {

		username = activity_login_username_edittxt.getText().toString();
		password = activity_login_password_edittxt.getText().toString();

		GCMRegistrar.checkDevice(this);

		GCMRegistrar.checkManifest(this);

		Cons.GCMid = GCMRegistrar.getRegistrationId(this);

		if (Cons.GCMid.equals("")) {
			GCMRegistrar.register(this, CommonUtilities.SENDER_ID);
		}

		Cons.GCMid = GCMRegistrar.getRegistrationId(this);

		JSONObject jbjdata = new JSONObject();
		JSONObject jbj = new JSONObject();
		try {
			jbj.put("username", username);
			jbj.put("password", password);
			jbj.put("deviceToken", Cons.GCMid);
			jbj.put("device_type", "2");

			Log.i("GCM ID :", Cons.GCMid);
			// jbj.put("user_firstname", prefFirstName);
			// jbj.put("user_lastname", prefLastName);
			// jbj.put("user_business_name", prefBusinessName);
			// jbj.put("user_email", prefEmail);
			// jbj.put("user_country_name", prefCountry);
			// jbj.put("user_state_name", prefState);
			// jbj.put("user_city_name", prefCity);

			jbjdata.put("data", jbj);
		} catch (JSONException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		finalString = jbjdata.toString();

		if (username.equals("") || password.equals("")) {

			AlertDialog.Builder alert = new AlertDialog.Builder(
					ActivityLogin.this);

			alert.setTitle("ChristianBusinessDirectory");
			alert.setMessage("Please enter username & password.");

			alert.setPositiveButton("Ok",
					new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog,
								int whichButton) {

						}

					});

			alert.show();
			return;
		}

		final ProgressDialog dialog;
		dialog = new ProgressDialog(this);
		dialog.setTitle("");
		dialog.setMessage("Please Wait...");
		dialog.setCancelable(false);

		AsyncTask<Void, Void, Boolean> waitForCompletion = new AsyncTask<Void, Void, Boolean>() {

			@Override
			protected void onPreExecute() {
				// TODO Auto-generated method stub
				super.onPreExecute();
				dialog.show();
			}

			boolean isLoginSuccess = false;

			@Override
			protected Boolean doInBackground(Void... params) {
				// TODO Auto-generated method stub
				try {
					HttpClient httpClient = new DefaultHttpClient();
					String url = Constant.LoginUrl;
					HttpPost httpPost = new HttpPost(url);
					List<NameValuePair> parameters = new ArrayList<NameValuePair>();
					parameters.add(new BasicNameValuePair("data", finalString));

					httpPost.setEntity(new UrlEncodedFormEntity(parameters,
							"UTF-8"));

					HttpResponse response = httpClient.execute(httpPost);
					BufferedReader reader = new BufferedReader(
							new InputStreamReader(response.getEntity()
									.getContent(), "UTF-8"));
					String json = reader.readLine();
					Log.i("String response", "" + json);
					JSONTokener tokener = new JSONTokener(json);
					JSONObject finalResult = new JSONObject(tokener);
					Log.i("Response Json", "" + finalResult.toString());
					JSONObject getdata = finalResult.getJSONObject("data");

					Log.i("Login Structure::", finalString);

					if (finalResult.has("success")) {
						String mSuccess = finalResult.getString("success");
						if (mSuccess.equals("1")) {
							flag = 1;
							isLoginSuccess = true;

							PreferenceConnector.writeString(
									getApplicationContext(),
									PreferenceConnector.EMAIL,
									getdata.getString("user_email"));

							PreferenceConnector.writeString(
									getApplicationContext(),
									PreferenceConnector.FIRSTNAME,
									getdata.getString("user_firstname"));

							PreferenceConnector.writeString(
									getApplicationContext(),
									PreferenceConnector.LASTNAME,
									getdata.getString("user_lastname"));

							PreferenceConnector.writeString(
									getApplicationContext(),
									PreferenceConnector.COUNTRYID,
									getdata.getString("user_fk_country"));

							PreferenceConnector.writeString(
									getApplicationContext(),
									PreferenceConnector.COUNTRYNAME,
									getdata.getString("user_country_name"));

							PreferenceConnector.writeString(
									getApplicationContext(),
									PreferenceConnector.STATEID,
									getdata.getString("user_fk_state"));

							PreferenceConnector.writeString(
									getApplicationContext(),
									PreferenceConnector.STATENAME,
									getdata.getString("user_state_name"));

							PreferenceConnector.writeString(
									getApplicationContext(),
									PreferenceConnector.CITYNAME,
									getdata.getString("user_city_name"));

							PreferenceConnector.writeString(
									getApplicationContext(),
									PreferenceConnector.CITYID,
									getdata.getString("user_fk_city"));

							PreferenceConnector.writeString(
									getApplicationContext(),
									PreferenceConnector.BUSINESS_NAME,
									getdata.getString("user_business_name"));

							PreferenceConnector.writeString(
									getApplicationContext(),
									PreferenceConnector.USER_ID,
									getdata.getString("user_id"));

						} else {
							flag = 0;

						}
					} else {
						flag = -1;
					}

				} catch (ClientProtocolException e) {
					// TODO Auto-generated catch block
					Log.i("Exception",
							"ClientProtocolException : " + e.getMessage());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Log.i("Exception", "IOException : " + e.getMessage());
				} catch (Exception e) {
					// TODO: handle exception
					Log.i("Exception", "Http Response : " + e.getMessage());
				}
				return null;
			}

			@Override
			protected void onPostExecute(Boolean result) {
				if (isLoginSuccess) {

					PreferenceConnector.writeBoolean(getApplicationContext(),
							PreferenceConnector.IS_USER_LOGIN, true);

					PreferenceConnector.writeString(getApplicationContext(),
							PreferenceConnector.USER_NAME, username);

					PreferenceConnector.writeString(getApplicationContext(),
							PreferenceConnector.USER_PASSWORD, password);

					AlertDialog.Builder alert = new AlertDialog.Builder(
							ActivityLogin.this);

					alert.setTitle("ChristianBusinessDirectory");
					alert.setMessage("Login Successfully.");

					alert.setPositiveButton("Ok",
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int whichButton) {
									Intent Assignemtnintent = new Intent(
											ActivityLogin.this,
											ActivityFeatured.class);
									startActivity(Assignemtnintent);

									ActivityLogin.this.finish();
								}

							});

					alert.show();

				} else {
					// Toast.makeText(getApplicationContext(),
					// "Unauthorized User", Toast.LENGTH_LONG).show();
					AlertDialog.Builder alert = new AlertDialog.Builder(
							ActivityLogin.this);

					alert.setTitle("ChristianBusinessDirectory");
					alert.setMessage("Unauthorized User.");

					alert.setPositiveButton("Ok",
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int whichButton) {
									activity_login_username_edittxt.setText("");
									activity_login_password_edittxt.setText("");
								}

							});

					alert.show();
				}
				dialog.dismiss();
			}

		};
		if (isInternetAvailable())
			waitForCompletion.execute();
		else
			Toast.makeText(getApplicationContext(),
					"Internet service not available", Toast.LENGTH_SHORT)
					.show();
	}

	private void forgotPassword() {

		final ProgressDialog dialog;
		dialog = new ProgressDialog(this);
		dialog.setTitle("");
		dialog.setMessage("Please Wait...");
		dialog.setCancelable(false);

		AsyncTask<Void, Void, Boolean> waitForCompletion = new AsyncTask<Void, Void, Boolean>() {

			@Override
			protected void onPreExecute() {
				// TODO Auto-generated method stub
				super.onPreExecute();
				dialog.show();
			}

			boolean isForgotPasswordSuccess = false;

			@Override
			protected Boolean doInBackground(Void... params) {
				try {
					HttpClient httpClient = new DefaultHttpClient();

					String url = Constant.ForgotPassUrl + "?username="
							+ forgotPassUsername;

					HttpGet httpGet = new HttpGet(url);
					Log.i("URL", url);

					HttpResponse response = httpClient.execute(httpGet);
					String json = EntityUtils.toString(response.getEntity());
					JSONTokener tokener = new JSONTokener(json);
					Log.i("String response", "" + json);
					JSONObject finalResult = new JSONObject(tokener);
					Log.i("Response Json", "" + finalResult.toString());

					if (finalResult.has("success")) {
						String mSuccess = finalResult.getString("success");
						if (mSuccess.equals("1")) {
							flag = 1;
							isForgotPasswordSuccess = true;
						} else {
							flag = 0;

						}
					} else {
						flag = -1;
					}

				} catch (ClientProtocolException e) {
					// TODO Auto-generated catch block
					Log.i("Exception",
							"ClientProtocolException : " + e.getMessage());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Log.i("Exception", "IOException : " + e.getMessage());
				} catch (Exception e) {
					// TODO: handle exception
					Log.i("Exception", "Http Response : " + e.getMessage());
				}
				return null;
			}

			@Override
			protected void onPostExecute(Boolean result) {
				// TODO Auto-generated method stub
				if (isForgotPasswordSuccess) {

					// Toast.makeText(getApplicationContext(),
					// "Successfully ForgotPassword Check Your Email",
					// Toast.LENGTH_LONG).show();

					AlertDialog.Builder alert = new AlertDialog.Builder(
							ActivityLogin.this);

					alert.setTitle("ChristianBusinessDirectory");
					alert.setMessage("Password has been sent successfully on you email.");

					alert.setPositiveButton("Ok",
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int whichButton) {

								}

							});

					alert.show();

				} else {
					// Toast.makeText(getApplicationContext(),
					// "Unauthorized data", Toast.LENGTH_LONG).show();
					AlertDialog.Builder alert = new AlertDialog.Builder(
							ActivityLogin.this);

					alert.setTitle("ChristianBusinessDirectory");
					alert.setMessage("Unauthorized data.");

					alert.setPositiveButton("Ok",
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int whichButton) {

								}

							});

					alert.show();
				}
				dialog.dismiss();
			}

		};
		if (isInternetAvailable())
			waitForCompletion.execute();
		else
			Toast.makeText(getApplicationContext(),
					"Internet service not available", Toast.LENGTH_SHORT)
					.show();
	}

	public void showToast(String msg) {
		Toast.makeText(ActivityLogin.this, msg, Toast.LENGTH_LONG).show();
	}

	private boolean isInternetAvailable() {
		// TODO Auto-generated method stub
		ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		if (cm.getActiveNetworkInfo() != null)
			return (cm.getActiveNetworkInfo().isConnected() && cm
					.getActiveNetworkInfo().isAvailable());
		else
			return false;
	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub

		super.onPause();
	}

}
