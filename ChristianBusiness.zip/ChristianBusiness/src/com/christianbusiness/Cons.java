package com.christianbusiness;

import java.util.ArrayList;

import com.chirstianbusiness.classes.GpsHelper;
import com.chirstianbusiness.classes.MemberShipLevel;
import com.chirstianbusiness.classes.NearByManager;
import com.chirstianbusiness.classes.ResourceManager;
import com.chirstianbusiness.classes.SearchBusinessManager;

public class Cons {
	public static ArrayList<CountryManager> ListCountry = new ArrayList<CountryManager>();
	public static ArrayList<StateManager> ListState = new ArrayList<StateManager>();
	public static ArrayList<CityManager> ListCity = new ArrayList<CityManager>();
	public static ArrayList<FeatureManager> ListofFeature = new ArrayList<FeatureManager>();
	public static ArrayList<BusinesCategoryManager> ListofBusinesscategorywise = new ArrayList<BusinesCategoryManager>();
	public static ArrayList<NearByManager> ListNearByCategory = new ArrayList<NearByManager>();
	public static ArrayList<CategoryManager> ListOfCategory = new ArrayList<CategoryManager>();
	public static ArrayList<ResourceManager> ListofResource = new ArrayList<ResourceManager>();
	public static ArrayList<SearchBusinessManager> ListSearchBusiness = new ArrayList<SearchBusinessManager>();
	public static ArrayList<SearchBusinessManager> ListSearchBusinessQuery = new ArrayList<SearchBusinessManager>();
	public static ArrayList<SearchBusinessManager> ListSearchBusinessFinal = new ArrayList<SearchBusinessManager>();
	public static ArrayList<GpsHelper> ListofGpsList = new ArrayList<GpsHelper>();
	public static ArrayList<MemberShipLevel> ListofMember = new ArrayList<MemberShipLevel>();

	public static ArrayList<ChurchManager> ListChurch = new ArrayList<ChurchManager>();
	public static ArrayList<ExtraCategoryManager> ListExtraCetegory = new ArrayList<ExtraCategoryManager>();
	public static String GCMid;
}
