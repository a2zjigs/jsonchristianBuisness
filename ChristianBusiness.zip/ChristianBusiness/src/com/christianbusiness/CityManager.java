package com.christianbusiness;

public class CityManager {
	private String city_id;
	private String city_name;
	private String city_short_name;
	private Boolean checked;

	public String getCity_id() {
		return city_id;
	}

	public void setCity_id(String city_id) {
		this.city_id = city_id;
	}

	public String getCity_name() {
		return city_name;
	}

	public void setCity_name(String city_name) {
		this.city_name = city_name;
	}

	public String getCity_short_name() {
		return city_short_name;
	}

	public void setCity_short_name(String city_short_name) {
		this.city_short_name = city_short_name;
	}

	public Boolean getChecked() {
		return checked;
	}

	public void setChecked(Boolean checked) {
		this.checked = checked;
	}

}
