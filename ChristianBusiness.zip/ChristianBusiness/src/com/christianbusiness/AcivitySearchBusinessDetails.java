package com.christianbusiness;

import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

import com.christianbusiness.preference.PreferenceConnector;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class AcivitySearchBusinessDetails extends
		android.support.v4.app.FragmentActivity {

	Button activity_business_details_list_btn;

	GoogleMap find_us_map;

	TextView txt_businessname, txt_businescategory, txt_businessnamedesc,
			txt_title, txt_businesdesc, txt_address, txt_contactno,
			txt_website;
	String Latitude, longitude;
	LatLng DUBLIN;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_business_details);
		initwidget();

		SupportMapFragment fragment = (SupportMapFragment) getSupportFragmentManager()
				.findFragmentById(R.id.activity_findus_maps);

		find_us_map = fragment.getMap();
		
//		if(PreferenceConnector
//				.readString(getApplicationContext(),
//						PreferenceConnector.MEMBERSHIP_ID, "").equals("1"))
//		{
//			txt_website.setVisibility(View.GONE);
//			fragment.getView().setVisibility(View.GONE);
//		}
		
		DUBLIN = new LatLng(Double.valueOf(Latitude), Double.valueOf(longitude));

		find_us_map.addMarker(new MarkerOptions()
				.position(DUBLIN)
				.title(Cons.ListNearByCategory.get(
						ActivityNearByBusiness.posofrecord).getBusiness_name())
				.snippet(
						Cons.ListNearByCategory.get(
								ActivityNearByBusiness.posofrecord)
								.getDescription())
				.icon(BitmapDescriptorFactory
						.defaultMarker(BitmapDescriptorFactory.HUE_VIOLET)));

		find_us_map.moveCamera(CameraUpdateFactory.newLatLng(DUBLIN));
		find_us_map.animateCamera(CameraUpdateFactory.zoomTo(10));

		activity_business_details_list_btn
				.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						finish();
					}
				});
	}

	private void initwidget() {
		// TODO Auto-generated method stub

		activity_business_details_list_btn = (Button) findViewById(R.id.activity_business_btn_back);

		txt_title = (TextView) findViewById(R.id.activity_business_details_heading);
		txt_businessname = (TextView) findViewById(R.id.activity_business_details_businessname);
		txt_businescategory = (TextView) findViewById(R.id.activity_business_details_businesscategory);
		txt_businesdesc = (TextView) findViewById(R.id.activity_business_details_businessdesc);
		txt_address = (TextView) findViewById(R.id.activity_business_details_businessaddresss);
		txt_contactno = (TextView) findViewById(R.id.activity_business_details_businesscontactno);
		txt_website = (TextView) findViewById(R.id.activity_business_details_businesswebsite);

		txt_title.setText(Cons.ListNearByCategory.get(
				ActivityFeatured.posofrecord).getBusiness_name());

		txt_businessname.setText(Cons.ListNearByCategory.get(
				ActivityFeatured.posofrecord).getBusiness_name());

		txt_address.setText(Cons.ListNearByCategory.get(
				ActivityFeatured.posofrecord).getStreet_name_number());

		txt_contactno.setText(Cons.ListNearByCategory.get(
				ActivityFeatured.posofrecord).getBusiness_phone());

		txt_website.setText(Cons.ListNearByCategory.get(
				ActivityFeatured.posofrecord).getWebsite_name());

		Latitude = Cons.ListNearByCategory.get(ActivityFeatured.posofrecord)
				.getLatitude();

		longitude = Cons.ListNearByCategory.get(ActivityFeatured.posofrecord)
				.getLongitude();

	}

}
