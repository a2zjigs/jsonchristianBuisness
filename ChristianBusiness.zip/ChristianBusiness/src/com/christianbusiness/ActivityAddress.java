package com.christianbusiness;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import com.christianbusiness.preference.PreferenceConnector;
import com.christianbusiness.utils.Constant;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class ActivityAddress extends Activity {

	Button btn_next, btn_back;

	TextView edt_country, edt_state, edt_city;

	Dialog dialog;

	EditText edt_postcode, edt_street;

	String CountryID, StateID, CityID = "";
	public static String Country_Name, State_Name, City_Name, Post_code,
			region, Street;

	SettingsAdapter mAdapter;
	CityAdapter CAdapter;
	StateAdapter SAdapter;

	public static ArrayList<String> CheckStatus = new ArrayList<String>();
	ListView ListMessage;
	String city_mix = "";

	// int size;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_address);
		initwidget();

		CAdapter = new CityAdapter(getApplicationContext());
		SAdapter = new StateAdapter(getApplicationContext());
		mAdapter = new SettingsAdapter(getApplicationContext());

		btn_back.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Country_Name = edt_country.getText().toString();
				State_Name = edt_state.getText().toString();
				City_Name = edt_city.getText().toString();
				Post_code = edt_postcode.getText().toString();
				// region = edt_region.getText().toString();
				Street = edt_street.getText().toString();

				PreferenceConnector.writeString(getApplicationContext(),
						PreferenceConnector.BUSINESS_COUNTRY, Country_Name);

				PreferenceConnector.writeString(getApplicationContext(),
						PreferenceConnector.BUSINESS_STATE, State_Name);

				PreferenceConnector.writeString(getApplicationContext(),
						PreferenceConnector.BUSINESS_CITY, City_Name);

				PreferenceConnector.writeString(getApplicationContext(),
						PreferenceConnector.STREEET_ADDRESS, Street);

				PreferenceConnector.writeString(getApplicationContext(),
						PreferenceConnector.BUSINESS_POSTCODE, Post_code);

				// PreferenceConnector.writeString(getApplicationContext(),
				// PreferenceConnector.REGION, region);
				finish();
				overridePendingTransition(R.anim.trans_right_in,
						R.anim.trans_right_out);
			}
		});

		btn_next.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Country_Name = edt_country.getText().toString();
				State_Name = edt_state.getText().toString();
				City_Name = edt_city.getText().toString();
				Post_code = edt_postcode.getText().toString();
				// region = edt_region.getText().toString();
				Street = edt_street.getText().toString();

				if (Country_Name == null || Country_Name.trim().equals("")) {
					MakeToast("please enter Country Name");
				} else if (State_Name == null || State_Name.trim().equals("")) {
					MakeToast("please enter State Name");
					// } else if (City_Name == null ||
					// City_Name.trim().equals("")) {
					// MakeToast("please enter Region Name");
				} else if (Post_code == null || Post_code.trim().equals("")) {
					MakeToast("please enter post code");
					// } else if (region == null || region.trim().equals("")) {
					// MakeToast("please enter region Name");
				} else if (Street == null || Street.trim().equals("")) {
					MakeToast("please enter Street Name");
				} else {

					PreferenceConnector.writeString(getApplicationContext(),
							PreferenceConnector.BUSINESS_COUNTRY, Country_Name);

					PreferenceConnector.writeString(getApplicationContext(),
							PreferenceConnector.BUSINESS_STATE, State_Name);

					PreferenceConnector.writeString(getApplicationContext(),
							PreferenceConnector.BUSINESS_CITY, City_Name);

					PreferenceConnector.writeString(getApplicationContext(),
							PreferenceConnector.STREEET_ADDRESS, Street);

					PreferenceConnector.writeString(getApplicationContext(),
							PreferenceConnector.BUSINESS_POSTCODE, Post_code);

					// PreferenceConnector.writeString(getApplicationContext(),
					// PreferenceConnector.REGION, region);

					Intent intentActivityLogo = new Intent(
							ActivityAddress.this, ActivityCategoryList.class);

					startActivity(intentActivityLogo);
					overridePendingTransition(R.anim.trans_left_in,
							R.anim.trans_left_out);
				}

			}
		});

		edt_country.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				dialog = new Dialog(ActivityAddress.this);
				// Include dialog.xml file
				dialog.setContentView(R.layout.custom_list_view);
				dialog.getWindow().setBackgroundDrawable(
						new ColorDrawable(android.graphics.Color.TRANSPARENT));

				TextView text = (TextView) dialog
						.findViewById(R.id.custom_list_view_title);
				text.setText("Select Country");
				ListMessage = (ListView) dialog.findViewById(R.id.custom_list);

				ListMessage.setAdapter(mAdapter);
				dialog.show();

			}
		});
		edt_state.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				dialog = new Dialog(ActivityAddress.this);
				// Include dialog.xml file
				dialog.setContentView(R.layout.custom_list_view);
				dialog.getWindow().setBackgroundDrawable(
						new ColorDrawable(android.graphics.Color.TRANSPARENT));

				TextView text = (TextView) dialog
						.findViewById(R.id.custom_list_view_title);
				text.setText("Select State");
				ListMessage = (ListView) dialog.findViewById(R.id.custom_list);

				ListMessage.setAdapter(SAdapter);
				dialog.show();

				CheckStatus.clear();
				edt_city.setText("");
				city_mix = "";
				// Cons.ListCity.clear();

			}
		});

		edt_city.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

				dialog = new Dialog(ActivityAddress.this);
				// Include dialog.xml file
				dialog.setContentView(R.layout.custom_list_view);
				dialog.getWindow().setBackgroundDrawable(
						new ColorDrawable(android.graphics.Color.TRANSPARENT));

				TextView text = (TextView) dialog
						.findViewById(R.id.custom_list_view_title);
				text.setText("Select City");
				ListMessage = (ListView) dialog.findViewById(R.id.custom_list);

				ListMessage.setAdapter(CAdapter);
				dialog.show();

			}
		});

	}

	private void initwidget() {
		btn_back = (Button) findViewById(R.id.activity_address_back_btn);
		btn_next = (Button) findViewById(R.id.activity_address_next_btn);

		edt_country = (TextView) findViewById(R.id.activity_address_edittxt_country);
		edt_city = (TextView) findViewById(R.id.activity_address_edittxt_city);
		edt_state = (TextView) findViewById(R.id.activity_address_edittxt_state);

		edt_postcode = (EditText) findViewById(R.id.activity_address_postcode_edittxt);
		// edt_region = (EditText)
		// findViewById(R.id.activity_address_regions_edittxt);
		edt_street = (EditText) findViewById(R.id.activity_address_street_edittxt);

		edt_country.setText(PreferenceConnector.readString(
				getApplicationContext(), PreferenceConnector.BUSINESS_COUNTRY,
				""));
		edt_city.setText(PreferenceConnector.readString(
				getApplicationContext(), PreferenceConnector.BUSINESS_CITY, ""));

		edt_state.setText(PreferenceConnector
				.readString(getApplicationContext(),
						PreferenceConnector.BUSINESS_STATE, ""));

		edt_postcode.setText(PreferenceConnector.readString(
				getApplicationContext(), PreferenceConnector.BUSINESS_POSTCODE,
				""));

		// edt_region.setText(PreferenceConnector.readString(
		// getApplicationContext(), PreferenceConnector.REGION, region));

		edt_street.setText(PreferenceConnector.readString(
				getApplicationContext(), PreferenceConnector.STREEET_ADDRESS,
				Street));

	}

	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		finish();
		overridePendingTransition(R.anim.trans_right_in, R.anim.trans_right_out);
		super.onBackPressed();
	}

	private void MakeToast(String msg) {
		Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_LONG).show();
	}

	public class SettingsAdapter extends BaseAdapter {

		Context mContext;

		public SettingsAdapter(Context c) {
			mContext = c;
		}

		public int getCount() {
			return Cons.ListCountry.size();
		}

		public Object getItem(int pos) {
			return pos;
		}

		public long getItemId(int pos) {
			return pos;
		}

		public View getView(final int pos, View convertView, ViewGroup parent) {
			if (convertView == null)
				convertView = View.inflate(mContext, R.layout.row_item, null);

			final ViewHolder holder = new ViewHolder();
			holder.imgText = (TextView) convertView
					.findViewById(R.id.row_item_textview);
			holder.imgText.setText(Cons.ListCountry.get(pos).getCountryname());

			convertView.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					edt_country.setText(Cons.ListCountry.get(pos)
							.getCountryname());
					CountryID = Cons.ListCountry.get(pos).getId();
					PreferenceConnector.writeString(getApplicationContext(),
							PreferenceConnector.BUSINES_COUNTRYID, CountryID);
					dialog.dismiss();
					GetStatedata();
				}
			});
			return convertView;
		}

		class ViewHolder {
			// public ImageView imgIcon, imgright;
			// CheckBox check;
			TextView imgText;
		}
	}

	public class StateAdapter extends BaseAdapter {

		Context mContext;

		public StateAdapter(Context c) {
			mContext = c;
		}

		public int getCount() {
			return Cons.ListState.size();
		}

		public Object getItem(int pos) {
			return pos;
		}

		public long getItemId(int pos) {
			return pos;
		}

		public View getView(final int pos, View convertView, ViewGroup parent) {
			if (convertView == null)
				convertView = View.inflate(mContext, R.layout.row_item, null);

			final ViewHolder holder = new ViewHolder();
			holder.imgText = (TextView) convertView
					.findViewById(R.id.row_item_textview);
			holder.imgText.setText(Cons.ListState.get(pos).getState_name());

			convertView.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					edt_state.setText(Cons.ListState.get(pos).getState_name());
					StateID = Cons.ListState.get(pos).getStateId();
					PreferenceConnector.writeString(getApplicationContext(),
							PreferenceConnector.BUSINES_STATEID, StateID);
					dialog.dismiss();
					GetCitydata();
				}
			});
			return convertView;
		}

		class ViewHolder {
			// public ImageView imgIcon, imgright;
			// CheckBox check;
			TextView imgText;
		}
	}

	public class CityAdapter extends BaseAdapter {

		Context mContext;

		public CityAdapter(Context c) {
			mContext = c;
		}

		public int getCount() {
			return Cons.ListCity.size();
		}

		public Object getItem(int pos) {
			return pos;
		}

		public long getItemId(int pos) {
			return pos;
		}

		public View getView(final int pos, View convertView, ViewGroup parent) {
			if (convertView == null)
				convertView = View.inflate(mContext,
						R.layout.row_layout_category_list, null);

			final ViewHolder holder = new ViewHolder();
			holder.imgIcon = (ImageView) convertView
					.findViewById(R.id.row_layout_category_checkbox_selected);
			holder.imgText = (TextView) convertView
					.findViewById(R.id.row_layout_category_textview_title);
			holder.imgText.setText(Cons.ListCity.get(pos).getCity_name());

			convertView.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub

					// edt_city.setText(Cons.ListCity.get(pos).getCity_name());

					dialog.dismiss();

				}
			});

			if (Cons.ListCity.get(pos).getChecked()) {
				holder.imgIcon.setImageResource(R.drawable.checkbox_tick);
				Log.i("Category", pos + ":" + "true");
			} else {
				holder.imgIcon.setImageResource(R.drawable.checkbox);
				Log.i("Category", pos + ":" + "false");
			}

			holder.imgIcon.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					if (Cons.ListCity.get(pos).getChecked()) {
						holder.imgIcon.setImageResource(R.drawable.checkbox);
						CheckStatus.remove(CheckStatus.size() - 1);
						CityManager cm = new CityManager();

						cm.setCity_id(Cons.ListCity.get(pos).getCity_id());
						cm.setCity_name(Cons.ListCity.get(pos).getCity_name());
						cm.setCity_short_name(Cons.ListCity.get(pos)
								.getCity_short_name());

						cm.setChecked(false);
						// city_mix = "," + Cons.ListCity.remove(pos).toString()
						// + city_mix ;
						// edt_city.setText(city_mix);

						Cons.ListCity.remove(pos);
						Cons.ListCity.add(pos, cm);
						Log.i("Status NOT::", ""
								+ Cons.ListCity.get(pos).getChecked());

					} else {

						if (CheckStatus.size() < 7) {

							holder.imgIcon
									.setImageResource(R.drawable.checkbox_tick);
							CheckStatus
									.add(Cons.ListCity.get(pos).getCity_id());

							CityManager cm = new CityManager();

							cm.setCity_id(Cons.ListCity.get(pos).getCity_id());
							cm.setCity_name(Cons.ListCity.get(pos)
									.getCity_name());
							cm.setCity_short_name(Cons.ListCity.get(pos)
									.getCity_short_name());
							cm.setChecked(true);

							Cons.ListCity.remove(pos);
							Cons.ListCity.add(pos, cm);
							Log.i("Status YES::", ""
									+ Cons.ListCity.get(pos).getChecked());

							city_mix = city_mix
									+ Cons.ListCity.get(pos).getCity_name()
									+ ",";
							// city_mix.substring(0, city_mix.length() - 1);
							Log.i("City Name:", city_mix);
							// city_mix.replace("null", "");

							// PreferenceConnector.writeString(getApplicationContext(),
							// PreferenceConnector.CITY_NAME, city_mix);

							CityID = CityID
									+ Cons.ListCity.get(pos).getCity_id() + ",";
							PreferenceConnector.writeString(
									getApplicationContext(),
									PreferenceConnector.BUSINES_CITYID, CityID);

							edt_city.setText(city_mix);

						} else {
							ShowAlertMessage("ChristianBusinessDirectory",
									"You can not select more than 7 region");
						}
					}

				}
			});

			return convertView;
		}

		class ViewHolder {
			public ImageView imgIcon;
			TextView imgText;
		}
	}

	private void GetStatedata() {

		final ProgressDialog dialog;
		dialog = new ProgressDialog(this);
		dialog.setTitle("");
		dialog.setMessage("Please Wait...");
		dialog.setCancelable(false);

		AsyncTask<Void, Void, Boolean> waitForCompletion = new AsyncTask<Void, Void, Boolean>() {

			@Override
			protected void onPreExecute() {
				// TODO Auto-generated method stub
				super.onPreExecute();
				dialog.show();
			}

			@Override
			protected Boolean doInBackground(Void... params) {
				Cons.ListState.clear();
				try {
					JSONObject objss = new JSONObject();
					JSONObject objs = new JSONObject();
					objs.put("country_id", CountryID);
					objss.put("data", objs);
					String FinalString = objss.toString();
					HttpClient httpClient = new DefaultHttpClient();
					String url = Constant.StateURL;
					HttpPost httpGet = new HttpPost(url);
					Log.i("URL", url);

					List<NameValuePair> parameters = new ArrayList<NameValuePair>();
					parameters.add(new BasicNameValuePair("data", FinalString));
					httpGet.setEntity(new UrlEncodedFormEntity(parameters,
							"UTF-8"));

					HttpResponse response = httpClient.execute(httpGet);
					String json = EntityUtils.toString(response.getEntity());
					JSONTokener tokener = new JSONTokener(json);
					JSONObject finalResult = new JSONObject(tokener);
					JSONArray JsonData = finalResult.getJSONArray("data");

					if (finalResult.getString("success").equals("1")) {

						for (int i = 0; i < JsonData.length(); i++) {
							JSONObject jbjdata = JsonData.getJSONObject(i);
							StateManager sm = new StateManager();
							for (int j = 0; j < jbjdata.length(); j++) {

								sm.setStateId(jbjdata.getString("id"));
								sm.setState_name(jbjdata
										.getString("state_name"));
								sm.setState_short_name(jbjdata
										.getString("short_name"));

							}
							Cons.ListState.add(sm);
						}
					}

				} catch (ClientProtocolException e) {
					// TODO Auto-generated catch block
					Log.i("Exception",
							"ClientProtocolException : " + e.getMessage());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Log.i("Exception", "IOException : " + e.getMessage());
				} catch (Exception e) {
					// TODO: handle exception
					Log.i("Exception", "Http Response : " + e.getMessage());
				}
				return null;
			};

			@Override
			protected void onPostExecute(Boolean result) {

				dialog.dismiss();
				// setStatedata();
			}
		};
		if (isInternetAvailable())
			waitForCompletion.execute();
		else
			Toast.makeText(getApplicationContext(),
					"Internet service not available", Toast.LENGTH_SHORT)
					.show();
	}

	private boolean isInternetAvailable() {
		// TODO Auto-generated method stub
		ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		if (cm.getActiveNetworkInfo() != null)
			return (cm.getActiveNetworkInfo().isConnected() && cm
					.getActiveNetworkInfo().isAvailable());
		else
			return false;
	}

	protected void GetCitydata() {
		// TODO Auto-generated method stub
		final ProgressDialog dialog;
		dialog = new ProgressDialog(this);
		dialog.setTitle("");
		dialog.setMessage("Please Wait...");
		dialog.setCancelable(false);

		AsyncTask<Void, Void, Boolean> waitForCompletion = new AsyncTask<Void, Void, Boolean>() {

			@Override
			protected void onPreExecute() {
				// TODO Auto-generated method stub
				super.onPreExecute();
				dialog.show();
			}

			@Override
			protected Boolean doInBackground(Void... params) {
				Cons.ListCity.clear();
				try {
					JSONObject objss = new JSONObject();
					JSONObject objs = new JSONObject();
					objs.put("state_id", StateID);
					objss.put("data", objs);
					String FinalString = objss.toString();
					HttpClient httpClient = new DefaultHttpClient();
					String url = Constant.CityUrl;
					HttpPost httpGet = new HttpPost(url);
					Log.i("URL", url);

					List<NameValuePair> parameters = new ArrayList<NameValuePair>();
					parameters.add(new BasicNameValuePair("data", FinalString));
					httpGet.setEntity(new UrlEncodedFormEntity(parameters,
							"UTF-8"));

					HttpResponse response = httpClient.execute(httpGet);
					String json = EntityUtils.toString(response.getEntity());
					JSONTokener tokener = new JSONTokener(json);
					JSONObject finalResult = new JSONObject(tokener);
					JSONArray JsonData = finalResult.getJSONArray("data");
					if (finalResult.getString("success").equals("1")) {

						for (int i = 0; i < JsonData.length(); i++) {
							JSONObject jbjdata = JsonData.getJSONObject(i);
							CityManager cm = new CityManager();
							for (int j = 0; j < jbjdata.length(); j++) {

								cm.setCity_id(jbjdata.getString("id"));
								cm.setCity_name(jbjdata.getString("city_name"));
								cm.setCity_short_name(jbjdata
										.getString("short_name"));
								cm.setChecked(false);

							}
							Cons.ListCity.add(cm);
						}
					}

				} catch (ClientProtocolException e) {
					// TODO Auto-generated catch block
					Log.i("Exception",
							"ClientProtocolException : " + e.getMessage());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Log.i("Exception", "IOException : " + e.getMessage());
				} catch (Exception e) {
					// TODO: handle exception
					Log.i("Exception", "Http Response : " + e.getMessage());
				}
				return null;
			}

			@Override
			protected void onPostExecute(Boolean result) {
				// TODO Auto-generated method stub
				super.onPostExecute(result);
				dialog.dismiss();
				// setCitydata();
			}
		};
		if (isInternetAvailable())
			waitForCompletion.execute();
		else
			Toast.makeText(getApplicationContext(),
					"Internet service not available", Toast.LENGTH_SHORT)
					.show();
	}

	private void ShowAlertMessage(String Title, String Message) {
		AlertDialog alertDialog = new AlertDialog.Builder(ActivityAddress.this)
				.create();

		// Setting Dialog Title
		alertDialog.setTitle(Title);

		// Setting Dialog Message
		alertDialog.setMessage(Message);

		// Setting OK Button
		alertDialog.setButton("Ok", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int which) {
				// Write your code here to execute after dialog closed
				dialog.dismiss();
			}
		});

		// Showing Alert Message
		alertDialog.show();
	}

}