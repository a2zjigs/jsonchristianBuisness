package com.christianbusiness;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;

import com.christianbusiness.preference.PreferenceConnector;

public class ActivityBusinessName extends Activity {

	TextView activity_business_name_featured_business;
	TextView activity_business_name_events;
	TextView activity_business_name_myevent;
	TextView activity_business_name_near_by_business;
	TextView activity_business_name_edit_profile;
	TextView activity_business_name_change_password;
	TextView activity_business_name_logout;
	TextView activity_business_name_register_business;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_businessname);

		initwidget();

		activity_business_name_featured_business
				.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						Intent intent = new Intent(ActivityBusinessName.this,
								ActivityFeatured.class);
						startActivity(intent);
						finish();
					}
				});
		activity_business_name_events.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				// Intent intent = new Intent(ActivityBusinessName.this,
				// ActivityEvents.class);
				// startActivity(intent);
				// finish();
			}
		});
		activity_business_name_myevent
				.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						// Intent intent = new Intent(ActivityBusinessName.this,
						// ActivityEventDetails.class);
						// startActivity(intent);
						// finish();
					}
				});
		activity_business_name_near_by_business
				.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						Intent intent = new Intent(ActivityBusinessName.this,
								ActivityNearByBusiness.class);
						startActivity(intent);
						finish();
					}
				});
		activity_business_name_edit_profile
				.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						Intent intent = new Intent(ActivityBusinessName.this,
								ActivityRegistrationUpdate.class);
						startActivity(intent);
						finish();
					}
				});
		activity_business_name_change_password
				.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						Intent intent = new Intent(ActivityBusinessName.this,
								ActivityChangePassword.class);
						startActivity(intent);
						finish();
					}
				});
		activity_business_name_logout.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

				PreferenceConnector.writeBoolean(getApplicationContext(),
						PreferenceConnector.IS_USER_LOGIN, false);

				AlertDialog.Builder alert = new AlertDialog.Builder(
						ActivityBusinessName.this);

				alert.setTitle("ChristianBusinessDirectory");
				alert.setMessage("Logout Successfully.");

				alert.setPositiveButton("Ok",
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog,
									int whichButton) {
								Intent intent = new Intent(
										ActivityBusinessName.this,
										ActivityLogin.class);
								startActivity(intent);
								ActivityBusinessName.this.finish();
							}

						});

				alert.show();

			}
		});
		activity_business_name_register_business
				.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						Intent intent = new Intent(ActivityBusinessName.this,
								ActivityRegisterBusiness.class);
						startActivity(intent);
						finish();
					}
				});
	}

	private void initwidget() {
		// TODO Auto-generated method stub
		activity_business_name_featured_business = (TextView) findViewById(R.id.activity_business_name_featured_business);
		activity_business_name_events = (TextView) findViewById(R.id.activity_business_name_events);
		activity_business_name_myevent = (TextView) findViewById(R.id.activity_business_name_myevent);
		activity_business_name_near_by_business = (TextView) findViewById(R.id.activity_business_name_near_by_business);
		activity_business_name_edit_profile = (TextView) findViewById(R.id.activity_business_name_edit_profile);
		activity_business_name_change_password = (TextView) findViewById(R.id.activity_business_name_change_password);
		activity_business_name_logout = (TextView) findViewById(R.id.activity_business_name_logout);
		activity_business_name_register_business = (TextView) findViewById(R.id.activity_business_name_register_business);
	}
}
