package com.christianbusiness;

import java.io.IOException;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import com.animation.AnimationLayout;
import com.christianbusiness.preference.PreferenceConnector;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

public class ActivityEvents extends Activity {

	ListView listView;
	List<RowItem> items;
	Button activity_events_list_btn;

	public static final String[] eventname = new String[] { "Auto", "Banking",
			"Cars", "Computers", "Real Estate" };
	protected AnimationLayout mmLayout;

	protected String[] mStrings = { "Featured Business", "Search Business",
			"Near By Business", "Business Categories", "Favorite Business",
			"Resource", "Edit Profile", "Change Password", "Business Register",
			"GPS Live Map", "Logout" };
	CustomBaseAdapter adapter;
	SettingsAdapter madapter;
	ListView mList;
	public static int position;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_events);
		initwidget();

		listView = (ListView) findViewById(R.id.activity_events_listview);

		adapter = new CustomBaseAdapter(this);
		listView.setAdapter(adapter);
		GetCategoryList();
		listView.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				// TODO Auto-generated method stub
				
				position = arg2;
//				if(Cons.ListOfCategory.get(position).getLinkParam().equals("N.A.")){
//					Intent ActivityDetails = new Intent(ActivityEvents.this,
//							ActivityEventDetails.class);
//					startActivity(ActivityDetails);
//					overridePendingTransition(R.anim.trans_left_in,
//							R.anim.trans_left_out);
//				} else {
//					Intent ActivityEventsExtra = new Intent(
//							ActivityEvents.this, ActivityEventsExtra.class);
//					ActivityEventsExtra.putExtra("Name", Cons.ListOfCategory
//							.get(position).getCategory_name());
//					startActivity(ActivityEventsExtra);
//					overridePendingTransition(R.anim.trans_left_in,
//							R.anim.trans_left_out);
//				}
				
				if (Cons.ListOfCategory.get(position).getCategory_name()
						.equals("Churches")
						|| Cons.ListOfCategory.get(position).getCategory_name()
								.equals("Schools")
						|| Cons.ListOfCategory.get(position).getCategory_name()
								.equals("Community Organisations")) {
					Intent ActivityEventsExtra = new Intent(
							ActivityEvents.this, ActivityEventsExtra.class);
					ActivityEventsExtra.putExtra("Name", Cons.ListOfCategory
							.get(position).getCategory_name());
					startActivity(ActivityEventsExtra);
					overridePendingTransition(R.anim.trans_left_in,
							R.anim.trans_left_out);

				} else {
					Intent ActivityDetails = new Intent(ActivityEvents.this,
							ActivityEventDetails.class);
					startActivity(ActivityDetails);
					overridePendingTransition(R.anim.trans_left_in,
							R.anim.trans_left_out);
				}

			}
		});

		activity_events_list_btn = (Button) findViewById(R.id.activity_events_list_btn);
		activity_events_list_btn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				// Intent intent = new Intent(ActivityEvents.this,
				// ActivityBusinessName.class);
				// startActivity(intent);
				// finish();
				mmLayout.toggleSidebar();
			}
		});
	}

	private void initwidget() {
		// TODO Auto-generated method stub
		mmLayout = (AnimationLayout) findViewById(R.id.activity_event_main_layout);
		madapter = new SettingsAdapter(getApplicationContext());

		mList = (ListView) findViewById(R.id.sidebar_list);

		mList.setAdapter(madapter);
		mList.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				// TODO Auto-generated method stub
				switch (arg2) {
				case 0:
					// Toast.makeText(getApplicationContext(),
					// "Item Selected::" + arg2, Toast.LENGTH_LONG).show();
					mmLayout.toggleSidebar();
					Intent intentchangepasswor = new Intent(
							ActivityEvents.this, ActivityFeatured.class);
					startActivity(intentchangepasswor);
					finish();
					break;

				case 1:

					mmLayout.toggleSidebar();
					Intent IntentActivitySearch = new Intent(
							ActivityEvents.this, ActivitySearchOption.class);
					startActivity(IntentActivitySearch);
					finish();

					break;

				case 2:
					mmLayout.toggleSidebar();
					Intent IntentNearby = new Intent(ActivityEvents.this,
							ActivityNearByBusiness.class);
					startActivity(IntentNearby);
					finish();

					break;

				case 3:
					mmLayout.toggleSidebar();
					break;
				case 4:
					mmLayout.toggleSidebar();
					Intent Intentfavbus = new Intent(ActivityEvents.this,
							ActivityFavouriteBusiness.class);
					startActivity(Intentfavbus);
					finish();

					break;

				case 5:
					mmLayout.toggleSidebar();
					Intent IntentResource = new Intent(ActivityEvents.this,
							ActivityResource.class);
					startActivity(IntentResource);
					finish();
					break;
				case 6:
					// Toast.makeText(getApplicationContext(),
					// "Item Selected::" + arg2, Toast.LENGTH_LONG).show();
					mmLayout.toggleSidebar();
					Intent intentchangepasswor2 = new Intent(
							ActivityEvents.this,
							ActivityRegistrationUpdate.class);
					startActivity(intentchangepasswor2);
					finish();
					break;

				case 7:
					// Toast.makeText(getApplicationContext(),
					// "Item Selected::" + arg2, Toast.LENGTH_LONG).show();
					mmLayout.toggleSidebar();
					Intent intentchangepasswor3 = new Intent(
							ActivityEvents.this, ActivityChangePassword.class);
					startActivity(intentchangepasswor3);
					finish();
					break;

				case 8:
					mmLayout.toggleSidebar();
					Intent regActivity = new Intent(ActivityEvents.this,
							ActivityRegisterBusiness.class);
					startActivity(regActivity);
					finish();

					break;

				case 9:

					mmLayout.toggleSidebar();
					Intent Intengps = new Intent(ActivityEvents.this,
							ActivityGPSLive.class);
					startActivity(Intengps);
					finish();
					
					break;
				case 10:
					PreferenceConnector.writeBoolean(getApplicationContext(),
							PreferenceConnector.IS_USER_LOGIN, false);

					AlertDialog.Builder alert = new AlertDialog.Builder(
							ActivityEvents.this);

					alert.setTitle("ChristianBusinessDirectory");
					alert.setMessage("Are You sure You Want to logout?");

					alert.setPositiveButton("Ok",
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int whichButton) {
									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.EMAIL, "");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.FIRSTNAME, "");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.LASTNAME, "");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.COUNTRYID, "");

									PreferenceConnector
											.writeString(
													getApplicationContext(),
													PreferenceConnector.COUNTRYNAME,
													"");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.STATEID, "");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.STATENAME, "");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.CITYNAME, "");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.CITYID, "");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.BUSINESS_NAME,
											"");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.USER_ID, "");
									Intent intent = new Intent(
											ActivityEvents.this,
											ActivityLogin.class);
									startActivity(intent);
									ActivityEvents.this.finish();
								}

							});
					alert.setNegativeButton("Cancel",
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int which) {
									// TODO Auto-generated method stub

								}

							});

					alert.show();
					break;
				default:
					break;
				}

			}
		});

	}

	public class CustomBaseAdapter extends BaseAdapter {

		Context context;
		List<RowItem> rowItems;

		public CustomBaseAdapter(Context context) {
			this.context = context;

		}

		/* private view holder class */
		private class ViewHolder {
			TextView custom_raw_activity_events_names;

		}

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return Cons.ListOfCategory.size();
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			ViewHolder holder = null;

			LayoutInflater mInflater = (LayoutInflater) context
					.getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
			if (convertView == null) {
				convertView = mInflater.inflate(
						R.layout.custom_raw_activity_events, null);
				holder = new ViewHolder();
				holder.custom_raw_activity_events_names = (TextView) convertView
						.findViewById(R.id.custom_raw_activity_events_names);
				holder.custom_raw_activity_events_names
						.setGravity(Gravity.CENTER);

				convertView.setTag(holder);
			} else {
				holder = (ViewHolder) convertView.getTag();
			}

			holder.custom_raw_activity_events_names.setText(Cons.ListOfCategory
					.get(position).getCategory_name());

			return convertView;
		}

		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return 0;
		}

	}

	public class SettingsAdapter extends BaseAdapter {

		Context mContext;

		public SettingsAdapter(Context c) {
			mContext = c;
		}

		public int getCount() {
			return mStrings.length;
		}

		public Object getItem(int pos) {
			return pos;
		}

		public long getItemId(int pos) {
			return pos;
		}

		public View getView(final int pos, View convertView, ViewGroup parent) {
			if (convertView == null)
				convertView = View.inflate(mContext, R.layout.row_layout_file,
						null);

			final ViewHolder holder = new ViewHolder();

			holder.imgText = (TextView) convertView
					.findViewById(R.id.row_layout_file_text_title);
			holder.imgText.setText(mStrings[pos]);
			return convertView;
		}

		class ViewHolder {
			public ImageView imgIcon, imgright;
			TextView imgText;
		}
	}

	protected void GetCategoryList() {

		final ProgressDialog dialog;
		dialog = new ProgressDialog(this);
		dialog.setTitle("");
		dialog.setMessage("Please Wait...");
		dialog.setCancelable(false);

		AsyncTask<Void, Void, Boolean> waitForCompletion = new AsyncTask<Void, Void, Boolean>() {

			@Override
			protected void onPreExecute() {
				// TODO Auto-generated method stub
				super.onPreExecute();
				dialog.show();
			}

			@Override
			protected Boolean doInBackground(Void... arg0) {
				// TODO Auto-generated method stub
				Cons.ListOfCategory.clear();
				try {

					HttpClient httpClient = new DefaultHttpClient();
					String url = com.christianbusiness.utils.Constant.CategoryList
							+ "?" + "page=2" + "&isregister=1";
					HttpGet httpGet = new HttpGet(url);
					Log.i("URL", url);

					HttpResponse response = httpClient.execute(httpGet);
					String json = EntityUtils.toString(response.getEntity());
					JSONTokener tokener = new JSONTokener(json);
					JSONObject finalResult = new JSONObject(tokener);
					Log.i("Response Json", "" + finalResult.toString());
					JSONArray obj = finalResult.getJSONArray("data");
					Log.i("Object of Data", obj.toString());
					for (int i = 0; i < obj.length(); i++) {
						CategoryManager cm = new CategoryManager();
						JSONObject objdata = obj.getJSONObject(i);
						cm.setId(objdata.getString("id"));
						cm.setCategory_name(objdata.getString("category_name"));
						cm.setCategory_image("category_image");
						cm.setCategory_desc(objdata.getString("category_desc"));
						cm.setCreated_at(objdata.getString("created_at"));
						cm.setUpdated_at(objdata.getString("updated_at"));
						cm.setStatus(objdata.getString("status"));
						cm.setChecked(false);
						
//						if (objdata.has("linkParam")) {
//							cm.setLinkParam(objdata.getString("linkParam"));
//						} else {
//							cm.setLinkParam("N.A.");
//						}
//						Log.i("LinkParam:", objdata.getString("linkParam"));

						Cons.ListOfCategory.add(cm);

					}

				} catch (ClientProtocolException e) {
					// TODO Auto-generated catch block
					Log.i("Exception",
							"ClientProtocolException : " + e.getMessage());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Log.i("Exception", "IOException : " + e.getMessage());
				} catch (Exception e) {
					// TODO: handle exception
					Log.i("Exception", "Http Response : " + e.getMessage());
				}
				return null;
			}

			@Override
			protected void onPostExecute(Boolean result) {
				// TODO Auto-generated method stub
				listView.setAdapter(adapter);
				dialog.dismiss();
			}

		};

		if (isInternetAvailable())
			waitForCompletion.execute();
		else
			Toast.makeText(getApplicationContext(),
					"Internet service not available", Toast.LENGTH_SHORT)
					.show();

	}

	private boolean isInternetAvailable() {
		// TODO Auto-generated method stub
		ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		if (cm.getActiveNetworkInfo() != null)
			return (cm.getActiveNetworkInfo().isConnected() && cm
					.getActiveNetworkInfo().isAvailable());
		else
			return false;
	}
}