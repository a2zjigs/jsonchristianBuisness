package com.christianbusiness;

import android.content.Context;
import android.content.Intent;

public final class CommonUtilities {

	// public static final String SERVER_URL =
	// "http://68.178.130.58/app/index.php/api/users/SetDeviceToken";

	// static int flagtemp = MainActivity.temp;
	// public static final String SERVER_URL =
	// "http://www.wecallu.co.il/index.php/api/registration/GetAppsRegistartionUser";
	// public static final String SERVER_URL = WebServices.GCMString;

	public static final String SENDER_ID = "612492157605";
	// public static final String SENDER_ID = "1093437524485";
	// public static final String Ser_url =
	// "http://www.wecallu.co.il/index.php/api/registration/flagMaintanByToken";
	// / public static final String Ser_url = WebServices.flagset;
	/**
	 * Tag used on log messages.
	 */
	public static final String TAG = "Christian Business GCM";

	public static final String DISPLAY_MESSAGE_ACTION = "com.christianbusiness.DISPLAY_MESSAGE";

	public static final String EXTRA_MESSAGE = "message";

	public static void displayMessage(Context context, String message) {
		Intent intent = new Intent(DISPLAY_MESSAGE_ACTION);
		intent.putExtra(EXTRA_MESSAGE, message);
		context.sendBroadcast(intent);
	}
}
