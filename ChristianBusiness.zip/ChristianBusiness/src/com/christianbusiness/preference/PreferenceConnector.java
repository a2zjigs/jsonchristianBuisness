package com.christianbusiness.preference;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

// PREFERENCES ClASS FOR STORING SETTING AND OTHER DETAILS
public class PreferenceConnector {
	public static final String PREF_NAME = "CHRISTIAN_BUSINESS_PREFERENCES";

	public static final int MODE = Context.MODE_WORLD_WRITEABLE;

	public static final String USER_ID = "USER_ID";
	public static final String USER_PASSWORD = "PASSWORD";
	public static final String USER_TOKEN = "USER_TOKEN";
	public static final String IS_USER_LOGIN = "IS_USER_LOGIN";
	public static final String USER_NAME = "USER_NAME";
	public static final String EMAIL = "EMAIL";
	// CITY
	public static final String CITY = "CITY";
	public static final String CITYNAME = "CITYNAME";
	// COUNTRY
	public static final String COUNTRY = "COUNTRY";
	public static final String COUNTRYNAME = "COUNTRYNAME";
	// STATE
	public static final String STATE = "STATE";
	public static final String STATENAME = "STATENAME";

	public static final String CITYID = "CITYID";
	public static final String COUNTRYID = "COUNTRYID";
	public static final String STATEID = "STATEID";
	public static final String FIRSTNAME = "FIRSTNAME";
	public static final String LASTNAME = "LASTNAME";
	public static final String BUSINESS_NAME = "BUSINESS_NAME";
	public static final String BUSINESS_NAME_REGISTER = "BUSINESS_NAME_REGISTER";
	public static final String BUSINESS_PHNO = "BUSINESS_PHNO";
	public static final String BUSINESS_WEBSITE = "BUSINESS_WEBSITE";
	public static final String CONTACT_PERSON = "CONTACT_PERSON";
	public static final String STREEET_ADDRESS = "STREEET_ADDRESS";
	public static final String POSTCODE = "POSTCODE";
	public static final String REGION = "REGION";
	public static final String PAYMENT_STATUS = "PAYMENT_STATUS";
	public static final String DESCRIPTION = "";

	public static final String BUSINESS_COUNTRY = "BUSINESS_COUNTRY";
	public static final String BUSINESS_STATE = "BUSINESS_STATE";
	public static final String BUSINESS_CITY = "BUSINESS_CITY";

	public static final String BUSINESS_POSTCODE = "POSTCODE";

	public static final String BUSINES_COUNTRYID = "BUSINES_COUNTRYID";
	public static final String BUSINES_STATEID = "BUSINES_STATEID";
	public static final String BUSINES_CITYID = "BUSINES_CITYID";
	public static final String CITY_NAME = "CITY_NAME";

	public static final String MEMBERSHIP_BASIC = "MEMBERSHIP_BASIC";
	public static final String MEMBERSHIP_DELUXE = "MEMBERSHIP_DELUXE";
	public static final String MEMBERSHIP_PREMIUM = "MEMBERSHIP_PREMIUM";
	public static final String MEMBERSHIP_SPONSOR = "MEMBERSHIP_SPONSOR";

	public static final String MEMBERSHIP_NAME = "MEMBERSHIP_NAME";
	public static final String MEMBERSHIP_ID = "MEMBERSHIP_ID";

	public static void writeBoolean(Context context, String key, boolean value) {
		getEditor(context).putBoolean(key, value).commit();
	}

	public static boolean readBoolean(Context context, String key,
			boolean defValue) {
		return getPreferences(context).getBoolean(key, defValue);
	}

	public static void writeInteger(Context context, String key, int value) {
		getEditor(context).putInt(key, value).commit();

	}

	public static int readInteger(Context context, String key, int defValue) {
		return getPreferences(context).getInt(key, defValue);
	}

	public static void writeString(Context context, String key, String value) {
		getEditor(context).putString(key, value).commit();

	}

	public static String readString(Context context, String key, String defValue) {
		return getPreferences(context).getString(key, defValue);
	}

	public static void writeFloat(Context context, String key, float value) {
		getEditor(context).putFloat(key, value).commit();
	}

	public static float readFloat(Context context, String key, float defValue) {
		return getPreferences(context).getFloat(key, defValue);
	}

	public static void writeLong(Context context, String key, long value) {
		getEditor(context).putLong(key, value).commit();
	}

	public static long readLong(Context context, String key, long defValue) {
		return getPreferences(context).getLong(key, defValue);
	}

	public static SharedPreferences getPreferences(Context context) {
		return context.getSharedPreferences(PREF_NAME, MODE);
	}

	public static Editor getEditor(Context context) {
		return getPreferences(context).edit();
	}

}
