package com.christianbusiness;

public class RowItem {
	private int imageId;
	private String businessname;
	private String details;
	private String eventname;
	private String computereventname;
	private String computereventwhen;
	private String computereventwhere;
	private int imageslidbar;
	private String slidbarname;

	public int getImageId() {
		return imageId;
	}

	public void setImageId(int imageId) {
		this.imageId = imageId;
	}

	public String getBusinessName() {
		return businessname;
	}

	public void setBusinessName(String businessname) {
		this.businessname = businessname;
	}

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}

	public String getEventName() {
		return eventname;
	}

	public void setEventName(String eventname) {
		this.eventname = eventname;
	}

	public String getComputerEventName() {
		return computereventname;
	}

	public void setComputerEventName(String computereventname) {
		this.computereventname = computereventname;
	}

	public String getComputerEventWhen() {
		return computereventwhen;
	}

	public void setComputerEventWhen(String computereventwhen) {
		this.computereventwhen = computereventwhen;
	}

	public String getComputerEventWhere() {
		return computereventwhere;
	}

	public void setComputerEventWhere(String computereventwhere) {
		this.computereventwhere = computereventwhere;
	}

	public int getImageSlidBar() {
		return imageslidbar;
	}

	public void setImageSlidBar(int imageslidbar) {
		this.imageslidbar = imageslidbar;
	}

	public String getSlidbarName() {
		return slidbarname;
	}

	public void setSlidbarName(String slidbarname) {
		this.slidbarname = slidbarname;
	}

}
