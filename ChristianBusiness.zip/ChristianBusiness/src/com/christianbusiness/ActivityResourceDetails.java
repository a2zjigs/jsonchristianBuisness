package com.christianbusiness;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class ActivityResourceDetails extends Activity {
	Button btn_back;
	TextView txt_title, txt_resourcetitle, txt_resourcedesc,
			txt_resourcecreted, txt_resourceupdate;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_resource_details);
		initwidget();

		btn_back.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				finish();
			}
		});
	}

	private void initwidget() {

		btn_back = (Button) findViewById(R.id.activity_resource_details_btn_back);
		txt_title = (TextView) findViewById(R.id.activity_resource_details_textview_title);

		txt_resourcetitle = (TextView) findViewById(R.id.activity_resource_details_textview_resourcetitle);
		txt_resourcedesc = (TextView) findViewById(R.id.activity_resource_details_textview_resourcedesc);

		txt_resourcecreted = (TextView) findViewById(R.id.activity_resource_details_textview_resourcecreated);
		txt_resourceupdate = (TextView) findViewById(R.id.activity_resource_details_textview_resourceupdated);

		txt_title.setText(Cons.ListofResource.get(ActivityResource.posofrecord)
				.getResource_title());
		txt_resourcetitle.setText(Cons.ListofResource.get(
				ActivityResource.posofrecord).getResource_title());
		txt_resourcedesc.setText(Cons.ListofResource.get(
				ActivityResource.posofrecord).getResource_desc());
		txt_resourcecreted.setText(Cons.ListofResource.get(
				ActivityResource.posofrecord).getCreated_at());
		txt_resourceupdate.setText(Cons.ListofResource.get(
				ActivityResource.posofrecord).getUpdated_at());

	}

}
