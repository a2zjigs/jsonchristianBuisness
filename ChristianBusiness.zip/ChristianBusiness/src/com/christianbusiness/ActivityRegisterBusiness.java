package com.christianbusiness;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.drawable.ColorDrawable;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.webkit.URLUtil;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;
import android.widget.Toast;

import com.animation.AnimationLayout;
import com.animation.CustomEditText;
import com.chirstianbusiness.classes.MemberShipLevel;
import com.christianbusiness.ActivityAddress.SettingsAdapter;
import com.christianbusiness.ActivityAddress.StateAdapter.ViewHolder;
import com.christianbusiness.preference.PreferenceConnector;

public class ActivityRegisterBusiness extends Activity implements
		OnEditorActionListener {

	MembersShipAdapter mMembershipAdapter;

	Button activity_register_business_next_btn;

	String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

	EditText activity_register_business_edittext_businessname;
	CustomEditText activity_register_business_phone_edittxt;
	EditText activity_register_business_edittxt_web;
	EditText activity_register_business_email_edittxt;
	Button btn_list;
	EditText activity_register_businesss_contact_person_edittxt;

	TextView activity_address_select_membership_level;
	Dialog dialog;
	public static String LevelId;

	String businessname, bussinessphn, businessweb, businesscontactperson,
			businessmemnerlevel;
	public static int membershiplevel;
	// public static int id_membership;

	protected String[] mStrings = { "Featured Business", "Search Business",
			"Near By Business", "Business Categories", "Favorite Business",
			"Resource", "Edit Profile", "Change Password", "Business Register",
			"GPS Live Map", "Logout" };

	ListView mList;
	ListView ListMessage;
	protected AnimationLayout mLayout;
	SettingsAdapter madapter;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_register_business);

		initwidget();

		mMembershipAdapter = new MembersShipAdapter(getApplicationContext());
		GetMemberShipLevel();

		// activity_register_business_phone_edittxt
		// .addTextChangedListener(new TextWatcher() {
		//
		// @Override
		// public void onTextChanged(CharSequence s, int start,
		// int before, int count) {
		// // TODO Auto-generated method stub
		// int strleng;
		// strleng = activity_register_business_phone_edittxt
		// .getText().toString().length();
		// if (strleng > 10) {
		//
		// Toast.makeText(getApplicationContext(),
		// "You can not enter more.",
		// Toast.LENGTH_LONG).show();
		// } else {
		//
		// activity_register_business_phone_edittxt
		// .setText(activity_register_business_phone_edittxt
		// .getText().toString());
		// }
		// }
		//
		// @Override
		// public void beforeTextChanged(CharSequence s, int start,
		// int count, int after) {
		// // TODO Auto-generated method stub
		//
		// }
		//
		// @Override
		// public void afterTextChanged(Editable s) {
		// // TODO Auto-generated method stub
		//
		// }
		// });

		activity_register_business_next_btn
				.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						businessmemnerlevel = activity_address_select_membership_level
								.getText().toString();
						businessname = activity_register_business_edittext_businessname
								.getText().toString();
						bussinessphn = activity_register_business_phone_edittxt
								.getText().toString();
						businessweb = activity_register_business_edittxt_web
								.getText().toString();
						businesscontactperson = activity_register_businesss_contact_person_edittxt
								.getText().toString();

						String emails = activity_register_business_email_edittxt
								.getText().toString();
						if (businessmemnerlevel == null
								|| businessmemnerlevel.trim().equals("")) {
							MakeToast("please select Membership Level.");
							 } else if (!emails.matches(emailPattern)) {
							 MakeToast("please Enter Proper Email Address.");
//						} else if (!URLUtil.isValidUrl(businessweb)) {
//							MakeToast("please enter Proper Web Url.");
						} else if (businessname == null
								|| businessname.trim().equals("")) {
							MakeToast("please enter  Business Name");
						} else if (bussinessphn == null
								|| bussinessphn.trim().equals("")) {
							MakeToast("Invalid Phone Number.");
						} else if (businesscontactperson == null
								|| businesscontactperson.trim().equals("")) {
							MakeToast("please enter contact person name.");
						} else {

							// PreferenceConnector.writeString(
							// getApplicationContext(),
							// PreferenceConnector.MEMBERSHIP_NAME,
							// businessmemnerlevel);

							PreferenceConnector.writeString(
									getApplicationContext(),
									PreferenceConnector.BUSINESS_NAME_REGISTER,
									businessname);

							PreferenceConnector.writeString(
									getApplicationContext(),
									PreferenceConnector.BUSINESS_PHNO,
									bussinessphn);

							PreferenceConnector.writeString(
									getApplicationContext(),
									PreferenceConnector.BUSINESS_WEBSITE,
									businessweb);

							PreferenceConnector.writeString(
									getApplicationContext(),
									PreferenceConnector.CONTACT_PERSON,
									businesscontactperson);

							Intent intent = new Intent(
									ActivityRegisterBusiness.this,
									ActivityDescription.class);
							startActivity(intent);
							overridePendingTransition(R.anim.trans_left_in,
									R.anim.trans_left_out);

						}
					}

				});

		btn_list.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				onDestroy();
				mLayout.toggleSidebar();

			}
		});

		activity_address_select_membership_level
				.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub

						dialog = new Dialog(ActivityRegisterBusiness.this);
						// Include dialog.xml file
						dialog.setContentView(R.layout.custom_list_view);
						dialog.getWindow().setBackgroundDrawable(
								new ColorDrawable(
										android.graphics.Color.TRANSPARENT));

						TextView text = (TextView) dialog
								.findViewById(R.id.custom_list_view_title);
						text.setText("Select Membership level");
						ListMessage = (ListView) dialog
								.findViewById(R.id.custom_list);

						ListMessage.setAdapter(mMembershipAdapter);
						dialog.show();

					}

				});

	}

	private void initwidget() {

		activity_address_select_membership_level = (TextView) findViewById(R.id.activity_address_select_membership_level);
		activity_register_business_next_btn = (Button) findViewById(R.id.activity_register_business_next_btn);

		activity_register_business_edittext_businessname = (EditText) findViewById(R.id.activity_register_business_edittext_businessname);
		activity_register_business_phone_edittxt = (CustomEditText) findViewById(R.id.activity_register_business_phone_edittxt);
		activity_register_business_edittxt_web = (EditText) findViewById(R.id.activity_register_business_edittxt_web);
		activity_register_business_email_edittxt = (EditText) findViewById(R.id.activity_register_business_email_edittxt);
		activity_register_businesss_contact_person_edittxt = (EditText) findViewById(R.id.activity_register_businesss_contact_person_edittxt);

		btn_list = (Button) findViewById(R.id.activity_register_business_btn_list);

		activity_address_select_membership_level.setText(PreferenceConnector
				.readString(getApplicationContext(),
						PreferenceConnector.MEMBERSHIP_NAME, ""));

		activity_register_business_edittext_businessname
				.setText(PreferenceConnector.readString(
						getApplicationContext(),
						PreferenceConnector.BUSINESS_NAME_REGISTER, ""));

		activity_register_business_phone_edittxt.setText(PreferenceConnector
				.readString(getApplicationContext(),
						PreferenceConnector.BUSINESS_PHNO, ""));

		activity_register_business_edittxt_web.setText(PreferenceConnector
				.readString(getApplicationContext(),
						PreferenceConnector.BUSINESS_WEBSITE, ""));

		activity_register_businesss_contact_person_edittxt
				.setText(PreferenceConnector.readString(
						getApplicationContext(),
						PreferenceConnector.CONTACT_PERSON, ""));

		mLayout = (AnimationLayout) findViewById(R.id.activity_register_business_top_layout);
		madapter = new SettingsAdapter(getApplicationContext());

		mList = (ListView) findViewById(R.id.sidebar_list);

		mList.setAdapter(madapter);
		mList.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				// TODO Auto-generated method stub
				switch (arg2) {
				case 0:
					mLayout.toggleSidebar();
					Intent regActivity = new Intent(
							ActivityRegisterBusiness.this,
							ActivityFeatured.class);
					startActivity(regActivity);
					overridePendingTransition(R.anim.trans_left_in,
							R.anim.trans_left_out);
					finish();
					break;

				case 1:

					mLayout.toggleSidebar();
					Intent IntentActivitySearch = new Intent(
							ActivityRegisterBusiness.this,
							ActivitySearchOption.class);
					startActivity(IntentActivitySearch);
					finish();

					break;

				case 2:
					mLayout.toggleSidebar();
					Intent IntentNearby = new Intent(
							ActivityRegisterBusiness.this,
							ActivityNearByBusiness.class);
					startActivity(IntentNearby);
					finish();

					break;

				case 3:
					mLayout.toggleSidebar();
					Intent intentchangepasswor = new Intent(
							ActivityRegisterBusiness.this, ActivityEvents.class);
					startActivity(intentchangepasswor);
					finish();
					break;
				case 4:

					mLayout.toggleSidebar();
					Intent IntentGps = new Intent(
							ActivityRegisterBusiness.this,
							ActivityFavouriteBusiness.class);
					startActivity(IntentGps);
					finish();

					break;

				case 5:
					mLayout.toggleSidebar();
					Intent IntentResource = new Intent(
							ActivityRegisterBusiness.this,
							ActivityResource.class);
					startActivity(IntentResource);
					finish();
					break;
				case 6:
					// Toast.makeText(getApplicationContext(),
					// "Item Selected::" + arg2, Toast.LENGTH_LONG).show();
					mLayout.toggleSidebar();
					Intent intentchangepasswor2 = new Intent(
							ActivityRegisterBusiness.this,
							ActivityRegistrationUpdate.class);
					startActivity(intentchangepasswor2);
					finish();
					break;

				case 7:
					// Toast.makeText(getApplicationContext(),
					// "Item Selected::" + arg2, Toast.LENGTH_LONG).show();
					mLayout.toggleSidebar();
					Intent intentchangepasswor3 = new Intent(
							ActivityRegisterBusiness.this,
							ActivityChangePassword.class);
					startActivity(intentchangepasswor3);
					finish();
					break;

				case 8:
					mLayout.toggleSidebar();

					break;

				case 9:
					mLayout.toggleSidebar();
					Intent Intengps = new Intent(ActivityRegisterBusiness.this,
							ActivityGPSLive.class);
					startActivity(Intengps);
					finish();
					break;
				case 10:
					PreferenceConnector.writeBoolean(getApplicationContext(),
							PreferenceConnector.IS_USER_LOGIN, false);

					AlertDialog.Builder alert = new AlertDialog.Builder(
							ActivityRegisterBusiness.this);

					alert.setTitle("ChristianBusinessDirectory");
					alert.setMessage("Are You sure You Want to logout?");

					alert.setPositiveButton("Ok",
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int whichButton) {
									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.EMAIL, "");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.FIRSTNAME, "");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.LASTNAME, "");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.COUNTRYID, "");

									PreferenceConnector
											.writeString(
													getApplicationContext(),
													PreferenceConnector.COUNTRYNAME,
													"");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.STATEID, "");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.STATENAME, "");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.CITYNAME, "");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.CITYID, "");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.BUSINESS_NAME,
											"");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.USER_ID, "");
									Intent intent = new Intent(
											ActivityRegisterBusiness.this,
											ActivityLogin.class);
									startActivity(intent);
									ActivityRegisterBusiness.this.finish();
								}

							});
					alert.setNegativeButton("Cancel",
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int which) {
									// TODO Auto-generated method stub

								}

							});

					alert.show();

					break;
				default:
					break;
				}

			}
		});
	}

	private void MakeToast(String msg) {
		Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_LONG).show();
	}

	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub

		PreferenceConnector.writeString(getApplicationContext(),
				PreferenceConnector.MEMBERSHIP_NAME, "");

		PreferenceConnector.writeString(getApplicationContext(),
				PreferenceConnector.BUSINESS_NAME_REGISTER, "");
		PreferenceConnector.writeString(getApplicationContext(),
				PreferenceConnector.BUSINESS_PHNO, "");

		PreferenceConnector.writeString(getApplicationContext(),
				PreferenceConnector.BUSINESS_WEBSITE, "");

		PreferenceConnector.writeString(getApplicationContext(),
				PreferenceConnector.CONTACT_PERSON, "");

		PreferenceConnector.writeString(getApplicationContext(),
				PreferenceConnector.DESCRIPTION, "");
		PreferenceConnector.writeString(getApplicationContext(),
				PreferenceConnector.BUSINESS_COUNTRY, "");

		PreferenceConnector.writeString(getApplicationContext(),
				PreferenceConnector.BUSINESS_STATE, "");

		PreferenceConnector.writeString(getApplicationContext(),
				PreferenceConnector.BUSINESS_CITY, "");

		PreferenceConnector.writeString(getApplicationContext(),
				PreferenceConnector.STREEET_ADDRESS, "");

		PreferenceConnector.writeString(getApplicationContext(),
				PreferenceConnector.BUSINESS_POSTCODE, "");

		Cons.ListOfCategory.clear();
		PreferenceConnector.writeString(getApplicationContext(),
				PreferenceConnector.REGION, "");

		SharedPreferences socialhandle = getApplicationContext()
				.getSharedPreferences("ABC", 0); // 0 - for private mode
		Editor editorSocial = socialhandle.edit();

		editorSocial.putInt("membership_checkbox", 0);

		editorSocial.commit(); // commit changes

		ActivityAddLogo.photo = null;

		finish();
		overridePendingTransition(R.anim.trans_right_in, R.anim.trans_right_out);
		super.onBackPressed();
	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub

		PreferenceConnector.writeString(getApplicationContext(),
				PreferenceConnector.MEMBERSHIP_NAME, "");

		PreferenceConnector.writeString(getApplicationContext(),
				PreferenceConnector.BUSINESS_NAME_REGISTER, "");
		PreferenceConnector.writeString(getApplicationContext(),
				PreferenceConnector.BUSINESS_PHNO, "");

		PreferenceConnector.writeString(getApplicationContext(),
				PreferenceConnector.BUSINESS_WEBSITE, "");

		PreferenceConnector.writeString(getApplicationContext(),
				PreferenceConnector.CONTACT_PERSON, "");

		PreferenceConnector.writeString(getApplicationContext(),
				PreferenceConnector.DESCRIPTION, "");
		PreferenceConnector.writeString(getApplicationContext(),
				PreferenceConnector.BUSINESS_COUNTRY, "");

		PreferenceConnector.writeString(getApplicationContext(),
				PreferenceConnector.BUSINESS_STATE, "");

		PreferenceConnector.writeString(getApplicationContext(),
				PreferenceConnector.BUSINESS_CITY, "");

		PreferenceConnector.writeString(getApplicationContext(),
				PreferenceConnector.STREEET_ADDRESS, "");

		PreferenceConnector.writeString(getApplicationContext(),
				PreferenceConnector.BUSINESS_POSTCODE, "");

		PreferenceConnector.writeString(getApplicationContext(),
				PreferenceConnector.REGION, "");

		Cons.ListOfCategory.clear();

		SharedPreferences socialhandle = getApplicationContext()
				.getSharedPreferences("ABC", 0); // 0 - for private mode
		Editor editorSocial = socialhandle.edit();

		editorSocial.putInt("membership_checkbox", 0);

		editorSocial.commit(); // commit changes
		ActivityAddLogo.photo = null;
		super.onDestroy();
	}

	public class SettingsAdapter extends BaseAdapter {

		Context mContext;

		public SettingsAdapter(Context c) {
			mContext = c;
		}

		public int getCount() {
			return mStrings.length;
		}

		public Object getItem(int pos) {
			return pos;
		}

		public long getItemId(int pos) {
			return pos;
		}

		public View getView(final int pos, View convertView, ViewGroup parent) {
			if (convertView == null)
				convertView = View.inflate(mContext, R.layout.row_layout_file,
						null);

			final ViewHolder holder = new ViewHolder();

			holder.imgText = (TextView) convertView
					.findViewById(R.id.row_layout_file_text_title);
			holder.imgText.setText(mStrings[pos]);
			return convertView;
		}

		class ViewHolder {
			public ImageView imgIcon, imgright;
			TextView imgText;
		}
	}

	@Override
	public boolean onEditorAction(TextView arg0, int arg1, KeyEvent arg2) {
		// TODO Auto-generated method stub
		return false;
	}

	public class MembersShipAdapter extends BaseAdapter {

		Context mContext;

		public MembersShipAdapter(Context c) {
			mContext = c;
		}

		public int getCount() {
			return Cons.ListofMember.size();
		}

		public Object getItem(int pos) {
			return pos;
		}

		public long getItemId(int pos) {
			return pos;
		}

		public View getView(final int pos, View convertView, ViewGroup parent) {
			if (convertView == null)
				convertView = View.inflate(mContext, R.layout.row_item, null);

			final ViewHolder holder = new ViewHolder();
			holder.imgText = (TextView) convertView
					.findViewById(R.id.row_item_textview);
			holder.imgText.setText(Cons.ListofMember.get(pos).getPlan_name());

			convertView.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub

					if (Cons.ListofMember.get(pos).getPlan_name()
							.equals("Basic")) {
						activity_register_business_edittxt_web
								.setVisibility(View.GONE);

						// id_membership = Integer.parseInt(Cons.ListofMember
						// .get(0).getId());

						ActivityDescription.textlimit = Integer
								.parseInt(Cons.ListofMember.get(0)
										.getDesc_limit());

						ActivityDescription.StringTitle = Cons.ListofMember
								.get(0).getPlan_name();

						membershiplevel = Integer.parseInt(Cons.ListofMember
								.get(0).getCategory_limit());

						ActivityCategoryList.Stringmembership = Cons.ListofMember
								.get(0).getPlan_name();

						ActivityCategoryList.sizeofselection = Integer
								.parseInt(Cons.ListofMember.get(0)
										.getCategory_limit());

					} else if (Cons.ListofMember.get(pos).getPlan_name()
							.equals("Sponsor")) {
						activity_register_business_edittxt_web
								.setVisibility(View.VISIBLE);

						// id_membership = Integer.parseInt(Cons.ListofMember
						// .get(1).getId());

						ActivityDescription.textlimit = Integer
								.parseInt(Cons.ListofMember.get(1)
										.getDesc_limit());

						ActivityDescription.StringTitle = Cons.ListofMember
								.get(1).getPlan_name();

						membershiplevel = Integer.parseInt(Cons.ListofMember
								.get(1).getCategory_limit());

						ActivityCategoryList.Stringmembership = Cons.ListofMember
								.get(1).getPlan_name();

						ActivityCategoryList.sizeofselection = Integer
								.parseInt(Cons.ListofMember.get(1)
										.getCategory_limit());
					} else if (Cons.ListofMember.get(pos).getPlan_name()
							.equals("Premium")) {
						activity_register_business_edittxt_web
								.setVisibility(View.VISIBLE);

						// id_membership = Integer.parseInt(Cons.ListofMember
						// .get(2).getId());

						ActivityDescription.textlimit = Integer
								.parseInt(Cons.ListofMember.get(2)
										.getDesc_limit());

						ActivityDescription.StringTitle = Cons.ListofMember
								.get(2).getPlan_name();

						membershiplevel = Integer.parseInt(Cons.ListofMember
								.get(2).getCategory_limit());

						ActivityCategoryList.Stringmembership = Cons.ListofMember
								.get(2).getPlan_name();

						ActivityCategoryList.sizeofselection = Integer
								.parseInt(Cons.ListofMember.get(2)
										.getCategory_limit());
					} else if (Cons.ListofMember.get(pos).getPlan_name()
							.equals("Deluxe")) {
						activity_register_business_edittxt_web
								.setVisibility(View.VISIBLE);

						// id_membership = Integer.parseInt(Cons.ListofMember
						// .get(3).getId());

						ActivityDescription.textlimit = Integer
								.parseInt(Cons.ListofMember.get(3)
										.getDesc_limit());

						ActivityDescription.StringTitle = Cons.ListofMember
								.get(3).getPlan_name();

						membershiplevel = Integer.parseInt(Cons.ListofMember
								.get(3).getCategory_limit());

						ActivityCategoryList.Stringmembership = Cons.ListofMember
								.get(3).getPlan_name();

						ActivityCategoryList.sizeofselection = Integer
								.parseInt(Cons.ListofMember.get(3)
										.getCategory_limit());
					} else {

					}

					activity_address_select_membership_level
							.setText(Cons.ListofMember.get(pos).getPlan_name());
					Log.v("Membership_Level_name :", Cons.ListofMember.get(pos)
							.getPlan_name());

					LevelId = Cons.ListofMember.get(pos).getId();
					Log.v("Membership_Level_id :", Cons.ListofMember.get(pos)
							.getId());

					PreferenceConnector.writeString(getApplicationContext(),
							PreferenceConnector.MEMBERSHIP_ID, LevelId);

					dialog.dismiss();

				}
			});
			return convertView;
		}

		class ViewHolder {

			TextView imgText;
		}
	}

	private void GetMemberShipLevel() {

		final ProgressDialog dialog;
		dialog = new ProgressDialog(this);
		dialog.setTitle("");

		dialog.setMessage("Please Wait...");
		dialog.setCancelable(false);

		AsyncTask<Void, Void, Boolean> waitForCompletion = new AsyncTask<Void, Void, Boolean>() {

			@Override
			protected void onPreExecute() {
				// TODO Auto-generated method stub
				super.onPreExecute();
				dialog.show();
			}

			@Override
			protected Boolean doInBackground(Void... params) {
				Cons.ListofMember.clear();
				try {

					HttpClient httpClient = new DefaultHttpClient();
					String url = com.christianbusiness.utils.Constant.GetMemberShipLevel;

					HttpGet httpGet = new HttpGet(url);

					HttpResponse response = httpClient.execute(httpGet);
					String json = EntityUtils.toString(response.getEntity());
					JSONTokener tokener = new JSONTokener(json);
					JSONObject finalResult = new JSONObject(tokener);
					Log.i("Response Json", "" + finalResult.toString());
					JSONArray obj = finalResult.getJSONArray("data");

					for (int i = 0; i < obj.length(); i++) {

						JSONObject jobjdata = obj.getJSONObject(i);
						MemberShipLevel msl = new MemberShipLevel();

						if (jobjdata.has("id")) {
							msl.setId(jobjdata.getString("id"));
						} else {
							msl.setId("N.A");
						}

						if (jobjdata.has("plan_name")) {
							msl.setPlan_name(jobjdata.getString("plan_name"));
						} else {
							msl.setPlan_name("N.A");
						}

						if (jobjdata.has("plan_price")) {
							msl.setPlan_price(jobjdata.getString("plan_price"));
						} else {
							msl.setPlan_price("N.A");
						}

						if (jobjdata.has("desc_limit")) {
							msl.setDesc_limit(jobjdata.getString("desc_limit"));
						} else {
							msl.setDesc_limit("N.A");
						}

						if (jobjdata.has("category_limit")) {
							msl.setCategory_limit(jobjdata
									.getString("category_limit"));
						} else {
							msl.setCategory_limit("N.A");
						}

						Cons.ListofMember.add(msl);

						Log.i("No:", "" + i);
						Log.i("Id:", jobjdata.getString("id"));
						Log.i("plan_name", jobjdata.getString("plan_name"));
						Log.i("plan_price", jobjdata.getString("plan_price"));
						Log.i("desc_limit", jobjdata.getString("desc_limit"));
						Log.i("category_limit",
								jobjdata.getString("category_limit"));

					}

				} catch (ClientProtocolException e) {
					// TODO Auto-generated catch block
					Log.i("Exception",
							"ClientProtocolException : " + e.getMessage());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Log.i("Exception", "IOException : " + e.getMessage());
				} catch (Exception e) {
					// TODO: handle exception
					Log.i("Exception", "Http Response : " + e.getMessage());
				}
				return null;
			};

			@Override
			protected void onPostExecute(Boolean result) {

				dialog.dismiss();
				setMemberShipLevel();
			}
		};
		if (isInternetAvailable())
			waitForCompletion.execute();
		else
			Toast.makeText(getApplicationContext(),
					"Internet service not available", Toast.LENGTH_SHORT)
					.show();
	}

	public boolean isInternetAvailable() {
		ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		if (cm.getActiveNetworkInfo() != null)
			return (cm.getActiveNetworkInfo().isConnected() && cm
					.getActiveNetworkInfo().isAvailable());
		else
			return false;
	}

	protected void setMemberShipLevel() {
		// TODO Auto-generated method stub
		List<String> listmembershiplevel = new ArrayList<String>();
		for (int i = 0; i < Cons.ListofMember.size(); i++) {
			listmembershiplevel.add(Cons.ListofMember.get(i).getPlan_name());
		}

		ArrayAdapter<String> dataAdapters1 = new ArrayAdapter<String>(this,
				android.R.layout.simple_spinner_item, listmembershiplevel);

		dataAdapters1
				.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

	}
}
