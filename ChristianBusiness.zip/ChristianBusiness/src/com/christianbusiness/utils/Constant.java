package com.christianbusiness.utils;

public class Constant {

	// TESTING SERVER WEB SERVICE
	public static final String LoginUrl = "http://testing.siliconithub.com/cbd/index.php/api/Registration/checkLogin";
	public static final String RegisterUrl = "http://testing.siliconithub.com/cbd/index.php/api/Registration/memberRegistration";
	public static final String RegisterUpdateUrl = "http://testing.siliconithub.com/cbd/index.php/api/Registration/updateMemberRegistration";
	public static final String ChangePassUrl = "http://testing.siliconithub.com/cbd/index.php/api/Registration/changePassword";
	public static final String ForgotPassUrl = "http://testing.siliconithub.com/cbd/index.php/api/Registration/forgotPassword";
	public static final String UpdateUrl = "http://testing.siliconithub.com/cbd/index.php/api/Registration/updateMemberRegistration";
	public static final String CountryUrl = "http://testing.siliconithub.com/cbd/index.php/api/Registration/getcountry";
	public static final String StateURL = "http://testing.siliconithub.com/cbd/index.php/api/Registration/getstates";
	public static final String CityUrl = "http://testing.siliconithub.com/cbd/index.php/api/Registration/getcity";
	public static final String GetFeaturlist = "http://testing.siliconithub.com/cbd/index.php/api/business/getfeaturedBusinessList?";
	public static final String ImageURL = "http://testing.siliconithub.com/cbd/upload/BusinessImage/";
	public static final String GetBusinesCategorywise = "http://testing.siliconithub.com/cbd/index.php/api/business/GetBusinessByCategory?id=";
	public static final String BusinessRegistraton = "http://testing.siliconithub.com/cbd/index.php/api/business/createDirectory";
	public static final String CategoryList = "http://testing.siliconithub.com/cbd/index.php/api/business/getcategoryDetails";
	public static final String NearByPlaces = "http://testing.siliconithub.com/cbd/index.php/api/business/nearByBusiness?";
	public static final String GetResource = "http://testing.siliconithub.com/cbd/index.php/api/Resource/getresourceList";
	public static final String SearchBusiness = "http://testing.siliconithub.com/cbd/index.php/api/business/searchBusiness";
	public static final String GetSelectedBusiness = "http://testing.siliconithub.com/cbd/index.php/api/business/getBusinessDetail?id=";
	public static final String GetTermCondition = "http://testing.siliconithub.com/cbd/index.php/api/business/getcategoryTermsConditions";
	public static final String GetPaymentMethod = "http://testing.siliconithub.com/cbd/index.php/api/business/updateDirectoryPaymentStatus?id=";
	public static final String GetAllBusinesforGps = "http://testing.siliconithub.com/cbd/index.php/api/business/getAllBusiness";
	public static final String Favourite = "http://testing.siliconithub.com/cbd/index.php/api/business/AddFevoriteBusiness?";
	public static final String GetMemberShipLevel = "http://testing.siliconithub.com/cbd/index.php/api/Membership/getmembershipLevels";

	public static final String GetURL = "http://testing.siliconithub.com/cbd/index.php/api/cms/GetCms/param/";

}
