package com.christianbusiness;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import com.animation.AnimationLayout;
import com.chirstianbusiness.classes.MemberShipLevel;
import com.christianbusiness.preference.PreferenceConnector;
import com.christianbusiness.utils.Constant;
import com.nostra13.universalimageloader.cache.disc.naming.HashCodeFileNameGenerator;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.ImageScaleType;
import com.nostra13.universalimageloader.core.assist.QueueProcessingType;
import com.nostra13.universalimageloader.core.decode.BaseImageDecoder;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

public class ActivityFeatured extends Activity {

	ListView listView;
	List<RowItem> items;
	Button activity_featured_list_btn;
	Button activity_featured_search_btn;

	protected String[] mStrings = { "Featured Business", "Search Business",
			"Near By Business", "Business Categories", "Favorite Business",
			"Resource", "Edit Profile", "Change Password", "Business Register",
			"GPS Live Map", "Logout" };

	SettingsAdapter madapter;
	public static int posofrecord;
	ListView mList;
	CustomBaseAdapter adapter;

	public ImageLoader imageLoader;
	public static DisplayImageOptions optionsItems;
	public static DisplayImageOptions optionsDetails;
	public static DisplayImageOptions options;

	// business_id=388&user_id=25&is_fevorite=Y

	protected AnimationLayout mLayout;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_featured);
		initwidget();
		initImageLoader();
		getdata();

		listView = (ListView) findViewById(R.id.activity_featured_listview);

		adapter = new CustomBaseAdapter(this, items);
		listView.setAdapter(adapter);

		listView.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> adpter, View v, int pos,
					long ld) {

			}
		});

		activity_featured_list_btn = (Button) findViewById(R.id.activity_featured_list_btn);
		activity_featured_list_btn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

				mLayout.toggleSidebar();
			}
		});

		activity_featured_search_btn = (Button) findViewById(R.id.activity_featured_search_btn);
		activity_featured_search_btn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				// Intent intent = new Intent(ActivityFeatured.this,
				// ActivityRegistrationUpdate.class);
				// startActivity(intent);
				// finish();
			}
		});
	}

	private void initImageLoader() {

		DisplayMetrics displaymetrics = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);

		ImageLoaderConfiguration config = new ImageLoaderConfiguration.Builder(
				getApplicationContext()).imageDecoder(new BaseImageDecoder())
				.threadPriority(Thread.NORM_PRIORITY - 2)
				.denyCacheImageMultipleSizesInMemory().enableLogging()
				.discCacheFileNameGenerator(new HashCodeFileNameGenerator())
				.tasksProcessingOrder(QueueProcessingType.LIFO).enableLogging()
				.build();
		// Initialize ImageLoader with configuration.
		imageLoader = ImageLoader.getInstance();
		imageLoader.init(config);
		optionsItems = new DisplayImageOptions.Builder()
				.showStubImage(R.drawable.ic_item_loading)
				.imageScaleType(ImageScaleType.IN_SAMPLE_POWER_OF_2)
				.showImageForEmptyUri(R.drawable.ic_item_loading)
				.showImageOnFail(R.drawable.noimage).cacheInMemory()
				.cacheOnDisc().bitmapConfig(Bitmap.Config.RGB_565).build();
		optionsDetails = new DisplayImageOptions.Builder()
				.showStubImage(R.drawable.ic_detail_item_loading)
				.imageScaleType(ImageScaleType.IN_SAMPLE_POWER_OF_2)
				.showImageForEmptyUri(R.drawable.ic_detail_item_loading)
				.showImageOnFail(R.drawable.noimage).cacheInMemory()
				.cacheOnDisc().bitmapConfig(Bitmap.Config.RGB_565).build();
		options = new DisplayImageOptions.Builder()
				.showStubImage(R.drawable.ic_item_loading)
				.imageScaleType(ImageScaleType.EXACTLY_STRETCHED)
				.showImageForEmptyUri(R.drawable.ic_item_loading)
				.showImageOnFail(R.drawable.noimage).cacheInMemory()
				.cacheOnDisc().bitmapConfig(Bitmap.Config.RGB_565).build();

		// String imageUrl = "http://a.b.com/invalid.jpg";
		// aq.id(R.id.image1).image(imageUrl, true, true, 0, AQuery.INVISIBLE);

	}

	private void initwidget() {
		mLayout = (AnimationLayout) findViewById(R.id.activity_change_password_rl1);
		madapter = new SettingsAdapter(getApplicationContext());

		mList = (ListView) findViewById(R.id.sidebar_list);

		mList.setAdapter(madapter);
		mList.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				// TODO Auto-generated method stub
				switch (arg2) {
				case 0:
					// Toast.makeText(getApplicationContext(),
					// "Item Selected::" + arg2, Toast.LENGTH_LONG).show();
					mLayout.toggleSidebar();

					break;

				case 1:

					mLayout.toggleSidebar();
					Intent IntentActivitySearch = new Intent(
							ActivityFeatured.this, ActivitySearchOption.class);
					startActivity(IntentActivitySearch);
					finish();

					break;

				case 2:
					mLayout.toggleSidebar();
					Intent IntentNearby = new Intent(ActivityFeatured.this,
							ActivityNearByBusiness.class);
					startActivity(IntentNearby);
					finish();

					break;

				case 3:
					mLayout.toggleSidebar();
					Intent intentchangepasswor = new Intent(
							ActivityFeatured.this, ActivityEvents.class);
					startActivity(intentchangepasswor);
					finish();
					break;
				case 4:

					mLayout.toggleSidebar();
					Intent intentbusinessfeture = new Intent(
							ActivityFeatured.this,
							ActivityFavouriteBusiness.class);
					startActivity(intentbusinessfeture);
					finish();

					break;

				case 5:
					mLayout.toggleSidebar();
					Intent IntentResource = new Intent(ActivityFeatured.this,
							ActivityResource.class);
					startActivity(IntentResource);
					finish();
					break;
				case 6:
					// Toast.makeText(getApplicationContext(),
					// "Item Selected::" + arg2, Toast.LENGTH_LONG).show();
					mLayout.toggleSidebar();
					Intent intentchangepasswor2 = new Intent(
							ActivityFeatured.this,
							ActivityRegistrationUpdate.class);
					startActivity(intentchangepasswor2);
					finish();
					break;

				case 7:
					// Toast.makeText(getApplicationContext(),
					// "Item Selected::" + arg2, Toast.LENGTH_LONG).show();
					mLayout.toggleSidebar();
					Intent intentchangepasswor3 = new Intent(
							ActivityFeatured.this, ActivityChangePassword.class);
					startActivity(intentchangepasswor3);
					finish();
					break;

				case 8:
					mLayout.toggleSidebar();
					Intent regActivity = new Intent(ActivityFeatured.this,
							ActivityRegisterBusiness.class);
					startActivity(regActivity);
					finish();
					break;

				case 9:
					mLayout.toggleSidebar();
					Intent Intengps = new Intent(ActivityFeatured.this,
							ActivityGPSLive.class);
					startActivity(Intengps);
					finish();

					break;

				case 10:
					PreferenceConnector.writeBoolean(getApplicationContext(),
							PreferenceConnector.IS_USER_LOGIN, false);

					AlertDialog.Builder alert = new AlertDialog.Builder(
							ActivityFeatured.this);

					alert.setTitle("ChristianBusinessDirectory");
					alert.setMessage("Are You sure You Want to logout?");

					alert.setPositiveButton("Ok",
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int whichButton) {

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.EMAIL, "");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.FIRSTNAME, "");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.LASTNAME, "");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.COUNTRYID, "");

									PreferenceConnector
											.writeString(
													getApplicationContext(),
													PreferenceConnector.COUNTRYNAME,
													"");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.STATEID, "");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.STATENAME, "");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.CITYNAME, "");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.CITYID, "");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.BUSINESS_NAME,
											"");

									PreferenceConnector.writeString(
											getApplicationContext(),
											PreferenceConnector.USER_ID, "");

									Intent intent = new Intent(
											ActivityFeatured.this,
											ActivityLogin.class);
									startActivity(intent);
									ActivityFeatured.this.finish();
								}

							});
					alert.setNegativeButton("Cancel",
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int which) {
									// TODO Auto-generated method stub

								}

							});

					alert.show();

					break;
				default:
					break;
				}

			}
		});

	}

	public class CustomBaseAdapter extends BaseAdapter {

		Context context;
		List<RowItem> rowItems;

		public CustomBaseAdapter(Context context, List<RowItem> items) {
			this.context = context;
			this.rowItems = items;
		}

		/* private view holder class */
		private class ViewHolder {
			ImageView custom_raw_activity_fearured_image;
			ImageView img_favourite;
			TextView custom_raw_activity_fearured_business_name;
			TextView custom_raw_activity_fearured_details;
		}

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return Cons.ListofFeature.size();
		}

		@Override
		public View getView(final int position, View convertView,
				ViewGroup parent) {
			ViewHolder holder = null;

			LayoutInflater mInflater = (LayoutInflater) context
					.getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
			if (convertView == null) {
				convertView = mInflater.inflate(
						R.layout.custom_raw_activity_fearured, null);
				holder = new ViewHolder();
				holder.custom_raw_activity_fearured_business_name = (TextView) convertView
						.findViewById(R.id.custom_raw_activity_fearured_business_name);
				holder.custom_raw_activity_fearured_business_name
						.setGravity(Gravity.CENTER);
				holder.custom_raw_activity_fearured_details = (TextView) convertView
						.findViewById(R.id.custom_raw_activity_fearured_details);
				holder.custom_raw_activity_fearured_details
						.setGravity(Gravity.CENTER);
				holder.custom_raw_activity_fearured_image = (ImageView) convertView
						.findViewById(R.id.custom_raw_activity_fearured_image);

				holder.img_favourite = (ImageView) convertView
						.findViewById(R.id.custom_row_activity_img_favourite);
				convertView.setTag(holder);
			} else {
				holder = (ViewHolder) convertView.getTag();
			}

			if (Cons.ListofFeature.get(position).getIs_fevorite()
					.contains("Yes")) {
				holder.img_favourite
						.setBackgroundResource(R.drawable.unfavroite);
			} else {
				holder.img_favourite.setBackgroundResource(R.drawable.favroite);
			}

			holder.img_favourite.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					posofrecord = position;
					DoFavouriteAndUnFavourite();
					// if (Cons.ListofFeature.get(position).getIs_fevorite()
					// .contains("Yes")) {
					// Cons.ListofFeature.get(position).setIs_fevorite("No");
					//
					// } else {
					// Cons.ListofFeature.get(position).setIs_fevorite("Yes");
					//
					// }
				}
			});

			convertView.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					posofrecord = position;
					Intent Bussinessdetails = new Intent(ActivityFeatured.this,
							ActivityBusinessDetails.class);
					startActivity(Bussinessdetails);
				}
			});

			holder.custom_raw_activity_fearured_business_name
					.setText(Cons.ListofFeature.get(position)
							.getBusiness_name().trim());
			holder.custom_raw_activity_fearured_details
					.setText(Cons.ListofFeature.get(position).getDescription()
							.trim());

			imageLoader.displayImage(Constant.ImageURL
					+ Cons.ListofFeature.get(position).getBusiness_logo(),
					holder.custom_raw_activity_fearured_image, optionsItems);

			return convertView;
		}

		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return 0;
		}

	}

	private void ShowAlertMessage(String title, String Message) {

		AlertDialog.Builder altDialog = new AlertDialog.Builder(this);
		altDialog.setTitle(title);
		altDialog.setMessage(Message); // here add your message
		altDialog.setNeutralButton("OK", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				// TODO Auto-generated method stub
				dialog.dismiss();
			}
		});
		altDialog.show();
	}

	public class SettingsAdapter extends BaseAdapter {

		Context mContext;

		public SettingsAdapter(Context c) {
			mContext = c;
		}

		public int getCount() {
			return mStrings.length;
		}

		public Object getItem(int pos) {
			return pos;
		}

		public long getItemId(int pos) {
			return pos;
		}

		public View getView(final int pos, View convertView, ViewGroup parent) {
			if (convertView == null)
				convertView = View.inflate(mContext, R.layout.row_layout_file,
						null);

			final ViewHolder holder = new ViewHolder();

			holder.imgText = (TextView) convertView
					.findViewById(R.id.row_layout_file_text_title);
			holder.imgText.setText(mStrings[pos]);
			return convertView;
		}

		class ViewHolder {
			public ImageView imgIcon, imgright;
			TextView imgText;
		}
	}

	// GET FEATURE LISTING FROM SERVER

	private void getdata() {

		final ProgressDialog dialog;
		dialog = new ProgressDialog(this);
		dialog.setTitle("");

		dialog.setMessage("Please Wait...");
		dialog.setCancelable(false);

		AsyncTask<Void, Void, Boolean> waitForCompletion = new AsyncTask<Void, Void, Boolean>() {

			@Override
			protected void onPreExecute() {
				// TODO Auto-generated method stub
				super.onPreExecute();
				dialog.show();
			}

			@Override
			protected Boolean doInBackground(Void... params) {
				Cons.ListofFeature.clear();
				try {

					HttpClient httpClient = new DefaultHttpClient();
					String url = com.christianbusiness.utils.Constant.GetFeaturlist
							+ "user_id="
							+ PreferenceConnector.readString(
									getApplicationContext(),
									PreferenceConnector.USER_ID, "")
							+ "&page=0";
					HttpGet httpGet = new HttpGet(url);
					Log.i("URL", url);

					HttpResponse response = httpClient.execute(httpGet);
					String json = EntityUtils.toString(response.getEntity());
					JSONTokener tokener = new JSONTokener(json);
					JSONObject finalResult = new JSONObject(tokener);
					Log.i("Response Json", "" + finalResult.toString());
					JSONArray obj = finalResult.getJSONArray("data");
					Log.i("Object of Data", obj.toString());
					for (int i = 0; i < obj.length(); i++) {

						FeatureManager rowitem = new FeatureManager();
						JSONObject objdata = obj.getJSONObject(i);

						if (objdata.has("id")) {
							rowitem.setId(objdata.getString("id"));
						} else {
							rowitem.setId("N.A");
						}

						if (objdata.has("is_fevorite")) {
							rowitem.setIs_fevorite(objdata
									.getString("is_fevorite"));
						} else {
							rowitem.setIs_fevorite("No");
						}

						if (objdata.has("fk_directory_category_id")) {
							rowitem.setFk_directory_category_id(objdata
									.getString("fk_directory_category_id"));
						} else {
							rowitem.setFk_directory_category_id("N.A");
						}

						if (objdata.has("fk_directory_category_names")) {
							rowitem.setFk_directory_category_names(objdata
									.getString("fk_directory_category_names"));
						} else {
							rowitem.setFk_directory_category_names("N.A.");
						}

						if (objdata.has("fk_user_id")) {
							rowitem.setFk_user_id(objdata
									.getString("fk_user_id"));
						} else {
							rowitem.setFk_user_id("N.A");

						}

						if (objdata.has("business_name")) {
							rowitem.setBusiness_name(objdata
									.getString("business_name"));
						} else {
							rowitem.setBusiness_name("N.A");
						}

						if (objdata.has("description")) {
							rowitem.setDescription(objdata
									.getString("description"));
						} else {
							rowitem.setDescription("N.A");
						}

						if (objdata.has("business_phone")) {
							rowitem.setBusiness_phone(objdata
									.getString("business_phone"));
						} else {
							rowitem.setBusiness_phone("N.A");
						}

						if (objdata.has("website_name")) {
							rowitem.setWebsite_name(objdata
									.getString("website_name"));
						} else {
							rowitem.setWebsite_name(objdata.getString("N.A"));
						}

						if (objdata.has("email")) {
							rowitem.setEmail(objdata.getString("email"));
						} else {
							rowitem.setEmail("N.A");
						}

						if (objdata.has("contact_person")) {

							rowitem.setContact_person(objdata
									.getString("contact_person"));
						} else {
							rowitem.setContact_person("N.A");
						}

						if (objdata.has("fk_country")) {
							rowitem.setFk_country(objdata
									.getString("fk_country"));
						} else {
							rowitem.setFk_country("N.A");
						}

						if (objdata.has("fk_country_name")) {
							rowitem.setFk_country_name(objdata
									.getString("fk_country_name"));
						} else {
							rowitem.setFk_country_name("N.A");
						}

						if (objdata.has("fk_state")) {
							rowitem.setFk_state(objdata.getString("fk_state"));
						} else {
							rowitem.setFk_state("N.A");
						}

						if (objdata.has("fk_state_name")) {
							rowitem.setFk_state_name(objdata
									.getString("fk_state_name"));
						} else {
							rowitem.setFk_state_name("N.A");
						}

						if (objdata.has("fk_city")) {

							rowitem.setFk_city(objdata.getString("fk_city"));
						} else {
							rowitem.setFk_city("N.A");
						}

						if (objdata.has("fk_city_name")) {
							rowitem.setFk_city_name(objdata
									.getString("fk_city_name"));
						} else {
							rowitem.setFk_city_name("N.A");
						}

						if (objdata.has("street_name_number")) {
							rowitem.setStreet_name_number(objdata
									.getString("street_name_number"));
						} else {
							rowitem.setStreet_name_number("N.A");
						}

						if (objdata.has("postcode")) {
							rowitem.setPostcode(objdata.getString("postcode"));
						} else {
							rowitem.setPostcode("N.A");
						}

						if (objdata.has("latitude")) {
							rowitem.setLatitude(objdata.getString("latitude"));
						} else {
							rowitem.setLatitude("N.A");
						}

						if (objdata.has("longitude")) {
							rowitem.setLongitude(objdata.getString("longitude"));
						} else {
							rowitem.setLongitude("N.A");
						}

						if (objdata.has("region")) {
							rowitem.setRegion(objdata.getString("region"));
						} else {
							rowitem.setRegion("N.A");
						}

						if (objdata.has("business_logo")) {
							rowitem.setBusiness_logo(objdata
									.getString("business_logo"));
						} else {
							rowitem.setBusiness_logo("N.A");
						}

						if (objdata.has("payment_status")) {
							rowitem.setPayment_status(objdata
									.getString("payment_status"));
						} else {
							rowitem.setPayment_status("N.A");
						}

						if (objdata.has("plan_startdate")) {
							rowitem.setPlan_startdate(objdata
									.getString("plan_startdate"));
						} else {
							rowitem.setPlan_startdate("N.A");
						}

						if (objdata.has("plan_enddate")) {
							rowitem.setPlan_enddate(objdata
									.getString("plan_enddate"));
						} else {
							rowitem.setPlan_enddate("N.A");
						}

						if (objdata.has("created_at")) {
							rowitem.setCreated_at(objdata
									.getString("created_at"));
						} else {
							rowitem.setCreated_at("N.A");
						}

						if (objdata.has("updated_at")) {
							rowitem.setUpdated_at(objdata
									.getString("updated_at"));
						} else {
							rowitem.setUpdated_at("N.A");
						}

						if (objdata.has("status")) {
							rowitem.setStatus(objdata.getString("status"));
						} else {
							rowitem.setStatus("N.A");
						}

						// }

						Cons.ListofFeature.add(rowitem);

					}

				} catch (ClientProtocolException e) {
					// TODO Auto-generated catch block
					Log.i("Exception",
							"ClientProtocolException : " + e.getMessage());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Log.i("Exception", "IOException : " + e.getMessage());
				} catch (Exception e) {
					// TODO: handle exception
					Log.i("Exception", "Http Response : " + e.getMessage());
				}
				return null;
			};

			@Override
			protected void onPostExecute(Boolean result) {

				dialog.dismiss();
				if (Cons.ListofFeature.size() == 0) {

					ShowAlertMessage("Christian Business", "No Data Found");

				} else {
					listView.setAdapter(adapter);
				}

			}
		};
		if (isInternetAvailable())
			waitForCompletion.execute();
		else
			Toast.makeText(getApplicationContext(),
					"Internet service not available", Toast.LENGTH_SHORT)
					.show();
	}

	public void showToast(String msg) {
		Toast.makeText(ActivityFeatured.this, msg, Toast.LENGTH_LONG).show();
	}

	// CHECKING INTERNET AVAILABILITY
	public boolean isInternetAvailable() {
		ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		if (cm.getActiveNetworkInfo() != null)
			return (cm.getActiveNetworkInfo().isConnected() && cm
					.getActiveNetworkInfo().isAvailable());
		else
			return false;
	}

	private void DoFavouriteAndUnFavourite() {

		final ProgressDialog dialog;
		dialog = new ProgressDialog(this);
		dialog.setTitle("");

		dialog.setMessage("Please Wait...");
		dialog.setCancelable(false);

		AsyncTask<Void, Void, Boolean> waitForCompletion = new AsyncTask<Void, Void, Boolean>() {
			String Message;

			@Override
			protected void onPreExecute() {
				// TODO Auto-generated method stub
				super.onPreExecute();
				dialog.show();
			}

			@Override
			protected Boolean doInBackground(Void... params) {

				try {

					String status;

					if (Cons.ListofFeature.get(posofrecord).getIs_fevorite()
							.contains("Yes")) {

						status = "N";
					} else {
						status = "Y";
					}

					HttpClient httpClient = new DefaultHttpClient();
					String url = com.christianbusiness.utils.Constant.Favourite
							+ "business_id="
							+ Cons.ListofFeature.get(posofrecord).getId()
							+ "&user_id="
							+ PreferenceConnector.readString(
									getApplicationContext(),
									PreferenceConnector.USER_ID, "")
							+ "&is_fevorite=" + status;

					Log.i("Log of Favourite::", url);
					// business_id=388&user_id=25&is_fevorite=Y
					HttpGet httpGet = new HttpGet(url);

					HttpResponse response = httpClient.execute(httpGet);
					String json = EntityUtils.toString(response.getEntity());
					JSONTokener tokener = new JSONTokener(json);
					JSONObject finalResult = new JSONObject(tokener);
					Log.i("Response Json", "" + finalResult.toString());

					Message = finalResult.getString("data");

				} catch (ClientProtocolException e) {
					// TODO Auto-generated catch block
					Log.i("Exception",
							"ClientProtocolException : " + e.getMessage());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Log.i("Exception", "IOException : " + e.getMessage());
				} catch (Exception e) {
					// TODO: handle exception
					Log.i("Exception", "Http Response : " + e.getMessage());
				}
				return null;
			};

			@Override
			protected void onPostExecute(Boolean result) {

				dialog.dismiss();

				if (Cons.ListofFeature.get(posofrecord).getIs_fevorite()
						.contains("Yes")) {
					Cons.ListofFeature.get(posofrecord).setIs_fevorite("No");

				} else {
					Cons.ListofFeature.get(posofrecord).setIs_fevorite("Yes");

				}

				listView.setAdapter(adapter);

				ShowAlertMessage("ChristianBusinessDirectory", Message);
			}
		};
		if (isInternetAvailable())
			waitForCompletion.execute();
		else
			Toast.makeText(getApplicationContext(),
					"Internet service not available", Toast.LENGTH_SHORT)
					.show();
	}

}
