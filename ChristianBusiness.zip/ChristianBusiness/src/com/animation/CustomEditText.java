package com.animation;

import android.content.Context;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.widget.EditText;

public class CustomEditText extends EditText {

	public CustomEditText(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
	}

	public CustomEditText(Context context, AttributeSet attr) {
		super(context, attr);
		// TODO Auto-generated constructor stub
	}

	@Override
	public boolean onKeyPreIme(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK
				&& event.getAction() == KeyEvent.ACTION_UP) {
			return true;
		}
		return super.dispatchKeyEvent(event);
	}
}
